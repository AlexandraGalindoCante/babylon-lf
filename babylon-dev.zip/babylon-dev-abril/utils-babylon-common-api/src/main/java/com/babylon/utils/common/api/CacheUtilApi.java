package com.babylon.utils.common.api;

import com.liferay.portal.kernel.cache.PortalCache;

import java.io.Serializable;
import java.util.List;

public interface CacheUtilApi {


    public String getKey(List<Serializable> args, String cacheName);

    public <K extends Serializable> K get (PortalCache<String, K> cache, String key);

    public <K extends Serializable> boolean put (PortalCache<String, K> cache, String key, K element);
}
