package com.babylon.utils.common.api;

import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.model.User;

import aQute.bnd.annotation.ProviderType;

/**
 * <b>Nombre: </b> CustomFieldsApi </br>
 * <b>Descripci�n:</b> Interfaz de la firma Api que expone m�todo para pedir
 * expandos y sus validaciones </br>
 * <b>Fecha Creaci�n:</b> 17/10/2024 </br>
 * <b>Autor:BABYLON Jose Andr�s S�nchez Bernal </br>
 * <b>Fecha de �ltima Modificaci�n: </b></br>
 * <b>Modificado por: </b></br>
 */
@ProviderType
public interface CustomFieldsApi {

	/**
	 * <b>Nombre: </b> getOrganizationIdByUser </br>
	 * <b>Descripci�n:</b> Firma m�todo obtener el OrganizationId </br>
	 * <b>Fecha Creaci�n:</b> 17/10/2024 </br>
	 * <b>Autor:BABYLON Jose Andr�s S�nchez Bernal </br>
	 * <b>Fecha de �ltima Modificaci�n: </b></br>
	 * <b>Modificado por: </b></br>
	 * 
	 * @param user
	 * @return
	 */
	public JSONObject getOrganizationIdByUser(User user);
}
