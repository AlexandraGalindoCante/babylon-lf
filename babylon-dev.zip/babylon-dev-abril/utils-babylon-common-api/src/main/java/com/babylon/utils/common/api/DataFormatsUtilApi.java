package com.babylon.utils.common.api;

import java.util.Date;

import aQute.bnd.annotation.ProviderType;

/**
 * <b>Nombre: </b> DataFormatsUtil </br>
 * <b>Descripci�n:</b> Interfaz de la firma Api que expone m�todos utilitarios en
 * base al uso de formatos de fechas </br>
 * <b>Fecha Creaci�n:</b> 18/11/2022 </br>
 * <b>Autor:BABYLON Ricardo Salinas</br>
 * <b>Fecha de �ltima Modificaci�n: 19/11/2022 </b></br>
 * <b>Modificado por:BABYLON Jose Andr�s S�nchez Bernal </b></br>
 */
@ProviderType
public interface DataFormatsUtilApi {

	/**
	 * <b>Nombre: </b> getFormatDate </br>
	 * <b>Descripci�n:</b> Firma m�todo de formato de fechas </br>
	 * <b>Fecha Creaci�n:</b> 18/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas</br>
	 * <b>Fecha de �ltima Modificaci�n:	19/11/2022 </b></br>
	 * <b>Modificado por:BABYLON Jose Andr�s S�nchez Bernal</b></br>
	 * 
	 * @param date
	 * @param dateFormatPattern
	 * @return String
	 */
	public String getFormatDate(Date date, String dateFormatPattern);

	/**
	 * <b>Nombre: </b> getParseDate </br>
	 * <b>Descripci�n:</b> Firma de m�todo de parseo de textos a fechas</br>
	 * <b>Fecha Creaci�n:</b> 18/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas</br>
	 * <b>Fecha de �ltima Modificaci�n: 19/11/2022 </b></br>
	 * <b>Modificado por:BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @param stringDate
	 * @param dateFormatPattern
	 * @return Date
	 */
	public Date getParseDate(String stringDate, String dateFormatPattern);

}
