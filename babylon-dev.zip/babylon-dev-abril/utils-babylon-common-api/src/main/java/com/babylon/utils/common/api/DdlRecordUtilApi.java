package com.babylon.utils.common.api;

import com.liferay.dynamic.data.lists.model.DDLRecord;

import java.util.List;

import aQute.bnd.annotation.ProviderType;

/**
 * <b>Nombre: </b> DdlRecordUtilApi </br>
 * <b>Descripci�n:</b> </br>
 * <b>Fecha Creaci�n:</b> 5/12/2022 </br>
 * <b>Autor:BABYLON Jose Andr�s S�nchez Bernal </br>
 * <b>Fecha de �ltima Modificaci�n: </b></br>
 * <b>Modificado por: </b></br>
 */
@ProviderType
public interface DdlRecordUtilApi {

	/**
	 * <b>Nombre: </b> getDDlRecords </br>
	 * <b>Descripci�n:</b> Firma m�todo que obtiene una lista dinamic�</br>
	 * <b>Fecha Creaci�n:</b> 5/12/2022 </br>
	 * <b>Autor:BABYLON Jose Andr�s S�nchez Bernal </br>
	 * <b>Fecha de �ltima Modificaci�n: </b></br>
	 * <b>Modificado por: </b></br>
	 * 
	 * @param ddlName
	 * @param companyId
	 * @param groupId
	 * @return List<DDLRecord>
	 * @throws Exception
	 */
	public List<DDLRecord> getDDlRecords(String ddlName, long companyId, long groupId);

}
