package com.babylon.utils.common.api;

import aQute.bnd.annotation.ProviderType;

/**
 * <b>Nombre: </b> EncodeUtil </br>
 * <b>Descripci�n:</b> Interfaz de la firma Api que expone m�todos utilitarios
 * en base al uso de formatos de encode y desencode</br>
 * <b>Fecha Creaci�n:</b> 18/11/2022 </br>
 * <b>Autor:BABYLON Ricardo Salinas </br>
 * <b>Fecha de �ltima Modificaci�n: 19/11/2022 </b></br>
 * <b>Modificado por: </b></br>
 */
@ProviderType
public interface EncodeUtilApi {

	/**
	 * <b>Nombre: </b> encodeBase64 </br>
	 * <b>Descripci�n:</b> Firma m�todo de encode en Base64 </br>
	 * <b>Fecha Creaci�n:</b> 18/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n: 19/11/2022 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @param stringData
	 * @return String
	 */
	public String encodeBase64(String stringData);

	/**
	 * <b>Nombre: </b> decodeBase64 </br>
	 * <b>Descripci�n:</b> Firma m�todo de desencode en Base64 </br>
	 * <b>Fecha Creaci�n:</b> 18/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n: 19/11/2022 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @param base64Data
	 * @return String
	 */
	public String decodeBase64(String base64Data);

	/**
	 * <b>Nombre: </b> encodeToURLEncodedFormat </br>
	 * <b>Descripci�n:</b> Firma m�todo de encode mediante texto</br>
	 * <b>Fecha Creaci�n:</b> 18/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n: 19/11/2022</b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal</b></br>
	 * 
	 * @param encodedString
	 * @return String
	 */
	public String encodeToURLEncodedFormat(String encodedString);

	/**
	 * <b>Nombre: </b> decodeFromURLEncodedFormat </br>
	 * <b>Descripci�n:</b> Firma m�todo de desencode del texto mediante un
	 * formato</br>
	 * <b>Fecha Creaci�n:</b> 18/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n: 19/11/2022 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal</b></br>
	 * 
	 * @param decodeString
	 * @return String
	 */
	public String decodeFromURLEncodedFormat(String decodeString);

	/**
	 * <b>Nombre: </b> generateMD5 </br>
	 * <b>Descripci�n:</b> Firma m�todo de encode el texto mediante algoritmo MD5
	 * </br>
	 * <b>Fecha Creaci�n:</b> 18/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n: 22/11/2022 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal</b></br>
	 * 
	 * @param str
	 * @return String
	 */
	public String generateMD5(String str);

}
