package com.babylon.utils.common.api;

import com.babylon.utils.common.api.exceptions.EncryptionException;

import aQute.bnd.annotation.ProviderType;


/**	<b>Nombre: </b> EncryptionUtil </br>
 * <b>Descripci�n:</b> Interfaz de la firma Api que expone m�todos utilitarios en
 * base al uso de formatos de encriptar y desencriptar</br>
 * <b>Fecha Creaci�n:</b> 18/11/2022 </br>
 * <b>Autor:BABYLON Ricardo Salinas</br>
 * <b>Fecha de �ltima Modificaci�n: 19/11/2022</b></br>
 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
 */
@ProviderType
public interface EncryptionUtilApi {

	/**	<b>Nombre: </b> decrypt </br>
	 * <b>Descripci�n:</b> Firma m�todo de desencriptar</br>
	 * <b>Fecha Creaci�n:</b> 18/11/2022 </br>
	 * <b>Autor:BABYLON Jose Andr�s S�nchez Bernal </br>
	 * <b>Fecha de �ltima Modificaci�n: </b></br>
	 * <b>Modificado por: </b></br>
	 * @param algorithm
	 * @param cipherText
	 * @return
	 * @throws EncryptionException
	 */
	public String decrypt(String algorithm, String cipherText) throws EncryptionException;

	/**	<b>Nombre: </b> encrypt </br>
	 * <b>Descripci�n:</b> Firma m�todo de encriptar  </br>
	 * <b>Fecha Creaci�n:</b> 18/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas</br>
	 * <b>Fecha de �ltima Modificaci�n: 19/11/2022 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal</b></br>
	 * @param algorithm
	 * @param plainText
	 * @return
	 * @throws EncryptionException
	 */
	public String encrypt(String algorithm, String plainText) throws EncryptionException;
}
