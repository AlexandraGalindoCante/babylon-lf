package com.babylon.utils.common.api;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;

import aQute.bnd.annotation.ProviderType;

/**
 * <b>Nombre: </b> LogUtilApi </br>
 * <b>Descripci�n:</b>Interfaz de la firma Api que expone m�todos utilitarios en
 * base al uso de la traza para logs </br>
 * <b>Fecha Creaci�n:</b> 30/11/2022 </br>
 * <b>Autor:BABYLON Jose Andr�s S�nchez Bernal </br>
 * <b>Fecha de �ltima Modificaci�n: </b></br>
 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal</b></br>
 */
@ProviderType
public interface LogUtilApi {

	/**
	 * <b>Nombre: </b> getTrace </br>
	 * <b>Descripci�n:</b>Firma m�todo para registrar las trazas personalizadas
	 * </br>
	 * <b>Fecha Creaci�n:</b> 30/11/2022 </br>
	 * <b>Autor:</b> BABYLON Jose Andr�s S�nchez Bernal </br>
	 * <b>Fecha de �ltima Modificaci�n: </b></br>
	 * <b>Modificado por: User sanchezjosb</b></br>
	 * 
	 * @param log
	 * @param companyId
	 * @throws PortalException
	 */
	public void getTrace(Log log, long companyId) throws PortalException;

	/**
	 * <b>Nombre: </b> getConfig </br>
	 * <b>Descripci�n:</b>Firma m�todo para obtener un UUID </br>
	 * <b>Fecha Creaci�n:</b> 30/11/2022 </br>
	 * <b>Autor:</b> BABYLON Jose Andr�s S�nchez Bernal </br>
	 * <b>Fecha de �ltima Modificaci�n: </b></br>
	 * <b>Modificado por: User sanchezjosb</b></br>
	 * 
	 * @param log
	 * @throws PortalException
	 */
	public void getUuid(Log log) throws PortalException;

}
