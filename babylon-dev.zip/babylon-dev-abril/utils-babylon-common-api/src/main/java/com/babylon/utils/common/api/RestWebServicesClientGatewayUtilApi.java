package com.babylon.utils.common.api;

import com.babylon.utils.common.api.constants.RestWebServiceConstants;
import com.babylon.utils.common.api.constants.RestWebServiceConstants.HttpMethods;
import com.babylon.utils.common.api.exceptions.NoSuchOrganizationIdException;
import com.babylon.utils.common.api.exceptions.RestWebServiceClientException;
import com.babylon.utils.common.api.request.RestWebServiceRequest;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;

import aQute.bnd.annotation.ProviderType;

/**
 * <b>Nombre: </b> RestWebServicesClientGatewayUtil </br>
 * <b>Descripci�n:</b> Interfaz de la firma Api que expone m�todos utilitarios
 * en base al uso de consumo de servicios por Gateway</br>
 * <b>Fecha Creaci�n:</b> 18/11/2022 </br>
 * <b>Autor:BABYLON Ricardo Salinas</br>
 * <b>Fecha de �ltima Modificaci�n: 19/11/2022</b></br>
 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal</b></br>
 */
@ProviderType
public interface RestWebServicesClientGatewayUtilApi {

	/**
	 * <b>Nombre: </b> callService </br>
	 * <b>Descripci�n:</b> Firma m�todo llamado de consumo de servicios Rest por
	 * cualquier m�todo</br>
	 * <b>Fecha Creaci�n:</b> 18/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas</br>
	 * <b>Fecha de �ltima Modificaci�n: 21/11/2022 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @param restWebServiceRequest
	 * @param method
	 * @param logger
	 * @return JSONObject
	 * @throws RestWebServiceClientException, BabylonNoSuchOrganizationIdException
	 */
	public JSONObject callService(RestWebServiceRequest restWebServiceRequest, HttpMethods method, Log logger)
			throws RestWebServiceClientException, NoSuchOrganizationIdException;
	
	/**	<b>Nombre: </b> callService </br>
	 * <b>Descripción:</b> Metodo Provisional mientras pasamos a consumo desde servicios  </br>
	 * <b>Fecha Creación:</b> 2 dic. 2024 </br>
	 * <b>Autor:</b> Luis Alberto Aldana </br>
	 * <b>Fecha de Última Modificación: </b></br>
	 * <b>Modificado por: </b></br>
	 * @param restWebServiceRequest
	 * @param method
	 * @param enableSetOrganizationId
	 * @param logger
	 * @return
	 * @throws RestWebServiceClientException
	 * @throws NoSuchOrganizationIdException
	 */
	public JSONObject callService(RestWebServiceRequest restWebServiceRequest,
			RestWebServiceConstants.HttpMethods method, boolean enableSetOrganizationId, Log logger) throws RestWebServiceClientException, NoSuchOrganizationIdException;

}
