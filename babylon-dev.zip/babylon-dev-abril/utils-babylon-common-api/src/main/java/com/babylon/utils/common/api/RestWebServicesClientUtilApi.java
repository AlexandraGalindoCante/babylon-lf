package com.babylon.utils.common.api;

import com.babylon.utils.common.api.exceptions.NoSuchOrganizationIdException;
import com.babylon.utils.common.api.exceptions.RestWebServiceClientException;
import com.babylon.utils.common.api.request.RestWebServiceRequest;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;

import aQute.bnd.annotation.ProviderType;

/**
 * <b>Nombre: </b> RestWebServicesClientUtil </br>
 * <b>Descripci�n:</b> Interfaz de la firma Api que expone m�todos utilitarios
 * en base al uso de consumo de servicios Rest</br>
 * <b>Fecha Creaci�n:</b> 18/11/2022 </br>
 * <b>Autor:BABYLON Ricardo Salinas</br>
 * <b>Fecha de �ltima Modificaci�n: 19/11/2022 </b></br>
 * <b>Modificado por:BABYLON Jose Andr�s S�nchez Bernal </b></br>
 */
@ProviderType
public interface RestWebServicesClientUtilApi {

	/**
	 * <b>Nombre: </b> callRestServiceByPost </br>
	 * <b>Description:</b> Firma m�todo de consumo de servicios Rest por metodo POST
	 * </br>
	 * <b>Fecha Creaci�n:</b> 18/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n: 19/11/2022</b></br>
	 * <b>Modificado por:BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @param restWebServiceRequest
	 * @param logger
	 * @return JSONObject
	 * @throws RESTWebServiceClientException
	 */
	public JSONObject callRestServiceByPost(RestWebServiceRequest restWebServiceRequest, Log logger)
			throws RestWebServiceClientException, NoSuchOrganizationIdException;

	/**	<b>Nombre: </b> callRestServiceByPost </br>
	 * <b>Descripción:</b> Metodo Provisional mientras pasamos a consumo desde servicios  </br>
	 * <b>Fecha Creación:</b> 2 dic. 2024 </br>
	 * <b>Autor:</b> Luis Alberto Aldana </br>
	 * <b>Fecha de Última Modificación: </b></br>
	 * <b>Modificado por: </b></br>
	 * @param restWebServiceRequest
	 * @param enableSetOrganizationId
	 * @param logger
	 * @return
	 * @throws RestWebServiceClientException
	 * @throws NoSuchOrganizationIdException
	 */
	public JSONObject callRestServiceByPost(RestWebServiceRequest restWebServiceRequest, boolean enableSetOrganizationId , Log logger)
			throws RestWebServiceClientException, NoSuchOrganizationIdException;
	
	/**
	 * <b>Nombre: </b> callRestServiceByGet </br>
	 * <b>Descripci�n:</b> Firma m�todo de consumo de servicios Rest por metodo
	 * GET</br>
	 * <b>Fecha Creaci�n:</b> 18/11/2022 </br>
	 * <b>Autor:BABYLON Jose Andr�s S�nchez Bernal </br>
	 * <b>Fecha de �ltima Modificaci�n: 19/11/2022 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal</b></br>
	 * 
	 * @param restWebServiceRequest
	 * @param logger
	 * @return JSONObject
	 * @throws RESTWebServiceClientException
	 */
	public JSONObject callRestServiceByGet(RestWebServiceRequest restWebServiceRequest, Log logger)
			throws RestWebServiceClientException, NoSuchOrganizationIdException;

	/**
	 * <b>Nombre: </b> callRestServiceByPut </br>
	 * <b>Descripci�n:</b> Firma m�todo de consumo de servicios Rest por metodo
	 * PUT</br>
	 * <b>Fecha Creaci�n:</b> 18/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salina </br>
	 * <b>Fecha de �ltima Modificaci�n: 19/11/2022 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal</b></br>
	 * 
	 * @param restWebServiceRequest
	 * @param logger
	 * @return JSONObject
	 * @throws RESTWebServiceClientException
	 */
	public JSONObject callRestServiceByPut(RestWebServiceRequest restWebServiceRequest, Log logger)
			throws RestWebServiceClientException, NoSuchOrganizationIdException;

	/**
	 * <b>Nombre: </b> callRestServiceByPatch </br>
	 * <b>Descripci�n:</b> Firma m�todo de consumo de servicios Rest por metodo
	 * PATCH</br>
	 * <b>Fecha Creaci�n:</b> 18/11/2022 </br>
	 * <b>Autor:BABYLON Jose Andr�s S�nchez Bernal </br>
	 * <b>Fecha de �ltima Modificaci�n: </b></br>
	 * <b>Modificado por: </b></br>
	 * 
	 * @param restWebServiceRequest
	 * @param logger
	 * @return
	 * @throws RESTWebServiceClientException
	 */
	public JSONObject callRestServiceByPatch(RestWebServiceRequest restWebServiceRequest, Log logger)
			throws RestWebServiceClientException, NoSuchOrganizationIdException;
	
	/**
	 * <b>Nombre: </b> callRestServiceByDelete </br>
	 * <b>Descripci�n:</b> Firma m�todo de consumo de servicios Rest por metodo
	 * DELETE</br>
	 * <b>Fecha Creaci�n:</b> 01/06/2024 </br>
	 * <b>Autor:BABYLON Jose Andr�s S�nchez Bernal </br>
	 * <b>Fecha de �ltima Modificaci�n: </b></br>
	 * <b>Modificado por: </b></br>
	 * 
	 * @param restWebServiceRequest
	 * @param logger
	 * @return
	 * @throws RESTWebServiceClientException
	 */
	public JSONObject callRestServiceByDelete(RestWebServiceRequest restWebServiceRequest, Log logger)
			throws RestWebServiceClientException, NoSuchOrganizationIdException;


}
