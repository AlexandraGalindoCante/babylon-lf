package com.babylon.utils.common.api;

import com.babylon.utils.common.api.model.ValidatorRulesDto;
import com.liferay.portal.kernel.json.JSONObject;

import aQute.bnd.annotation.ProviderType;

/**
 * <b>Nombre: </b> ValidatorUtilApi </br>
 * <b>Descripci�n:</b> Interfaz de la firma Api que expone m�todo para validar
 * los campos de entrada</br>
 * <b>Fecha Creaci�n:</b> 30/11/2022 </br>
 * <b>Autor:BABYLON Jose Andr�s S�nchez Bernal </br>
 * <b>Fecha de �ltima Modificaci�n: </b></br>
 * <b>Modificado por: </b></br>
 */
@ProviderType
public interface ValidatorUtilApi {

	/**
	 * <b>Nombre: </b> validateAttribute </br>
	 * <b>Descripci�n:</b> Firma m�todo para validar parametros de cualquier tipo
	 * </br>
	 * <b>Fecha Creaci�n:</b> 30/11/2022 </br>
	 * <b>Autor:BABYLON Jose Andr�s S�nchez Bernal </br>
	 * <b>Fecha de �ltima Modificaci�n: </b></br>
	 * <b>Modificado por: </b></br>
	 * 
	 * @param value
	 * @param validatorRulesDto
	 * @return
	 */
	public boolean validateAttributeAction(ValidatorRulesDto validatorRulesDto, String value, String message,
			JSONObject response);
}
