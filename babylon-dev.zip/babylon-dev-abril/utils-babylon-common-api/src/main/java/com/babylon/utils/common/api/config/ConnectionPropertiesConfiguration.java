package com.babylon.utils.common.api.config;

import aQute.bnd.annotation.metatype.Meta;

import com.babylon.utils.categories.api.constants.BabylonCategoriesUtilsConstants;
import com.babylon.utils.common.api.constants.BabylonCommonUtilsConstants;
import com.liferay.portal.configuration.metatype.annotations.ExtendedObjectClassDefinition;
import com.liferay.portal.configuration.metatype.annotations.ExtendedObjectClassDefinition.Scope;

/**
 * <b>Nombre: </b> ConnectionPropertiesConfiguration </br>
 * <b>Descripci�n:</b> Clase de configuraci�n de propiedades </br>
 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
 * <b>Autor:BABYLON Ricardo Salinas </br>
 * <b>Fecha de �ltima Modificaci�n: 13/01/2023 </b></br>
 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
 */
@ExtendedObjectClassDefinition(category = BabylonCategoriesUtilsConstants.KEY_NAMELANGUAGE_CATEGORY_CONFIG_GENERAL, scope = Scope.SYSTEM)
@Meta.OCD(id = BabylonCommonUtilsConstants.KEY_METAOCD_ID_CONNECTION_PROPERTIES, localization = BabylonCommonUtilsConstants.KEY_UTILS_CONTENT_LANGUAGE, name = BabylonCommonUtilsConstants.KEY_NAMELANGUAGE_CONFIG_CONNECTION_PROPERTIES)
public interface ConnectionPropertiesConfiguration {
	/**
	 * <b>Nombre: </b> proxyHostname </br>
	 * <b>Descripci�n:</b> M�todo de configuraci�n donde se embebe la configuraci�n
	 * de proxy (hostname)</br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas</br>
	 * <b>Fecha de �ltima Modificaci�n: 13/01/2023 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @return
	 */
	@Meta.AD(deflt = BabylonCommonUtilsConstants.DEFAULT_VALUE_CONNECTION_PROPERTIES_HOSTNAME, name = BabylonCommonUtilsConstants.KEY_NAMELANGUAGE_PROPERTIES_CONNECTION_HOSTNAME, required = false)
	public String proxyHostname();

	/**
	 * <b>Nombre: </b> proxyPort </br>
	 * <b>Descripci�n:</b> M�todo de configuraci�n donde se embebe la configuraci�n
	 * del puerto de proxy</br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n: 13/01/2023 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @return
	 */
	@Meta.AD(deflt = BabylonCommonUtilsConstants.DEFAULT_VALUE_CONNECTION_PROPERTIES_PORT, name = BabylonCommonUtilsConstants.KEY_NAMELANGUAGE_PROPERTIES_CONNECTION_PORT, required = false)
	public int proxyPort();

	/**
	 * <b>Nombre: </b> connectTimeout </br>
	 * <b>Descripci�n:</b> M�todo de configuraci�n donde se define la configuraci�n
	 * del tiempo para definir un timeOut en respuesta</br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n: 13/01/2023 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @return
	 */
	@Meta.AD(deflt = BabylonCommonUtilsConstants.DEFAULT_VALUE_CONNECTION_PROPERTIES_TIMEOUT, name = BabylonCommonUtilsConstants.KEY_NAMELANGUAGE_PROPERTIES_CONNECTION_TIMEOUT, required = false)
	public int connectTimeout();

	/**
	 * <b>Nombre: </b> connectionRequestTimeout </br>
	 * <b>Descripci�n:</b> M�todo de configuraci�n donde se define la configuraci�n
	 * del tiempo para definir un timeOut en conexi�n</br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Jose Andr�s S�nchez Bernal </br>
	 * <b>Fecha de �ltima Modificaci�n: 13/01/2023 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @return
	 */
	@Meta.AD(deflt = BabylonCommonUtilsConstants.DEFAULT_VALUE_CONNECTION_PROPERTIES_TIMEOUT_REQUEST, name = BabylonCommonUtilsConstants.KEY_NAMELANGUAGE_PROPERTIES_CONNECTION_TIMEOUT_REQUEST, required = false)
	public int connectionRequestTimeout();

	/**
	 * <b>Nombre: </b> socketTimeout </br>
	 * <b>Descripci�n:</b> M�todo de configuraci�n donde se define la configuraci�n
	 * del tiempo para definir el socket en timeOut</br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Jose Andr�s S�nchez Bernal </br>
	 * <b>Fecha de �ltima Modificaci�n: 13/01/2023 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @return
	 */
	@Meta.AD(deflt = BabylonCommonUtilsConstants.DEFAULT_VALUE_CONNECTION_PROPERTIES_SOCKET_TIMEOUT, name = BabylonCommonUtilsConstants.KEY_NAMELANGUAGE_PROPERTIES_CONNECTION_TIMEOUT_SOCKET, required = false)
	public int socketTimeout();
}
