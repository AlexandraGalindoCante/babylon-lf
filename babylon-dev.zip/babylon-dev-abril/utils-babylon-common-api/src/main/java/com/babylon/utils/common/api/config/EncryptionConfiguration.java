package com.babylon.utils.common.api.config;

import com.babylon.utils.categories.api.constants.BabylonCategoriesUtilsConstants;
import com.babylon.utils.common.api.constants.BabylonCommonUtilsConstants;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.configuration.metatype.annotations.ExtendedObjectClassDefinition;
import com.liferay.portal.configuration.metatype.annotations.ExtendedObjectClassDefinition.Scope;

import aQute.bnd.annotation.metatype.Meta;

/**
 * <b>Nombre: </b> EncryptionConfiguration </br>
 * <b>Descripci�n:</b> Clase de configuraci�n de encriptaci�n </br>
 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
 * <b>Autor:BABYLON Jose Andr�s S�nchez Bernal </br>
 * <b>Fecha de �ltima Modificaci�n: 13/01/2023 </b></br>
 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
 * 
 */
@ExtendedObjectClassDefinition(category = BabylonCategoriesUtilsConstants.KEY_NAMELANGUAGE_CATEGORY_CONFIG_ENCRYPTION, scope = Scope.SYSTEM)
@Meta.OCD(id = BabylonCommonUtilsConstants.KEY_METAOCD_ID_ENCRYPTION, localization = BabylonCommonUtilsConstants.KEY_UTILS_CONTENT_LANGUAGE, name = BabylonCommonUtilsConstants.KEY_NAMELANGUAGE_CONFIG_ENCRYPTION)
public interface EncryptionConfiguration {

	/**
	 * <b>Nombre: </b> encryptionResourcesPath </br>
	 * <b>Descripci�n:</b>M�todo de configuraci�n que define la ruta de recuursos de
	 * encriptaci�n </br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas</br>
	 * <b>Fecha de �ltima Modificaci�n: 13/01/2023 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @return
	 */
	@Meta.AD(deflt = StringPool.BLANK, name = BabylonCommonUtilsConstants.KEY_NAME_PROPERTIES_ENCRYPTION_PATH_RESOURCES, required = false)
	public String encryptionResourcesPath();

	/**
	 * <b>Nombre: </b> rsaPublicKeyPath </br>
	 * <b>Descripci�n:</b> M�todo de configuraci�n que define llave publica
	 * algoritmo RSA </br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas</br>
	 * <b>Fecha de �ltima Modificaci�n: 13/01/2023 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @return
	 */
	@Meta.AD(deflt = StringPool.BLANK, name = BabylonCommonUtilsConstants.KEY_NAME_PROPERTIES_ENCRYPTION_PATH_RSA_PUBLICKEY, required = false)
	public String rsaPublicKeyPath();

	/**
	 * <b>Nombre: </b> rsaPrivateKeyPath </br>
	 * <b>Descripci�n:</b> M�todo de configuraci�n que define llave privada
	 * algoritmo RSA </br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n: 13/01/2023 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @return
	 */
	@Meta.AD(deflt = StringPool.BLANK, name = BabylonCommonUtilsConstants.KEY_NAME_PROPERTIES_ENCRYPTION_PATH_RSA_PRIVATEKEY, required = false)
	public String rsaPrivateKeyPath();

	/**
	 * <b>Nombre: </b> aes256SecretKeyPath </br>
	 * <b>Descripci�n:</b> M�todo de configuraci�n que define la ruta de la llave
	 * privada algoritmo AES256 </br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Jose Andr�s S�nchez Bernal </br>
	 * <b>Fecha de �ltima Modificaci�n: 13/01/2023 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @return
	 */
	@Meta.AD(deflt = StringPool.BLANK, name = BabylonCommonUtilsConstants.KEY_NAME_PROPERTIES_ENCRYPTION_PATH_AES256_PRIVATEKEY, required = false)
	public String aes256SecretKeyPath();

	/**
	 * <b>Nombre: </b> rsaAlgorithm </br>
	 * <b>Descripci�n:</b> M�todo de configuraci�n que define el nombre del
	 * algoritmo RSA</br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n: 13/01/2023 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @return
	 */
	@Meta.AD(deflt = BabylonCommonUtilsConstants.DEFAULT_VALUE_ENCRYPTION_RSA_ALGORITHM, name = BabylonCommonUtilsConstants.KEY_NAME_PROPERTIES_ENCRYPTION_ALGORITHM_RSA, required = false)
	public String rsaAlgorithm();

	/**
	 * <b>Nombre: </b> aes256Algorithm </br>
	 * <b>Descripci�n:</b> M�todo de configuraci�n que define el nombre del
	 * algoritmo AES256</br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n: 13/01/2023 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @return
	 */
	@Meta.AD(deflt = BabylonCommonUtilsConstants.DEFAULT_VALUE_ENCRYPTION_AES256_ALGORITHM, name = BabylonCommonUtilsConstants.KEY_NAME_PROPERTIES_ENCRYPTION_ALGORITHM_AES256, required = false)
	public String aes256Algorithm();

	/**
	 * <b>Nombre: </b> aes256Iv </br>
	 * <b>Descripci�n:</b> M�todo de configuraci�n que define el nombre del
	 * algoritmo AES265Iv</br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n: 13/01/2023 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @return
	 */
	@Meta.AD(deflt = BabylonCommonUtilsConstants.DEFAULT_VALUE_ENCRYPTION_AES256IV_ALGORITHM, name = BabylonCommonUtilsConstants.KEY_NAME_PROPERTIES_ENCRYPTION_ALGORITHM_AES256IV, required = false)
	public String aes256Iv();

}
