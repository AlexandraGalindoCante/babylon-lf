package com.babylon.utils.common.api.config;

import aQute.bnd.annotation.metatype.Meta;

import com.babylon.utils.categories.api.constants.BabylonCategoriesUtilsConstants;
import com.babylon.utils.common.api.constants.BabylonCommonUtilsConstants;
import com.babylon.utils.common.api.constants.RestWebServiceConstants;
import com.liferay.portal.configuration.metatype.annotations.ExtendedObjectClassDefinition;
import com.liferay.portal.configuration.metatype.annotations.ExtendedObjectClassDefinition.Scope;

/**
 * <b>Nombre: </b> GatewayAuthorizationConfiguration </br>
 * <b>Descripci�n:</b> Clase de configuraci�n de propiedades</br>
 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
 * <b>Autor:BABYLON Jose Andr�s S�nchez Bernal </br>
 * <b>Fecha de �ltima Modificaci�n: </b></br>
 * <b>Modificado por: 13/01/2022 </b></br>
 */
@ExtendedObjectClassDefinition(category = BabylonCategoriesUtilsConstants.KEY_NAMELANGUAGE_CATEGORY_CONFIG_GENERAL, scope = Scope.SYSTEM)
@Meta.OCD(id = BabylonCommonUtilsConstants.KEY_METAOCD_ID_GATEWAY, localization = BabylonCommonUtilsConstants.KEY_UTILS_CONTENT_LANGUAGE, name = BabylonCommonUtilsConstants.KEY_NAMELANGUAGE_CONFIG_GATEWAY)
public interface GatewayAuthorizationConfiguration {

	/**
	 * <b>Nombre: </b> authorizationType </br>
	 * <b>Descripci�n:</b> Clase de configuraci�n de autorizaci�n </br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Jose Andr�s S�nchez Bernal </br>
	 * <b>Fecha de �ltima Modificaci�n: 13/01/2023 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @return
	 */
	@Meta.AD(name = BabylonCommonUtilsConstants.KEY_NAMELANGUAGE_PROPERTIES_GATEWAY_AUTH_TYPE, deflt = RestWebServiceConstants.KEY_UTILS_AUTHORIZATION_OAUTH_2, optionLabels = {
			BabylonCommonUtilsConstants.DEFAULT_VALUE_GATEWAY_AUTHORIZATION_TYPE }, optionValues = {
					RestWebServiceConstants.KEY_UTILS_AUTHORIZATION_OAUTH_2 }, required = false)
	public String authorizationType();

	/**
	 * <b>Nombre: </b> grantType </br>
	 * <b>Descripci�n:</b> M�todo de configuraci�n donde se define el valor
	 * predeterminado del parametro grandType</br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * 
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n: 13/01/2023 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @return
	 */
	@Meta.AD(name = BabylonCommonUtilsConstants.KEY_NAMELANGUAGE_PROPERTIES_GATEWAY_AUTH_GRANTTYPE, deflt = BabylonCommonUtilsConstants.DEFAULT_VALUE_GATEWAY_AUTHORIZATION_GRANTTYPE, optionLabels = {
			BabylonCommonUtilsConstants.KEY_UTILS_CLIENT_CREDENTIALS,
			BabylonCommonUtilsConstants.KEY_UTILS_PASS_CREDENTIALS,
			BabylonCommonUtilsConstants.KEY_UTILS_AUTHORIZATION_CODE,  BabylonCommonUtilsConstants.KEY_UTILS_IMPLICIT }, optionValues = {
					BabylonCommonUtilsConstants.KEY_UTILS_CLIENT_CREDENTIALS,
					BabylonCommonUtilsConstants.KEY_UTILS_PASS, BabylonCommonUtilsConstants.KEY_UTILS_IMPLICIT,
					BabylonCommonUtilsConstants.KEY_UTILS_AUTHORIZATION_CODE }, required = false)
	public String grantType();

	/**
	 * <b>Nombre: </b> accessTokenURL </br>
	 * <b>Descripci�n:</b> M�todo de configuraci�n donde se define el valor
	 * predeterminado del parametro accessTokenURL</br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n: 13/01/2023 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @return
	 */
	@Meta.AD(name = BabylonCommonUtilsConstants.KEY_NAMELANGUAGE_PROPERTIES_GATEWAY_AUTH_ACCESSTOKEN, deflt = BabylonCommonUtilsConstants.DEFAULT_VALUE_GATEWAY_AUTHORIZATION_ACCESSTOKEN, required = false)
	public String accessTokenURL();

	/**
	 * <b>Nombre: </b> scope </br>
	 * <b>Descripci�n:</b> M�todo de configuraci�n donde se define el valor
	 * predeterminado del parametro scope</br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n: 13/01/2023 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @return
	 */
	@Meta.AD(name = BabylonCommonUtilsConstants.KEY_NAMELANGUAGE_PROPERTIES_GATEWAY_AUTH_SCOPE, deflt = BabylonCommonUtilsConstants.DEFAULT_VALUE_GATEWAY_AUTHORIZATION_SCOPE, required = false)
	public String scope();

	/**
	 * <b>Nombre: </b> usesProxy </br>
	 * <b>Descripci�n:</b> M�todo de configuraci�n donde se define el valor
	 * predeterminado del parametro usesProxy, si contiene o no</br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n: 13/01/2023 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @return
	 */
	@Meta.AD(name = BabylonCommonUtilsConstants.KEY_NAMELANGUAGE_PROPERTIES_GATEWAY_AUTH_USESPROXY, deflt = BabylonCommonUtilsConstants.DEFAULT_VALUE_GATEWAY_AUTHORIZATION_USESPROXY, required = false)
	public boolean usesProxy();
}
