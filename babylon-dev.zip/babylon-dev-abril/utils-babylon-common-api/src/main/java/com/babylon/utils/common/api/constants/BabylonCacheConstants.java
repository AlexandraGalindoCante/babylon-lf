package com.babylon.utils.common.api.constants;

public class BabylonCacheConstants {
    private BabylonCacheConstants() {
    }

    public static final String PARTNER_CACHE = "PARTNER-CACHE";
    public static final String BONUS_TYPE_CACHE = "BONUS-TYPE-CACHE";
    public static final String BUSINESS_TYPE_CACHE = "BUSINESS-TYPE-CACHE";
    public static final String FINANCIAL_PRODUCT_CACHE = "FINANCIAL-PRODUCT-CACHE";
    public static final String PRODUCT_TYPE_CACHE = "PRODUCT-TYPE-CACHE";
    public static final String COUNTRY_CACHE = "COUNTRY-CACHE";
}
