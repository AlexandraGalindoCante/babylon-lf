package com.babylon.utils.common.api.constants;

import java.util.regex.Pattern;

/**
 * <b>Nombre: </b> BabylonCommonUtilsConstants </br>
 * <b>Descripci�n:</b> Clase de constantes para el proyecto utilitario y su
 * logica de negocio </br>
 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
 * <b>Autor:BABYLON Ricardo Salina </br>
 * <b>Fecha de �ltima Modificaci�n: 13/01/2023 </b></br>
 * <b>Modificado por:BABYLON Jose Andr�s S�nchez Bernal </b></br>
 */
public class BabylonCommonUtilsConstants {

	/**
	 * <b>Nombre: </b> BabylonCommonUtilsConstants </br>
	 * <b>Descripci�n:</b> Constructor </br>
	 * <b>Fecha Creaci�n:</b> 13/01/2023 </br>
	 * <b>Autor:BABYLON Jose Andr�s S�nchez Bernal </br>
	 * <b>Fecha de �ltima Modificaci�n: </b></br>
	 * <b>Modificado por: </b></br>
	 * 
	 * @return
	 */
	private BabylonCommonUtilsConstants() {
	}

	public static class System {
		public static final Long USER_ID =20123L;
	}

	// Keys Language.properties
	public static final String KEY_NAMELANGUAGE_CONFIG_CONNECTION_PROPERTIES = "key_name_config_connection_properties";
	public static final String KEY_NAMELANGUAGE_CONFIG_GATEWAY = "key_name_config_gateway";
	public static final String KEY_NAMELANGUAGE_CONFIG_ENCRYPTION = "key_name_config_encryption";

	public static final String KEY_NAMELANGUAGE_PROPERTIES_CONNECTION_HOSTNAME = "key_name_properties_connection_hostname";
	public static final String KEY_NAMELANGUAGE_PROPERTIES_CONNECTION_PORT = "key_name_properties_connection_port";
	public static final String KEY_NAMELANGUAGE_PROPERTIES_CONNECTION_TIMEOUT = "key_name_properties_connection_timeout";
	public static final String KEY_NAMELANGUAGE_PROPERTIES_CONNECTION_TIMEOUT_REQUEST = "key_name_properties_connection_timeout_request";
	public static final String KEY_NAMELANGUAGE_PROPERTIES_CONNECTION_TIMEOUT_SOCKET = "key_name_properties_connection_timeout_socket";

	public static final String KEY_NAMELANGUAGE_PROPERTIES_GATEWAY_AUTH_TYPE = "key_name_properties_gateway_auth_type";
	public static final String KEY_NAMELANGUAGE_PROPERTIES_GATEWAY_AUTH_ACCESSTOKEN = "key_name_properties_gateway_auth_accesstoken";
	public static final String KEY_NAMELANGUAGE_PROPERTIES_GATEWAY_AUTH_SCOPE = "key_name_properties_gateway_auth_scope";
	public static final String KEY_NAMELANGUAGE_PROPERTIES_GATEWAY_AUTH_GRANTTYPE = "key_name_properties_gateway_auth_grantype";
	public static final String KEY_NAMELANGUAGE_PROPERTIES_GATEWAY_AUTH_USESPROXY = "key_name_properties_gateway_auth_usesproxy";

	public static final String KEY_NAME_PROPERTIES_ENCRYPTION_PATH_RESOURCES = "key_name_properties_encryption_path_resources";
	public static final String KEY_NAME_PROPERTIES_ENCRYPTION_PATH_RSA_PUBLICKEY = "key_name_properties_encryption_path_rsa_publickey";
	public static final String KEY_NAME_PROPERTIES_ENCRYPTION_PATH_RSA_PRIVATEKEY = "key_name_properties_encryption_path_rsa_privatekey";
	public static final String KEY_NAME_PROPERTIES_ENCRYPTION_PATH_AES256_PRIVATEKEY = "key_name_properties_encryption_path_aes256_privatekey";
	public static final String KEY_NAME_PROPERTIES_ENCRYPTION_ALGORITHM_RSA = "key_name_properties_encryption_algorithm_rsa";
	public static final String KEY_NAME_PROPERTIES_ENCRYPTION_ALGORITHM_AES256 = "key_name_properties_encryption_algorithm_aes256";
	public static final String KEY_NAME_PROPERTIES_ENCRYPTION_ALGORITHM_AES256IV = "key_name_properties_encryption_algorithm_aes256iv";


	// Keys Constants
	public static final String KEY_NAME_PROPERTIES_UTIL_RSA = "RSA";
	public static final String KEY_NAME_PROPERTIES_UTIL_AES = "AES";
	public static final int KEY_NUM_PROPERTIES_UTIL_MILLISECONDS_BY_SECOND = 1000;

	public static final String KEY_METAOCD_ID_CONNECTION_PROPERTIES = "com.babylon.utils.common.api.config.ConnectionPropertiesConfiguration";
	public static final String KEY_METAOCD_ID_ENCRYPTION = "com.babylon.utils.common.api.config.EncryptionConfiguration";
	public static final String KEY_METAOCD_ID_GATEWAY = "com.babylon.utils.common.api.config.GatewayAuthorizationConfiguration";

	public static final String KEY_NAME_COMPONENT_AUTH_VERIFIER_PROPERTY = "auth.verifier.guest.allowed=false";
	public static final String KEY_NAME_COMPONENT_ECOSYSTEM_LOCALIZATION = "javax.portlet.resource-bundle=content.Language";

	public static final String KEY_UTILS_CONTENT_LANGUAGE = "content/Language";
	public static final String KEY_UTILS_CLIENT_CREDENTIALS = "Client Credentials";
	public static final String KEY_UTILS_PASS_CREDENTIALS = "Password Credentials";
	public static final String KEY_UTILS_IMPLICIT = "Implicit";
	public static final String KEY_UTILS_AUTHORIZATION_CODE = "Authorization Code";
	public static final String KEY_UTILS_PASS = "password";
	public static final String KEY_UTILS_HOSTNAME = "hostName";
	public static final String KEY_UTILS_UUID_TR = "uuid";
	public static final String KEY_UTILS_ERROR = "error";
	public static final String KEY_UTILS_MESSAGE = "message";
	public static final String KEY_UTILS_BODY = "body";
	public static final String KEY_UTILS_SHOW = "show";
	public static final String KEY_UTILS_ID = "id";
	public static final String KEY_UTILS_COVERAGEID = "coverageId";
	public static final String KEY_UTILS_TYPEID = "typeId";
	public static final String KEY_UTILS_QUESTIONID = "questionId";
	public static final String KEY_UTILS_PARENTID = "parentId";
	public static final String KEY_UTILS_MODELID = "modelId";
	public static final String KEY_UTILS_COMPROGRAMID = "commercialProgramId";
	public static final String KEY_UTILS_VEHICLEID = "vehicleId";
	public static final String KEY_UTILS_CODE = "code";
	public static final String KEY_UTILS_NAME = "name";
	public static final String KEY_UTILS_STATUS = "status";
	public static final String KEY_UTILS_STATE = "state";
	public static final String KEY_UTILS_COMPANYID = "companyId";
	public static final String KEY_UTILS_GROUPID = "groupId";

	public static final String KEY_UTILS_XML_CLOSE = "<%";
	public static final String KEY_UTILS_XML_OPEN = "%>";
	public static final String KEY_UTILS_ORGANIZATIONID = "OrganizationId";
	
	public static final int NEW_REGISTER = 1;
	public static final int UPDATE_REGISTER = 2;
	public static final int EXIST_REGISTER = 3;

	public static final String KEY_JAXRS_CATEGORY_INFOBIP = "=WsInfobipApi.Rest";
	public static final String KEY_JAXRS_CATEGORY_NEQUI = "=WsNequiApi.Rest";
	public static final String KEY_JAXRS_CATEGORY_INSTAFIT = "=WsInstafitApi.Rest";
	public static final String KEY_JAXRS_CATEGORY_MASIV = "=WsMasivApi.Rest";
	public static final String KEY_JAXRS_CATEGORY_GOOGLE = "=WsGoogleApi.Rest";
	public static final String KEY_JAXRS_CATEGORY_TRANSUNION = "=WsTransunionApi.Rest";
	public static final String KEY_JAXRS_CATEGORY_BUSINESS_PRODUCT = "=WsBusinessProductApi.Rest";
	public static final String KEY_JAXRS_CATEGORY_BUSINESS_PLAN = "=WsBusinessPlanApi.Rest";
	public static final String KEY_JAXRS_CATEGORY_BUSINESS_COMISSION = "=WsBusinessComissionApi.Rest";
	public static final String KEY_JAXRS_CATEGORY_SESSION = "=WsSessionApi.Rest";

	// Services WS Business
	public static final String KEY_JAXRS_PATH_BUSINESS_PRODUCT = "=/babylon/business/product";
	public static final String KEY_JAXRS_PATH_BUSINESS_PLAN = "=/babylon/business/plan";
	public static final String KEY_JAXRS_PATH_BUSINESS_COMISSION = "=/babylon/business/comission";
	public static final String KEY_JAXRS_PATH_SESSION = "=/babylon/session";

	// Services WS
	public static final String KEY_JAXRS_PATH_GOOGLE = "=/babylon/google";
	public static final String KEY_JAXRS_PATH_INFOBIP = "=/babylon/infobip";
	public static final String KEY_JAXRS_PATH_NEQUI = "=/babylon/infobip";
	public static final String KEY_JAXRS_PATH_INSTAFIT = "=/babylon/infobip";
	public static final String KEY_JAXRS_PATH_MASIV = "=/babylon/masiv";
	public static final String KEY_JAXRS_PATH_TRANSUNION = "=/babylon/transunion";
	
	// INFOBIP
	public static final String KEY_ERROR_SEND_OTP = "errorSendOtp";
	public static final String KEY_EMAIL = "eMail";
	public static final String KEY_PHONE_NUMBER = "phoneNumber";
	

	public static final String KEY_VALIDATOR_NAMES_REGEXP = "^([a-zA-Z����������]+[+\\s]*)+$";
	public static final String KEY_VALIDATOR_DATE_REGEXP1 = "^([0-2][0-9]||3[0-1])-(0[0-9]||1[0-2])-([0-9][0-9])?[0-9][0-9]$"; // dd-mm-yyyy
	public static final String KEY_VALIDATOR_DATE_REGEXP2 = "^([0-2][0-9]||3[0-1])/(0[0-9]||1[0-2])/([0-9][0-9])?[0-9][0-9]$"; // dd/mm/yyyy
	public static final String KEY_VALIDATOR_DATE_REGEXP3 = "^(0[0-9]||1[0-2])-([0-2][0-9]||3[0-1])-([0-9][0-9])?[0-9][0-9]$"; // mm-dd-yyyy
	public static final String KEY_VALIDATOR_DATE_REGEXP4 = "^(0[0-9]||1[0-2])/([0-2][0-9]||3[0-1])/([0-9][0-9])?[0-9][0-9]$"; // mm/dd/yyyy
	public static final String KEY_VALIDATOR_DATE_REGEXP5 = "^\\d{4}\\-(0?[1-9]|1[012])\\-(0?[1-9]|[12][0-9]|3[01])$"; // yyyy-mm-dd
	public static final String KEY_VALIDATOR_DATE_REGEXP8 = "^([0-2][0-9]|3[01])/(0[1-9]|1[0-2])/\\d{4}$";
	public static final String KEY_VALIDATOR_DATE_FORMAT1 = "dd-mm-yyyy";
	public static final String KEY_VALIDATOR_DATE_FORMAT2 = "dd/mm/yyyy";
	public static final String KEY_VALIDATOR_DATE_FORMAT3 = "mm-dd-yyyy";
	public static final String KEY_VALIDATOR_DATE_FORMAT4 = "mm/dd/yyyy";
	public static final String KEY_VALIDATOR_DATE_FORMAT5 = "yyyy-mm-dd";
	public static final String KEY_VALIDATOR_DATE_FORMAT6 = "MM/dd/yyyy";
	public static final String KEY_VALIDATOR_DATE_FORMAT7 = "yyyy-MM-dd";
	public static final String KEY_VALIDATOR_DATE_FORMAT8 = "dd/MM/yyyy";
	public static final Pattern DECIMAL_4_PATTERN = Pattern.compile("^\\d+(\\.\\d{1,4})?$");

	public static final String DEFAULT_VALUE_MESSAGE_SUCCESS = "Success";
	public static final String DEFAULT_VALUE_MESSAGE_INTERNALERROR = "Error internal application, please contact your administrator ";
	public static final String DEFAULT_VALUE_MESSAGE_NOTFOUNDERROR = "Error, not found ";
	public static final String DEFAULT_VALUE_MESSAGE_GENERALERROR = "Error general application, please contact your administrator ";

	public static final String DEFAULT_MESSAGE_EXCEPTION_LOG_MESSAGE = "RESTWebServicesClient Exception --> ";
	public static final String DEFAULT_MESSAGE_EXCEPTION_LOG_MESSAGE_OPENGET = "Execute consumption by GET";
	public static final String DEFAULT_MESSAGE_EXCEPTION_LOG_MESSAGE_CLOSEGET = "Closing connection by GET";
	public static final String DEFAULT_MESSAGE_EXCEPTION_LOG_MESSAGE_OPENPOST = "Execute consumption by POST";
	public static final String DEFAULT_MESSAGE_EXCEPTION_LOG_MESSAGE_CLOSEPOST = "Closing connection by POST";
	public static final String DEFAULT_MESSAGE_EXCEPTION_LOG_MESSAGE_OPENPATCH = "Execute consumption by PATCH";
	public static final String DEFAULT_MESSAGE_EXCEPTION_LOG_MESSAGE_CLOSEPATCH = "Closing connection by PATCH";

	public static final String DEFAULT_MESSAGE_EXCEPTION_LOG_MESSAGE_USER = "The obj User not found";
	public static final String DEFAULT_MESSAGE_EXCEPTION_LOG_MESSAGE_CUSTOMFIELD_ORGANIZATIONID = "The User not have a customField OrganizationId";
	public static final String DEFAULT_MESSAGE_EXCEPTION_LOG_MESSAGE_VALUE_ORGANIZATIONID = "The customField OrganizationId not have a value";
	
	public static final String DEFAULT_VALUE_CONNECTION_PROPERTIES_HOSTNAME = "ncproxy1";
	public static final String DEFAULT_VALUE_CONNECTION_PROPERTIES_PORT = "8080";
	public static final String DEFAULT_VALUE_CONNECTION_PROPERTIES_TIMEOUT = "10";
	public static final String DEFAULT_VALUE_CONNECTION_PROPERTIES_TIMEOUT_REQUEST = "5";
	public static final String DEFAULT_VALUE_CONNECTION_PROPERTIES_SOCKET_TIMEOUT = "40";

	public static final String DEFAULT_VALUE_ENCRYPTION_RSA_ALGORITHM = "RSA/ECB/PKCS1Padding";
	public static final String DEFAULT_VALUE_ENCRYPTION_AES256_ALGORITHM = "AES/CBC/PKCS5Padding";
	public static final String DEFAULT_VALUE_ENCRYPTION_AES256IV_ALGORITHM = "Yzog3Ljz90zSz+fbu43SsQ==";

	public static final String DEFAULT_VALUE_GATEWAY_AUTHORIZATION_TYPE = "OAuth 2.0";
	public static final String DEFAULT_VALUE_GATEWAY_AUTHORIZATION_GRANTTYPE = "client_credentials";
	public static final String DEFAULT_VALUE_GATEWAY_AUTHORIZATION_ACCESSTOKEN = "https://api-services-uat.babylonnet.com/CO/UAT/customer/v1/authorization_customer";
	public static final String DEFAULT_VALUE_GATEWAY_AUTHORIZATION_SCOPE = "Bearer";
	public static final String DEFAULT_VALUE_GATEWAY_AUTHORIZATION_USESPROXY = "true";

	public static final long DEFAULT_VALUE_STATUS_SUCCESS = 200;
	public static final long DEFAULT_VALUE_STATUS_CREATED = 201;
	public static final long DEFAULT_VALUE_STATUS_NOTFOUND_SUCCESS = 204;	
	public static final long DEFAULT_VALUE_STATUS_NOTFOUNDERROR = 404;
	public static final long DEFAULT_VALUE_STATUS_INTERNALERROR = 400;
	public static final long DEFAULT_VALUE_STATUS_GENERALERROR = 500;


	public static class Response {
		/**
		 * AD: keys para control de errores
		 */
		public static final Integer STATUS_SUCCESS = 200;
		public static final Integer CREATE_SUCCESS = 201;
		public static final Integer DELETE_SUCCESS = 204;
		public static final Integer STATUS_INTERNAL_ERROR = 500;
		public static final Integer BAD_REQUEST = 400;
		public static final Integer STATUS_UNAUTHORIZED = 401;
		public static final Integer STATUS_FORBIDDEN = 403;
		public static final Integer REQUEST_CONFLICT = 409;
		public static final String MESSAGE_INTERNAL_ERROR = "error-message-internal-error";
		public static final String MESSAGE_BAD_REQUEST = "error-message-bad-request";
		public static final String MESSAGE_SUCCESS = "saved-successfully";
		public static final String FILE_ALREADY_EXISTS = "file-already-exists";
		public static final String PRODUCT_ALREADY_EXISTS = "product-already-exists";

	}

	public  static class State {
		public static final String DELETED =  "deleted";
		public static final String ACTIVE = "active";
		public static final String INACTIVE ="inactive";
	}

	public static class DocumentLibrary {

		public static final String PREFIX_FRIENDLY_URL = "/documents/d/global/";

	}


	public static final String CATEGORY_CONFIG_SERVICES = "key_name_category_config_services";
}