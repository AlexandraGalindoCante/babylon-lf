package com.babylon.utils.common.api.constants;

/**
 * <b>Nombre: </b> RestWebServiceConstants </br>
 * <b>Descripción:</b> Clase de constantes para los servicios y su logica de
 * negocio </br>
 * <b>Fecha Creación:</b> 22/11/2022 </br>
 * <b>Autor:BABYLON Ricardo Salinas</br>
 * <b>Fecha de última Modificación: 22/11/2022 </b></br>
 * <b>Modificado por: BABYLON Jose Andrés Sánchez Bernal</b></br>
 */
public class RestWebServiceConstants {

	private RestWebServiceConstants() {
	}

	public static final String KEY_UTILS_ACCEPT = "Accept";
	public static final String KEY_UTILS_CONTENT_TYPE = "Content-type";
	public static final String KEY_UTILS_USER = "X-User";
	public static final String KEY_UTILS_ORGANIZATION_ID = "X-Organization-ID";
	public static final String KEY_UTILS_RESULT = "result";
	public static final String KEY_UTILS_AUTHORIZATION = "Authorization";
	public static final String KEY_UTILS_AUTHORIZATION2 = "authorization";
	public static final String KEY_UTILS_X_API_KEY = "x-api-key";
	public static final String KEY_UTILS_ACCEPT_ALL = "*/*";
	public static final String KEY_UTILS_BASIC_AUTHORIZATION = "Basic ";
	public static final String KEY_UTILS_ACCESS_TOKEN = "access_token";
	public static final String KEY_UTILS_GRANT_TYPE = "grant_type";
	public static final String KEY_UTILS_SCOPE = "scope";
	public static final String KEY_UTILS_BODY_RESPONSE = "bodyResponse";
	public static final String KEY_UTILS_AUTHORIZATION_OAUTH_2 = "OAauth2";
	public static final String KEY_UTILS_AUTHORIZATION_BASIC_AUTHENTICATION = "BasicAuthentication";
	public static final String KEY_UTILS_AUTHORIZATION_API_KEY = "ApiKey";
	public static final String KEY_UTILS_CLIENT_CREDENTIALS = "client_credentials";
	public static final String KEY_UTILS_APPLICATION_URLENCODED = "application/x-www-form-urlencoded";
	public static final String KEY_UTILS_APPLICATION_JSON = "application/json";
	public static final String JSON_PROCESSING_ERROR = "JSON format error.";

	
	public enum HttpMethods {
		GET, POST, PUT, DELETE, PATCH
	}
}
