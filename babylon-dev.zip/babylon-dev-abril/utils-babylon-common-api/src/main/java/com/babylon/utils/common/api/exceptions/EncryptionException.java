package com.babylon.utils.common.api.exceptions;

import com.liferay.petra.string.StringPool;

/**
 * <b>Nombre: </b> EncryptionException </br>
 * <b>Descripci�n:</b> Clase de la firma Api que expone m�todos de excepciones
 * de apis encriptadas</br>
 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
 * <b>Autor:BABYLON Ricardo Salinas</br>
 * <b>Fecha de �ltima Modificaci�n: 22/11/2022 </b></br>
 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
 */
public class EncryptionException extends Exception {

	private static final long serialVersionUID = 1L;
	private String errorMessage;
	private String exceptionType;

	/**
	 * <b>Nombre: </b> EncryptionException </br>
	 * <b>Descripci�n:</b> Firma m�todo llamado para generar la Excepci�n controlado
	 * en los m�todos de api en Encryption </br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n: 22/11/2022 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @param errorMessage
	 * @param exceptionType
	 */
	public EncryptionException(String errorMessage, String exceptionType) {
		super(exceptionType.concat(StringPool.SPACE).concat(":: ").concat(errorMessage));
		this.errorMessage = errorMessage;
		this.exceptionType = exceptionType;
	}

	/**
	 * <b>Nombre: </b> getErrorMessage </br>
	 * <b>Descripci�n:</b> Firma m�todo llamado para obtener el mensaje de la
	 * excepci�n controlada en los m�todos de api en Encryption </br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n: 22/11/2022 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @return String
	 */
	public String getErrorMessage() {
		return errorMessage;
	}

	/**
	 * <b>Nombre: </b> setErrorMessage </br>
	 * <b>Descripci�n:</b> Firma m�todo llamado para setear el mensaje de la
	 * excepci�n controlada en los m�todos de api en Encryption </br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n: 22/11/2022 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @param errorMessage
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	/**
	 * <b>Nombre: </b> getExceptionType </br>
	 * <b>Descripci�n:</b> Firma m�todo llamado para obtener el tipo de excepci�n
	 * controlada en los m�todos de api en Encryption </br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas</br>
	 * <b>Fecha de �ltima Modificaci�n: 22/11/2022</b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @return String
	 */
	public String getExceptionType() {
		return exceptionType;
	}

	/**
	 * <b>Nombre: </b> setExceptionType </br>
	 * <b>Descripci�n:</b> Firma m�todo llamado para setear el tipo de excepci�n
	 * controlada en los m�todos de api en Encryption </br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n: 22/11/2022 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @param exceptionType
	 */
	public void setExceptionType(String exceptionType) {
		this.exceptionType = exceptionType;
	}

	/**
	 * <b>Nombre: </b> getSerialversionuid </br>
	 * <b>Descripci�n:</b> Firma m�todo llamado para obtener el id serial de la
	 * clase Encryption </br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n: 22/11/2022 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @return long
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
