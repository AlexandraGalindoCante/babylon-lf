package com.babylon.utils.common.api.exceptions;

import com.liferay.petra.string.StringPool;


public class NoSuchOrganizationIdException extends Exception {

	private static final long serialVersionUID = 1L;
	private String errorMessage;
	private String exceptionType;

	public NoSuchOrganizationIdException(){
		super();
	}

	public NoSuchOrganizationIdException(String errorMessage, String exceptionType) {
		super(exceptionType.concat(StringPool.SPACE).concat(":: ").concat(errorMessage));
		this.errorMessage = errorMessage;
		this.exceptionType = exceptionType;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getExceptionType() {
		return exceptionType;
	}

	public void setExceptionType(String exceptionType) {
		this.exceptionType = exceptionType;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
