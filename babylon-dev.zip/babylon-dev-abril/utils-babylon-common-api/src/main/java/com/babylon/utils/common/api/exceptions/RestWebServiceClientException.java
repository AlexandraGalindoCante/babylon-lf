package com.babylon.utils.common.api.exceptions;

/**
 * <b>Nombre: </b> RestWebServiceClientException </br>
 * <b>Descripci�n:</b> Clase de la firma Api que expone las excepciones
 * controladas de los m�todos de uso Rest </b> <b>Fecha Creaci�n:</b> 22/11/2022
 * </br>
 * <b>Autor:BABYLON Ricardo Salinas </br>
 * <b>Fecha de �ltima Modificaci�n: 22/11/2022 </b></br>
 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
 */
public class RestWebServiceClientException extends Exception {

	private static final long serialVersionUID = 1L;
	private int statusCode;
	private String errorMessage;
	private String response;

	/**
	 * <b>Nombre: </b> RestWebServiceClientException </br>
	 * <b>Descripci�n:</b>Constructor de la clase</br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n:22/11/2022 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 */
	public RestWebServiceClientException() {
		super();
	}

	/**
	 * <b>Nombre: </b> RestWebServiceClientException </br>
	 * <b>Descripci�n:</b>Firma m�todo llamado de la excepci�n controlada para las
	 * apis con uso de servicios Rest</br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n: 22/11/2022</b></br>
	 * <b>Modificado por:BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @param statusCode
	 * @param errorMessage
	 */
	public RestWebServiceClientException(int statusCode, String errorMessage) {
		super(errorMessage);
		this.statusCode = statusCode;
		this.errorMessage = errorMessage;
	}

	/**
	 * <b>Nombre: </b> RestWebServiceClientException </br>
	 * <b>Descripci�n:</b> Firma m�todo llamado de la excepci�n controlada para las
	 * apis con uso de servicios Rest con response</br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n: 22/11/2022</b></br>
	 * <b>Modificado por:BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @param statusCode
	 * @param errorMessage
	 * @param response
	 */
	public RestWebServiceClientException(int statusCode, String errorMessage, String response) {
		super();
		this.statusCode = statusCode;
		this.errorMessage = errorMessage;
		this.response = response;
	}

	/**
	 * <b>Nombre: </b> getStatusCode </br>
	 * <b>Descripci�n:</b> Firma m�todo llamado del status para obtener el
	 * c�digo</br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas</br>
	 * <b>Fecha de �ltima Modificaci�n:22/11/2022 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @return
	 */
	public int getStatusCode() {
		return statusCode;
	}

	/**
	 * <b>Nombre: </b> setStatusCode </br>
	 * <b>Descripci�n:</b> Firma m�todo llamado del status para setear el
	 * c�digo</br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas</br>
	 * <b>Fecha de �ltima Modificaci�n:22/11/2022 </b></br>
	 * <b>Modificado por:BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @param statusCode
	 */
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

	/**
	 * <b>Nombre: </b> getErrorMessage </br>
	 * <b>Descripci�n:</b> Firma m�todo llamado de exceciones controladas para
	 * obtener el mensaje de error</br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Jose Andr�s S�nchez Bernal </br>
	 * <b>Fecha de �ltima Modificaci�n:22/11/2022 </b></br>
	 * <b>Modificado por:BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @return
	 */
	public String getErrorMessage() {
		return errorMessage;
	}

	/**
	 * <b>Nombre: </b> setErrorMessage </br>
	 * <b>Descripci�n:</b> Firma m�todo llamado de exceciones controladas para
	 * obtener el mensaje de error</br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n: 22/11/2022</b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @param errorMessage
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	/**
	 * <b>Nombre: </b> getResponse </br>
	 * <b>Descripci�n:</b>Firma m�todo llamado de exceciones controladas para
	 * obtener el response</br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas</br>
	 * <b>Fecha de �ltima Modificaci�n:22/11/2022 </b></br>
	 * <b>Modificado por:BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @return
	 */
	public String getResponse() {
		return response;
	}

	/**
	 * <b>Nombre: </b> setResponse </br>
	 * <b>Descripci�n:</b>Firma m�todo llamado de exceciones controladas para setear
	 * el response </br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n:22/11/2022 </b></br>
	 * <b>Modificado por:BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @param response
	 */
	public void setResponse(String response) {
		this.response = response;
	}

	/**
	 * <b>Nombre: </b> toString </br>
	 * <b>Descripci�n:</b> </br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n: 22/11/2022</b></br>
	 * <b>Modificado por:BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @return
	 */
	@Override
	public String toString() {
		StringBuilder toString = new StringBuilder();
		toString.append("Error message: ");
		toString.append(errorMessage);
		toString.append(" Status code: ");
		toString.append(statusCode);
		toString.append(" Response: ");
		toString.append(response);
		return toString.toString();
	}
}
