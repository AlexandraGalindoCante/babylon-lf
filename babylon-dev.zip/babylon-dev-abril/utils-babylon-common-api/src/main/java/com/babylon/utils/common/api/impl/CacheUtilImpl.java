package com.babylon.utils.common.api.impl;

import com.babylon.utils.common.api.CacheUtilApi;
import com.liferay.portal.kernel.cache.PortalCache;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import org.osgi.service.component.annotations.Component;

import javax.lang.model.element.Element;
import java.io.Serializable;
import java.util.List;
import java.util.stream.Collectors;

@Component(
        service = CacheUtilApi.class
)
public class CacheUtilImpl implements CacheUtilApi {

    private static final Log LOGGER = LogFactoryUtil.getLog(CacheUtilImpl.class);

    @Override
    public String getKey(List<Serializable> args, String cacheName) {
        return args.stream().map(Serializable::toString).collect(Collectors.joining("-")) + cacheName;
    }

    @Override
    public <K extends Serializable> K get (PortalCache<String, K> cache, String key){
        if(LOGGER.isDebugEnabled()){
            LOGGER.debug("getElementFromCache [cache = " + cache.getPortalCacheName() + ", key = " + key + "]");
        }
        return cache.get(key);
    }

    @Override
    public <K extends Serializable> boolean put(PortalCache<String, K> cache, String key, K element) {
        try{
            if(LOGGER.isDebugEnabled()){
                LOGGER.debug("putElementInCache [cache = " + cache.getPortalCacheName() + ", key = " + key + "]");
            }
            cache.put(key, element);
            return true;
        }catch (Exception e){
            LOGGER.error("Error putElementInCache [" + key + "]",e);
            return false;
        }
    }


}
