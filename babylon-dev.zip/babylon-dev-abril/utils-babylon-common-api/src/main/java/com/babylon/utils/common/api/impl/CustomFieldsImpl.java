package com.babylon.utils.common.api.impl;

import com.babylon.utils.common.api.CustomFieldsApi;
import com.babylon.utils.common.api.constants.BabylonCommonUtilsConstants;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.util.Validator;

import org.osgi.service.component.annotations.Component;

/**
 * <b>Nombre: </b> CustomFieldsImpl </br>
 * <b>Descripci�n:</b> Clase de implementaci�n que expone m�todos para
 * validar los parametros</br>
 * <b>Fecha Creaci�n:</b> 17/10/2024 </br>
 * <b>Autor:BABYLON Jose Andr�s S�nchez Bernal </br>
 * <b>Fecha de �ltima Modificaci�n: </b></br>
 * <b>Modificado por: </b></br>
 */
@Component(service = CustomFieldsApi.class)
public class CustomFieldsImpl implements CustomFieldsApi {

	/**
	 * <b>Nombre: </b> validateAttributeAction </br>
	 * <b>Descripci�n:</b> </br>
	 * <b>Fecha Creaci�n:</b> 17/10/2024 </br>
	 * <b>Autor:BABYLON Jose Andr�s S�nchez Bernal </br>
	 * <b>Fecha de �ltima Modificaci�n: </b></br>
	 * <b>Modificado por: </b></br>
	 * 
	 * @param validatorRulesDto
	 * @param value
	 * @param message
	 * @param response
	 * @return
	 */
	@Override
	public JSONObject getOrganizationIdByUser(User user) {
		JSONObject response = JSONFactoryUtil.createJSONObject();
		long organizationId = 0;
		if (Validator.isNull(user)) {
			setResultToResponse(BabylonCommonUtilsConstants.DEFAULT_MESSAGE_EXCEPTION_LOG_MESSAGE_USER, response);
		}
		if (!user.getExpandoBridge().hasAttribute(BabylonCommonUtilsConstants.KEY_UTILS_ORGANIZATIONID)) {
			setResultToResponse(
					BabylonCommonUtilsConstants.DEFAULT_MESSAGE_EXCEPTION_LOG_MESSAGE_CUSTOMFIELD_ORGANIZATIONID,
					response);
		}
		organizationId = (long) user.getExpandoBridge()
				.getAttribute(BabylonCommonUtilsConstants.KEY_UTILS_ORGANIZATIONID);
		if (Validator.isNull(organizationId)) {
			setResultToResponse(BabylonCommonUtilsConstants.DEFAULT_MESSAGE_EXCEPTION_LOG_MESSAGE_USER, response);
		}else {
			response.put(BabylonCommonUtilsConstants.KEY_UTILS_ERROR, Boolean.FALSE);
			response.put(BabylonCommonUtilsConstants.KEY_UTILS_SHOW, Boolean.FALSE);
			response.put(BabylonCommonUtilsConstants.KEY_UTILS_MESSAGE, BabylonCommonUtilsConstants.DEFAULT_VALUE_MESSAGE_SUCCESS);
			response.put(BabylonCommonUtilsConstants.KEY_UTILS_ORGANIZATIONID, organizationId);
		}

		return response;
	}

	/**
	 * <b>Nombre: </b> setResultToResponse </br>
	 * <b>Descripci�n:</b> </br>
	 * <b>Fecha Creaci�n:</b> 17/10/2024 </br>
	 * <b>Autor:BABYLON Jose Andr�s S�nchez Bernal </br>
	 * <b>Fecha de �ltima Modificaci�n: </b></br>
	 * <b>Modificado por: </b></br>
	 * 
	 * @param message
	 * @param response
	 */
	private static void setResultToResponse(String message, JSONObject response) {
		response.put(BabylonCommonUtilsConstants.KEY_UTILS_ERROR, Boolean.TRUE);
		response.put(BabylonCommonUtilsConstants.KEY_UTILS_SHOW, Boolean.TRUE);
		response.put(BabylonCommonUtilsConstants.KEY_UTILS_MESSAGE, message);
	}
}
