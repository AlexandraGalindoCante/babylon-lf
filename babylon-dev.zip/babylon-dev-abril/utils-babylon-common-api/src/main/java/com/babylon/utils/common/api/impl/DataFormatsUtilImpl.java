package com.babylon.utils.common.api.impl;

import com.babylon.utils.common.api.DataFormatsUtilApi;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.osgi.service.component.annotations.Component;

/**
 * <b>Nombre: </b> DataFormatsUtilImpl </br>
 * <b>Descripci�n:</b>Clase de implementaci�n que expone m�todos utilitarios en
 * base al uso de formatos de fechas </br>
 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
 * <b>Autor:BABYLON Ricardo Salinas </br>
 * <b>Fecha de �ltima Modificaci�n: 22/11/2022 </b></br>
 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
 */
@Component(service = DataFormatsUtilApi.class)
public class DataFormatsUtilImpl implements DataFormatsUtilApi {

	private static final Log logger = LogFactoryUtil.getLog(DataFormatsUtilImpl.class);

	/**
	 * <b>Nombre: </b> getFormatDate </br>
	 * <b>Descripci�n:</b> Implementaci�n del m�todo de formato de fechas </br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Jose Andr�s S�nchez Bernal </br>
	 * <b>Fecha de �ltima Modificaci�n: 22/11/2022 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal</b></br>
	 * 
	 * @param date
	 * @param dateFormatPattern
	 * @return String
	 */
	@Override
	public String getFormatDate(Date date, String dateFormatPattern) {
		try {
			DateFormat dateFormat = new SimpleDateFormat(dateFormatPattern);
			return dateFormat.format(date);
		} catch (Exception e) {
			logger.error(
					"Error format date:" + date + ", Pattern:" + dateFormatPattern + " Exception:" + e.getMessage());
			return StringPool.BLANK;
		}
	}

	/**
	 * <b>Nombre: </b> getParseDate </br>
	 * <b>Descripci�n:</b> Implementaci�n del m�todo de parseo de textos a
	 * fechas</br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n: 22/11/2022 </b></br>
	 * <b>Modificado por:BABYLON Jose Andr�s S�nchez Bernal</b></br>
	 * 
	 * @param stringDate
	 * @param dateFormatPattern
	 * @return Date
	 */
	@Override
	public Date getParseDate(String stringDate, String dateFormatPattern) {
		try {
			DateFormat dateFormat = new SimpleDateFormat(dateFormatPattern);
			return dateFormat.parse(stringDate);
		} catch (ParseException e) {
			logger.error("Error parse date:" + stringDate + ", Pattern:" + dateFormatPattern + " Exception:"
					+ e.getMessage());
			return null;
		}
	}
}
