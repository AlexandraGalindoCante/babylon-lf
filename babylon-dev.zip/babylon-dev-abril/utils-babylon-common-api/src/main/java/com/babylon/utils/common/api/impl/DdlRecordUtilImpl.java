package com.babylon.utils.common.api.impl;

import com.babylon.utils.common.api.DdlRecordUtilApi;
import com.babylon.utils.common.api.constants.BabylonCommonUtilsConstants;
import com.liferay.dynamic.data.lists.model.DDLRecord;
import com.liferay.dynamic.data.lists.model.DDLRecordSet;
import com.liferay.dynamic.data.lists.service.DDLRecordLocalServiceUtil;
import com.liferay.dynamic.data.lists.service.DDLRecordSetLocalServiceUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.PropertyFactoryUtil;
import com.liferay.portal.kernel.dao.orm.RestrictionsFactoryUtil;

import java.util.List;

import org.osgi.service.component.annotations.Component;

/**
 * <b>Nombre: </b> DdlRecordUtilImpl </br>
 * <b>Descripci�n:</b> Clase de implementaci�n que expone m�todos utilitarios en
 * base al uso de listas dinamicas</br>
 * <b>Fecha Creaci�n:</b> 5/12/2022 </br>
 * <b>Autor:BABYLON Jose Andr�s S�nchez Bernal </br>
 * <b>Fecha de �ltima Modificaci�n: </b></br>
 * <b>Modificado por: </b></br>
 */
@Component(service = DdlRecordUtilApi.class)
public class DdlRecordUtilImpl implements DdlRecordUtilApi {

	/**
	 * <b>Nombre: </b> getDDlRecords </br>
	 * <b>Descripci�n:</b> M�todo que consulta una lista dinamica segun su intancia
	 * y sitio en donde se encuentre</br>
	 * <b>Fecha Creaci�n:</b> 5/12/2022 </br>
	 * <b>Autor:BABYLON Jose Andr�s S�nchez Bernal </br>
	 * <b>Fecha de �ltima Modificaci�n: </b></br>
	 * <b>Modificado por: </b></br>
	 * 
	 * @param ddlName
	 * @param companyId
	 * @param groupId
	 * @return List<DDLRecord>
	 * @throws Exception
	 */
	@Override
	public List<DDLRecord> getDDlRecords(String ddlName, long companyId, long groupId) {
		DynamicQuery dq = DDLRecordSetLocalServiceUtil.dynamicQuery();
		dq.add(PropertyFactoryUtil.forName(BabylonCommonUtilsConstants.KEY_UTILS_COMPANYID).eq(companyId));
		if (groupId != 0) {
			dq.add(RestrictionsFactoryUtil.eq(BabylonCommonUtilsConstants.KEY_UTILS_GROUPID, groupId));
		}
		dq.add(RestrictionsFactoryUtil.like(BabylonCommonUtilsConstants.KEY_UTILS_NAME,
				BabylonCommonUtilsConstants.KEY_UTILS_XML_OPEN + ddlName + BabylonCommonUtilsConstants.KEY_UTILS_XML_CLOSE));
		List<DDLRecordSet> recordSet = DDLRecordSetLocalServiceUtil.dynamicQuery(dq);
		return DDLRecordLocalServiceUtil.getRecords(recordSet.get(0).getRecordSetId());
	}
}
