package com.babylon.utils.common.api.impl;

import com.babylon.utils.common.api.EncodeUtilApi;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;

import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.apache.commons.codec.binary.Base64;
import org.osgi.service.component.annotations.Component;

/**
 * <b>Nombre: </b> EncodeUtilImpl </br>
 * <b>Descripci�n:</b> Clase de la implementaci�n que expone m�todos utilitarios
 * en base al uso de formatos de encode y desencode</br>
 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
 * <b>Autor:BABYLON Ricardo Salinas </br>
 * <b>Fecha de �ltima Modificaci�n: 22/11/2022 </b></br>
 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal</b></br>
 */
@Component(service = EncodeUtilApi.class)
public class EncodeUtilImpl implements EncodeUtilApi {

	private static Log logger = LogFactoryUtil.getLog(EncodeUtilImpl.class);

	/**
	 * <b>Nombre: </b> encodeBase64 </br>
	 * <b>Descripci�n:</b M�todo de implementaci�n de encode en Base64 </br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n: 22/11/2022 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @param stringData
	 * @return String
	 */
	@Override
	public String encodeBase64(String stringData) {
		return new String(Base64.encodeBase64(stringData.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
	}

	/**
	 * <b>Nombre: </b> decodeBase64 </br>
	 * <b>Descripci�n:</b> M�todo de implementaci�n de desencode en Base64 </br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n:22/11/2022 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal</b></br>
	 * 
	 * @param base64Data
	 * @return String
	 */
	@Override
	public String decodeBase64(String base64Data) {
		return new String(Base64.decodeBase64(base64Data.getBytes(StandardCharsets.UTF_8)));
	}

	/**
	 * <b>Nombre: </b> encodeToURLEncodedFormat </br>
	 * <b>Descripci�n:</b>M�todo de implementaci�n de encode mediante texto</br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n: </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal</b></br>
	 * 
	 * @param encodedString
	 * @return String
	 */
	@Override
	public String encodeToURLEncodedFormat(String encodedString) {
		try {
			return URLEncoder.encode(encodedString, StandardCharsets.UTF_8.displayName());
		} catch (UnsupportedEncodingException e) {
			logger.error("Error encode to URL encoded format: " + e.getMessage());
			return StringPool.BLANK;
		}
	}

	/**
	 * <b>Nombre: </b> decodeFromURLEncodedFormat </br>
	 * <b>Descripci�n:</b> M�todo de implementaci�n de desencode del texto mediante
	 * un formato</br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n: </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal</b></br>
	 * 
	 * @param decodeString
	 * @return String
	 */
	@Override
	public String decodeFromURLEncodedFormat(String decodeString) {
		try {
			return URLDecoder.decode(decodeString, StandardCharsets.UTF_8.displayName());
		} catch (UnsupportedEncodingException e) {
			logger.error("Error decode from URL encoded format: " + e.getMessage());
			return StringPool.BLANK;
		}
	}

	/**
	 * <b>Nombre: </b> generateMD5 </br>
	 * <b>Descripci�n:</b> M�todo de implementaci�n de encode el texto mediante
	 * algoritmo MD5 </br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n: 22/11/2022</b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @param str
	 * @return String
	 */
	@Override
	public String generateMD5(String str) {
		try {
			MessageDigest md5 = MessageDigest.getInstance("MD5");
			md5.update(StandardCharsets.UTF_8.encode(str));
			return String.format("%032x", new BigInteger(1, md5.digest()));
		} catch (NoSuchAlgorithmException e) {
			logger.error("Error generateMD5: " + e.getMessage() + " ");
			return StringPool.BLANK;
		}
	}
}