package com.babylon.utils.common.api.impl;

import com.babylon.utils.common.api.EncryptionUtilApi;
import com.babylon.utils.common.api.config.EncryptionConfiguration;
import com.babylon.utils.common.api.constants.BabylonCommonUtilsConstants;
import com.babylon.utils.common.api.exceptions.EncryptionException;
import com.liferay.portal.configuration.metatype.bnd.util.ConfigurableUtil;

import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;

/**
 * <b>Nombre: </b> EncryptionUtilImpl </br>
 * <b>Descripci�n:</b>Clase Implementaci�n de la Api que expone m�todos
 * utilitarios en base al uso de formatos de encriptar y desencriptar</br>
 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
 * <b>Autor:BABYLON Jose Andr�s S�nchez Bernal </br>
 * <b>Fecha de �ltima Modificaci�n: 13/01/2023 </b></br>
 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
 */
@Component(configurationPid = "babylon.common.utils.config.EncryptionConfiguration", immediate = true, service = EncryptionUtilApi.class)
public class EncryptionUtilImpl implements EncryptionUtilApi {

	private volatile EncryptionConfiguration config;

	/**
	 * <b>Nombre: </b> decrypt </br>
	 * <b>Descripci�n:</b>Implementaci�n del m�todo que desencripta algoritmos RSA y
	 * AES </br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas</br>
	 * <b>Fecha de �ltima Modificaci�n: 13/01/2023 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @param algorithm
	 * @param cipherText
	 * @return String
	 * @throws EncryptionException
	 */
	@Override
	public String decrypt(String algorithm, String cipherText) throws EncryptionException {
		try {
			switch (algorithm) {
			case BabylonCommonUtilsConstants.KEY_NAME_PROPERTIES_UTIL_RSA:
				return decryptByRSA(cipherText);
			case BabylonCommonUtilsConstants.KEY_NAME_PROPERTIES_UTIL_AES:
				return decryptByAES256(cipherText);
			default:
				throw new EncryptionException(algorithm.concat(": Algorithm is not defined to encrypt"),
						getClass().getName());
			}
		} catch (InvalidKeyException | InvalidKeySpecException | NoSuchAlgorithmException | NoSuchPaddingException
				| IllegalBlockSizeException | BadPaddingException | IOException
				| InvalidAlgorithmParameterException e) {
			throw new EncryptionException(e.getMessage(), e.getClass().getName());

		}
	}

	/**
	 * <b>Nombre: </b> encrypt </br>
	 * <b>Descripci�n:</b> Implmentaci�n m�todo que encripta algoritmos de tipo RSA
	 * y AES</br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n: 13/01/2023 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @param algorithm
	 * @param plainText
	 * @return String
	 * @throws EncryptionException
	 */
	@Override
	public String encrypt(String algorithm, String plainText) throws EncryptionException {

		try {
			switch (algorithm) {
			case BabylonCommonUtilsConstants.KEY_NAME_PROPERTIES_UTIL_RSA:
				return encryptByRSA(plainText);
			case BabylonCommonUtilsConstants.KEY_NAME_PROPERTIES_UTIL_AES:
				return encryptByAES256(plainText);
			default:
				throw new EncryptionException(algorithm.concat(": Algorithm is not defined to encrypt"),
						getClass().getName());
			}
		} catch (InvalidKeyException | InvalidKeySpecException | NoSuchAlgorithmException | NoSuchPaddingException
				| IllegalBlockSizeException | BadPaddingException | IOException
				| InvalidAlgorithmParameterException e) {
			throw new EncryptionException(e.getMessage(), e.getClass().getName());

		}
	}

	/**
	 * <b>Nombre: </b> encryptByRSA </br>
	 * <b>Descripci�n:</b> Implementaci�n del m�todo que encripta exclusivamente
	 * algoritmos RSA </br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n: 13/01/2023 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @param plainText
	 * @return String
	 * @throws InvalidKeyException
	 * @throws InvalidKeySpecException
	 * @throws NoSuchAlgorithmException
	 * @throws IOException
	 * @throws NoSuchPaddingException
	 * @throws IllegalBlockSizeException
	 * @throws BadPaddingException
	 */
	private String encryptByRSA(String plainText)
			throws InvalidKeyException, InvalidKeySpecException, NoSuchAlgorithmException, IOException,
			NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException {
		Cipher cipher = Cipher.getInstance(config.rsaAlgorithm());
		cipher.init(Cipher.ENCRYPT_MODE, getPublicKey());
		String strToEncryptResult = Base64.getEncoder()
				.encodeToString(cipher.doFinal(plainText.getBytes(StandardCharsets.UTF_8)));
		return strToEncryptResult;
	}

	/**
	 * <b>Nombre: </b> decryptByRSA </br>
	 * <b>Descripci�n:</b> Implementaci�n del m�todo que desencripta exclusivamente
	 * algoritmos RSA </br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n: 13/01/2023 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @param cipherText
	 * @return String
	 * @throws NoSuchAlgorithmException
	 * @throws NoSuchPaddingException
	 * @throws InvalidKeyException
	 * @throws InvalidKeySpecException
	 * @throws IOException
	 * @throws IllegalBlockSizeException
	 * @throws BadPaddingException
	 */
	private String decryptByRSA(String cipherText) throws NoSuchAlgorithmException, NoSuchPaddingException,
			InvalidKeyException, InvalidKeySpecException, IOException, IllegalBlockSizeException, BadPaddingException {
		Cipher cipher = Cipher.getInstance(config.rsaAlgorithm());
		cipher.init(Cipher.DECRYPT_MODE, getPrivateKey());
		return new String(cipher.doFinal(Base64.getDecoder().decode(cipherText)), StandardCharsets.UTF_8);
	}

	/**
	 * <b>Nombre: </b> encryptByAES256 </br>
	 * <b>Descripci�n:</b>Implementaci�n del m�todo que encripta exclusivamente
	 * algoritmos AES256 </br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n: 13/01/2023 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @param plainText
	 * @return String
	 * @throws NoSuchAlgorithmException
	 * @throws NoSuchPaddingException
	 * @throws InvalidKeyException
	 * @throws InvalidAlgorithmParameterException
	 * @throws InvalidKeySpecException
	 * @throws IllegalBlockSizeException
	 * @throws BadPaddingException
	 * @throws IOException
	 */
	private String encryptByAES256(String plainText) throws NoSuchAlgorithmException, NoSuchPaddingException,
			InvalidKeyException, InvalidAlgorithmParameterException, InvalidKeySpecException, IllegalBlockSizeException,
			BadPaddingException, IOException {
		Cipher cipher = Cipher.getInstance(config.aes256Algorithm());
		cipher.init(Cipher.ENCRYPT_MODE, getAESSecretKey(), getAES256Iv());
		return Base64.getEncoder().encodeToString(cipher.doFinal(plainText.getBytes()));
	}

	/**
	 * <b>Nombre: </b> decryptByAES256 </br>
	 * <b>Descripci�n:</b> Implementaci�n del m�todo que desencripta exclusivamente
	 * algoritmos AES256</br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n: 13/01/2023 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @param cipherText
	 * @return String
	 * @throws NoSuchAlgorithmException
	 * @throws NoSuchPaddingException
	 * @throws InvalidKeyException
	 * @throws InvalidAlgorithmParameterException
	 * @throws InvalidKeySpecException
	 * @throws IllegalBlockSizeException
	 * @throws BadPaddingException
	 * @throws IOException
	 */
	private String decryptByAES256(String cipherText) throws NoSuchAlgorithmException, NoSuchPaddingException,
			InvalidKeyException, InvalidAlgorithmParameterException, InvalidKeySpecException, IllegalBlockSizeException,
			BadPaddingException, IOException {
		Cipher cipher = Cipher.getInstance(config.aes256Algorithm());
		cipher.init(Cipher.DECRYPT_MODE, getAESSecretKey(), getAES256Iv());
		return new String(cipher.doFinal(Base64.getDecoder().decode(cipherText)));
	}

	/**
	 * <b>Nombre: </b> getPrivateKey </br>
	 * <b>Descripci�n:</b>Implementaci�n del m�todo que obtienela key privada
	 * exclusivamente algoritmos RSA</br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas</br>
	 * <b>Fecha de �ltima Modificaci�n: 13/01/2023 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @return PrivateKey
	 * @throws IOException
	 * @throws NoSuchAlgorithmException
	 * @throws InvalidKeySpecException
	 */
	private PrivateKey getPrivateKey() throws IOException, NoSuchAlgorithmException, InvalidKeySpecException {
		byte[] bytes = Files
				.readAllBytes(Paths.get(config.encryptionResourcesPath().concat(config.rsaPrivateKeyPath())));
		PKCS8EncodedKeySpec ks = new PKCS8EncodedKeySpec(bytes);
		KeyFactory kf = KeyFactory.getInstance(BabylonCommonUtilsConstants.KEY_NAME_PROPERTIES_UTIL_RSA);
		return kf.generatePrivate(ks);
	}

	/**
	 * <b>Nombre: </b> getPublicKey </br>
	 * <b>Descripci�n:</b>Implementaci�n del m�todo que obtienela key publica
	 * exclusivamente algoritmos RSA </br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n: 13/01/2023 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @return PublicKey
	 * @throws IOException
	 * @throws InvalidKeySpecException
	 * @throws NoSuchAlgorithmException
	 */
	private PublicKey getPublicKey() throws IOException, InvalidKeySpecException, NoSuchAlgorithmException {
		byte[] bytes = Files
				.readAllBytes(Paths.get(config.encryptionResourcesPath().concat(config.rsaPublicKeyPath())));
		X509EncodedKeySpec ks = new X509EncodedKeySpec(bytes);
		KeyFactory kf = KeyFactory.getInstance(BabylonCommonUtilsConstants.KEY_NAME_PROPERTIES_UTIL_RSA);
		return kf.generatePublic(ks);
	}

	/**
	 * <b>Nombre: </b> getAESSecretKey </br>
	 * <b>Descripci�n:</b> Implementaci�n del m�todo que obtiene la key privada
	 * exclusivamente algoritmos AES256 </br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas</br>
	 * <b>Fecha de �ltima Modificaci�n: 13/01/2023 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @return SecretKeySpec
	 * @throws IOException
	 * @throws NoSuchAlgorithmException
	 * @throws NoSuchPaddingException
	 * @throws InvalidKeyException
	 * @throws InvalidKeySpecException
	 * @throws IllegalBlockSizeException
	 * @throws BadPaddingException
	 */
	private SecretKeySpec getAESSecretKey() throws IOException, NoSuchAlgorithmException, NoSuchPaddingException,
			InvalidKeyException, InvalidKeySpecException, IllegalBlockSizeException, BadPaddingException {
		Cipher cipher = Cipher.getInstance(config.rsaAlgorithm());
		cipher.init(Cipher.DECRYPT_MODE, getPrivateKey());
		return new SecretKeySpec(
				cipher.doFinal(Files.readAllBytes(
						Paths.get(config.encryptionResourcesPath().concat(config.aes256SecretKeyPath())))),
				BabylonCommonUtilsConstants.KEY_NAME_PROPERTIES_UTIL_AES);
	}

	/**
	 * <b>Nombre: </b> createAES256SecretKey </br>
	 * <b>Descripci�n:</b> Implementaci�n del m�todo que crea la key publica
	 * exclusivamente algoritmos AES256 </br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n: 13/01/2023 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @param secretKeyFileName
	 * @throws NoSuchAlgorithmException
	 * @throws InvalidKeySpecException
	 * @throws IOException
	 * @throws NoSuchPaddingException
	 * @throws InvalidKeyException
	 * @throws IllegalBlockSizeException
	 * @throws BadPaddingException
	 */
	public void createAES256SecretKey(String secretKeyFileName)
			throws NoSuchAlgorithmException, InvalidKeySpecException, IOException, NoSuchPaddingException,
			InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
		FileOutputStream out = new FileOutputStream(config.encryptionResourcesPath().concat(secretKeyFileName));
		Cipher cipher = Cipher.getInstance(config.rsaAlgorithm());
		cipher.init(Cipher.ENCRYPT_MODE, getPublicKey());
		SecretKey key = generateKey(256);
		out.write(cipher.doFinal(key.getEncoded()));
		out.close();
	}

	/**
	 * <b>Nombre: </b> generateAES256Iv </br>
	 * <b>Descripci�n:</b> Implementaci�n del m�todo que crea la keyexclusivamente
	 * algoritmos AES256Iv </br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n: 13/01/2023 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @return String
	 */
	public String generateAES256Iv() {
		byte[] iv = new byte[128 / 8];
		new SecureRandom().nextBytes(iv);
		return Base64.getEncoder().encodeToString(iv);
	}

	/**
	 * <b>Nombre: </b> generateKey </br>
	 * <b>Descripci�n:</b> Implementaci�n del m�todo que crea la key publica
	 * exclusivamente algoritmos AES</br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n: 13/01/2023 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @param keysize
	 * @return SecretKey
	 * @throws NoSuchAlgorithmException
	 */
	private SecretKey generateKey(int keysize) throws NoSuchAlgorithmException {
		KeyGenerator keyGenerator = KeyGenerator.getInstance(BabylonCommonUtilsConstants.KEY_NAME_PROPERTIES_UTIL_AES);
		keyGenerator.init(keysize);
		return keyGenerator.generateKey();
	}

	/**
	 * <b>Nombre: </b> getAES256Iv </br>
	 * <b>Descripci�n:</b> Implementaci�n del m�todo que obtiene la key publica
	 * exclusivamente algoritmos AES256</br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n: 13/01/2023 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @return IvParameterSpec
	 */
	private IvParameterSpec getAES256Iv() {
		return new IvParameterSpec(Base64.getDecoder().decode((config.aes256Iv())));
	}

	/**
	 * <b>Nombre: </b> activate </br>
	 * <b>Descripci�n:</b> Implementaci�n del m�todo que activa la configuraci�n del
	 * modulo en liferay para la api Enbcryption</br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n: 13/01/2023 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @param properties
	 */
	@Activate
	@Modified
	protected void activate(Map<String, Object> properties) {
		config = ConfigurableUtil.createConfigurable(EncryptionConfiguration.class, properties);
	}
}
