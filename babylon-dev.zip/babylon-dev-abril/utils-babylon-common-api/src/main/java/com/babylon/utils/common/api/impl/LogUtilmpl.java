package com.babylon.utils.common.api.impl;

import com.babylon.utils.common.api.LogUtilApi;
import com.babylon.utils.common.api.constants.BabylonCommonUtilsConstants;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.model.VirtualHost;
import com.liferay.portal.kernel.service.VirtualHostLocalService;

import java.util.Optional;
import java.util.UUID;

import org.apache.log4j.MDC;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * <b>Nombre: </b> LogUtilmpl </br>
 * <b>Descripci�n:</b> Clase de implementaci�nque expone m�todos utilitarios en
 * base al uso de la traza para logs </br>
 * <b>Fecha Creaci�n:</b> 30/11/2022 </br>
 * <b>Autor:BABYLON Jose Andr�s S�nchez Bernal </br>
 * <b>Fecha de �ltima Modificaci�n: </b></br>
 * <b>Modificado por: </b></br>
 */
@Component(service = LogUtilApi.class)
public class LogUtilmpl implements LogUtilApi {

	/**
	 * <b>Nombre: </b> getTrace </br>
	 * <b>Descripci�n:</b>Implementaci�n del m�todo para registrar las trazas
	 * personalizas </br>
	 * <b>Fecha Creaci�n:</b> 30/11/2022 </br>
	 * <b>Autor:BABYLON Jose Andr�s S�nchez Bernal </br>
	 * <b>Fecha de �ltima Modificaci�n: </b></br>
	 * <b>Modificado por: </b></br>
	 * 
	 * @param log
	 * @param companyId
	 * @throws PortalException
	 */
	@Override
	public void getTrace(Log log, long companyId) throws PortalException {
		try {

			String hostname = getHostname(companyId);
			UUID uuid = UUID.randomUUID();
			MDC.put(BabylonCommonUtilsConstants.KEY_UTILS_HOSTNAME, hostname);
			MDC.put(BabylonCommonUtilsConstants.KEY_UTILS_UUID_TR, uuid);
		} catch (Exception e) {
			log.error("getTrace Error: ", e);
		}
	}

	/**
	 * <b>Nombre: </b> getUuid </br>
	 * <b>Descripci�n:</b>Implementaci�n del m�todo para obtener un UUID de registro
	 * </br>
	 * <b>Fecha Creaci�n:</b> 30/11/2022 </br>
	 * <b>Autor:BABYLON Jose Andr�s S�nchez Bernal </br>
	 * <b>Fecha de �ltima Modificaci�n: </b></br>
	 * <b>Modificado por: </b></br>
	 * 
	 * @param log
	 * @throws PortalException
	 */
	@Override
	public void getUuid(Log log) throws PortalException {
		UUID uuid = UUID.randomUUID();
		MDC.put(BabylonCommonUtilsConstants.KEY_UTILS_UUID_TR, uuid);
	}

	/**
	 * <b>Nombre: </b> getHostname </br>
	 * <b>Descripci�n:</b> M�todo utilitario para obtener el hostname de la
	 * instancia apartir del companyId </br>
	 * <b>Fecha Creaci�n:</b> 30/11/2022 </br>
	 * <b>Autor:BABYLON Jose Andr�s S�nchez Bernal </br>
	 * <b>Fecha de �ltima Modificaci�n: 23/01/2023</b></br>
	 * <b>Modificado por:BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @param companyId
	 * @return String
	 * @throws PortalException
	 */
	private String getHostname(long companyId) throws PortalException {
		Optional<VirtualHost> optionalVirtualHost = virtualHostApi.getVirtualHosts(companyId, 0).parallelStream()
				.findFirst();
		if (optionalVirtualHost.isPresent()) {
			return optionalVirtualHost.get().getHostname();
		}
		return StringPool.BLANK;
	}

	@Reference
	VirtualHostLocalService virtualHostApi;
}
