package com.babylon.utils.common.api.impl;

import com.babylon.utils.common.api.RestWebServicesClientGatewayUtilApi;
import com.babylon.utils.common.api.RestWebServicesClientUtilApi;
import com.babylon.utils.common.api.config.GatewayAuthorizationConfiguration;
import com.babylon.utils.common.api.constants.BabylonCommonUtilsConstants;
import com.babylon.utils.common.api.constants.RestWebServiceConstants;
import com.babylon.utils.common.api.exceptions.NoSuchOrganizationIdException;
import com.babylon.utils.common.api.exceptions.RestWebServiceClientException;
import com.babylon.utils.common.api.request.RestWebServiceRequest;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.configuration.metatype.bnd.util.ConfigurableUtil;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.util.ContentTypes;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.Validator;
import com.babylon.utils.common.api.EncodeUtilApi;

import java.util.Map;

import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.annotations.Reference;

/**
 * <b>Nombre: </b> RestWebServicesClientGatewayImpl </br>
 * <b>Descripci�n:</b> </br>
 * <b>Fecha Creaci�n:</b> 25/11/2022 </br>
 * <b>Autor:BABYLON Ricardo Salinas </br>
 * <b>Fecha de �ltima Modificaci�n: 25/11/2022 </b></br>
 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal</b></br>
 */
@Component(configurationPid = BabylonCommonUtilsConstants.KEY_METAOCD_ID_GATEWAY, immediate = true, service = RestWebServicesClientGatewayUtilApi.class)
public class RestWebServicesClientGatewayImpl implements RestWebServicesClientGatewayUtilApi {

	private volatile GatewayAuthorizationConfiguration gatewayAuthorizationConfiguration;

	/**
	 * <b>Nombre: </b> callService </br>
	 * <b>Descripci�n:</b> M�todo de implementaci�n sobrescrito del api para el
	 * consumo de servicios Rest para cualquier tipo</br>
	 * <b>Fecha Creaci�n:</b> 25/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n: 25/11/2022 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal</b></br>
	 * 
	 * @param restWebServiceRequest
	 * @param method
	 * @param logger
	 * @return JSONObject
	 * @throws RestWebServiceClientException
	 */
	@Override
	public JSONObject callService(RestWebServiceRequest restWebServiceRequest,
			RestWebServiceConstants.HttpMethods method, Log logger)
			throws RestWebServiceClientException, NoSuchOrganizationIdException {

		String requestUrl = GetterUtil.getString(restWebServiceRequest.getRequestUrl());
		String requestBody = GetterUtil.getString(restWebServiceRequest.getRequestBody());

		if (restWebServiceRequest.getUsesProxy() == null) {
			restWebServiceRequest.setUsesProxy(gatewayAuthorizationConfiguration.usesProxy());
		}
		addAuthorization(restWebServiceRequest, logger);
		restWebServiceRequest.setRequestUrl(requestUrl);
		restWebServiceRequest.setRequestBody(requestBody);
		switch (method) {
		case POST:
			return restWebServicesClientUtilApi.callRestServiceByPost(restWebServiceRequest, logger);
		case GET:
			return restWebServicesClientUtilApi.callRestServiceByGet(restWebServiceRequest, logger);
		case PUT:
			return restWebServicesClientUtilApi.callRestServiceByPut(restWebServiceRequest, logger);
		case PATCH:
			return restWebServicesClientUtilApi.callRestServiceByPut(restWebServiceRequest, logger);
		default:
			return JSONFactoryUtil.createJSONObject();
		}
	}

	@Override
	public JSONObject callService(RestWebServiceRequest restWebServiceRequest,
			RestWebServiceConstants.HttpMethods method, boolean enableSetOrganizationId, Log logger)
			throws RestWebServiceClientException, NoSuchOrganizationIdException {

		String requestUrl = GetterUtil.getString(restWebServiceRequest.getRequestUrl());
		String requestBody = GetterUtil.getString(restWebServiceRequest.getRequestBody());

		if (restWebServiceRequest.getUsesProxy() == null) {
			restWebServiceRequest.setUsesProxy(gatewayAuthorizationConfiguration.usesProxy());
		}
		addAuthorization(restWebServiceRequest, logger);
		restWebServiceRequest.setRequestUrl(requestUrl);
		restWebServiceRequest.setRequestBody(requestBody);
		switch (method) {
		case POST:
			if (enableSetOrganizationId) {
				return restWebServicesClientUtilApi.callRestServiceByPost(restWebServiceRequest, logger);
			}
			return restWebServicesClientUtilApi.callRestServiceByPost(restWebServiceRequest, enableSetOrganizationId,
					logger);
		case GET:
			return restWebServicesClientUtilApi.callRestServiceByGet(restWebServiceRequest, logger);
		case PUT:
			return restWebServicesClientUtilApi.callRestServiceByPut(restWebServiceRequest, logger);
		case PATCH:
			return restWebServicesClientUtilApi.callRestServiceByPut(restWebServiceRequest, logger);
		default:
			return JSONFactoryUtil.createJSONObject();
		}
	}

	/**
	 * <b>Nombre: </b> addAuthorization </br>
	 * <b>Descripci�n:</b> M�todo propio de la implementaci�n que setea en el header
	 * del request del servicio a consumir la autorizaci�n solo si la necesita entre
	 * ellas OAuth2, Basic Authorization, Api Key</br>
	 * <b>Fecha Creaci�n:</b> 25/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n: 25/11/2022 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal</b></br>
	 * 
	 * @param restWebServiceRequest
	 * @param logger
	 * @throws RestWebServiceClientException
	 */
	private void addAuthorization(RestWebServiceRequest restWebServiceRequest, Log logger)
			throws RestWebServiceClientException, NoSuchOrganizationIdException {
		String authorizationType = restWebServiceRequest.getAuthorizationType();
		if (Validator.isNull(authorizationType)) {
			authorizationType = gatewayAuthorizationConfiguration.authorizationType();
		}
		switch (authorizationType) {
		case RestWebServiceConstants.KEY_UTILS_AUTHORIZATION_OAUTH_2:
			restWebServiceRequest.setHeader(RestWebServiceConstants.KEY_UTILS_AUTHORIZATION,
					getOauth2AuthorizationToken(restWebServiceRequest, logger));
			restWebServiceRequest.getHeaders().remove(RestWebServiceConstants.KEY_UTILS_ACCEPT);
			restWebServiceRequest.getHeaders().remove(RestWebServiceConstants.KEY_UTILS_CONTENT_TYPE);
			restWebServiceRequest.setRequestBodyMimeType(null);
			break;
		case RestWebServiceConstants.KEY_UTILS_AUTHORIZATION_BASIC_AUTHENTICATION:
			restWebServiceRequest.setHeader(RestWebServiceConstants.KEY_UTILS_AUTHORIZATION,
					getBasicAuthorizationToken(restWebServiceRequest));
			break;
		case RestWebServiceConstants.KEY_UTILS_AUTHORIZATION_API_KEY:
			restWebServiceRequest.setHeader(RestWebServiceConstants.KEY_UTILS_AUTHORIZATION,
					restWebServiceRequest.getClientSecret());
			break;
		default:
			break;
		}

	}

	/**
	 * <b>Nombre: </b> getBasicAuthorizationToken </br>
	 * <b>Descripci�n:</b> M�todo propio de la implementaci�n que obtiene el token
	 * de tipo Basic Authorization </br>
	 * <b>Fecha Creaci�n:</b> 25/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n: 25/11/2022 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal</b></br>
	 * 
	 * @param restWebServiceRequest
	 * @return String
	 */
	private String getBasicAuthorizationToken(RestWebServiceRequest restWebServiceRequest) {
		StringBuilder authorization = new StringBuilder();
		authorization.append(RestWebServiceConstants.KEY_UTILS_BASIC_AUTHORIZATION);
		authorization.append(getBasicAuthorizationToken(restWebServiceRequest.getClientID(),
				restWebServiceRequest.getClientSecret()));
		return authorization.toString();
	}

	/**
	 * <b>Nombre: </b> getOauth2AuthorizationToken </br>
	 * <b>Descripci�n:</b> M�todo propio de la implementaci�n que obtiene el token
	 * de tipo OAuth2.0 </br>
	 * <b>Fecha Creaci�n:</b> 25/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n: 25/11/2022 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal</b></br>
	 * 
	 * @param restWebServiceRequest
	 * @param logger
	 * @return String
	 * @throws RestWebServiceClientException
	 */
	private String getOauth2AuthorizationToken(RestWebServiceRequest restWebServiceRequest, Log logger)
			throws RestWebServiceClientException, NoSuchOrganizationIdException {

		String basicAuthorizationToken = getBasicAuthorizationToken(restWebServiceRequest.getClientID(),
				restWebServiceRequest.getClientSecret());

		String accessToken = StringPool.BLANK;

		if (Validator.isNull(restWebServiceRequest.getAccessTokenURL())) {
			restWebServiceRequest.setRequestUrl(gatewayAuthorizationConfiguration.accessTokenURL());
		} else {
			restWebServiceRequest.setRequestUrl(restWebServiceRequest.getAccessTokenURL());
		}

		if (Validator.isNull(restWebServiceRequest.getScope())) {
			restWebServiceRequest.setScope(gatewayAuthorizationConfiguration.scope());
		}

		if (Validator.isNull(restWebServiceRequest.getGrantType())) {
			restWebServiceRequest.setGrantType(gatewayAuthorizationConfiguration.grantType());
		}
		restWebServiceRequest.setRequestBodyMimeType(ContentTypes.APPLICATION_X_WWW_FORM_URLENCODED);

		StringBuilder authorization = new StringBuilder();
		authorization.append(RestWebServiceConstants.KEY_UTILS_BASIC_AUTHORIZATION);
		authorization.append(basicAuthorizationToken);

		restWebServiceRequest.setHeader(RestWebServiceConstants.KEY_UTILS_AUTHORIZATION, authorization.toString());
		restWebServiceRequest.setHeader(RestWebServiceConstants.KEY_UTILS_ACCEPT,
				RestWebServiceConstants.KEY_UTILS_ACCEPT_ALL);
		restWebServiceRequest.setHeader(RestWebServiceConstants.KEY_UTILS_CONTENT_TYPE,
				ContentTypes.APPLICATION_X_WWW_FORM_URLENCODED);

		StringBuilder requestBody = new StringBuilder();
		requestBody.append(RestWebServiceConstants.KEY_UTILS_GRANT_TYPE);
		requestBody.append(StringPool.EQUAL);
		requestBody.append(restWebServiceRequest.getGrantType());
		requestBody.append(StringPool.AMPERSAND);
		requestBody.append(RestWebServiceConstants.KEY_UTILS_SCOPE);
		requestBody.append(StringPool.EQUAL);
		requestBody.append(restWebServiceRequest.getScope());

		restWebServiceRequest.setRequestBody(requestBody.toString());

		JSONObject authorizationTokenSettings = restWebServicesClientUtilApi
				.callRestServiceByPost(restWebServiceRequest, logger);

		accessToken = authorizationTokenSettings.getString(RestWebServiceConstants.KEY_UTILS_ACCESS_TOKEN);

		StringBuilder oauth2Authorization = new StringBuilder();
		oauth2Authorization.append(restWebServiceRequest.getScope());
		oauth2Authorization.append(StringPool.SPACE);
		oauth2Authorization.append(accessToken);

		return oauth2Authorization.toString();
	}

	/**
	 * <b>Nombre: </b> getBasicAuthorizationToken </br>
	 * <b>Descripci�n:</b> M�todo de implementaci�n propio que obtiene setea el
	 * token de tipo Basic Authorization al StringBuilder y retornarlopara su
	 * uso</br>
	 * <b>Fecha Creaci�n:</b> 25/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n: 25/11/2022 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @param clientID
	 * @param clientSecret
	 * @return String
	 */
	private String getBasicAuthorizationToken(String clientID, String clientSecret) {
		StringBuilder basicAuthorization = new StringBuilder();
		basicAuthorization.append(clientID);
		basicAuthorization.append(StringPool.COLON);
		basicAuthorization.append(clientSecret);
		return encodeUtilImpl.encodeBase64(basicAuthorization.toString());
	}

	/**
	 * <b>Nombre: </b> activate </br>
	 * <b>Descripci�n:</b> M�todo de implementaci�n propio que activa pla
	 * configuraci�n del api para el uso de campos dinamicos.</br>
	 * <b>Fecha Creaci�n:</b> 25/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n: 25/11/2022</b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @param properties
	 */
	@Activate
	@Modified
	protected void activate(Map<String, Object> properties) {
		gatewayAuthorizationConfiguration = ConfigurableUtil.createConfigurable(GatewayAuthorizationConfiguration.class,
				properties);
	}

	@Reference
	private RestWebServicesClientUtilApi restWebServicesClientUtilApi;

	@Reference
	private EncodeUtilApi encodeUtilImpl;

}