package com.babylon.utils.common.api.impl;

import com.babylon.utils.common.api.RestWebServicesClientUtilApi;
import com.babylon.utils.common.api.config.ConnectionPropertiesConfiguration;
import com.babylon.utils.common.api.constants.BabylonCommonUtilsConstants;
import com.babylon.utils.common.api.constants.RestWebServiceConstants;
import com.babylon.utils.common.api.constants.RestWebServiceConstants.HttpMethods;
import com.babylon.utils.common.api.exceptions.NoSuchOrganizationIdException;
import com.babylon.utils.common.api.exceptions.RestWebServiceClientException;
import com.babylon.utils.common.api.request.RestWebServiceRequest;
import com.babylon.utils.common.api.util.CommonGenericUtilsUtil;
import com.liferay.headless.commerce.core.util.ServiceContextHelper;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.configuration.metatype.bnd.util.ConfigurableUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.json.JSONArray;
import com.liferay.portal.kernel.json.JSONException;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.UserLocalServiceUtil;
import com.liferay.portal.kernel.util.ContentTypes;
import com.liferay.portal.kernel.util.Validator;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPatch;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicNameValuePair;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.annotations.Reference;

/**
 * <b>Nombre: </b> RestWebServicesClientImpl </br>
 * <b>Descripción:</b> Clase de implementación de la Api que expone métodos
 * utilitarios en base al uso de consumo de servicios Rest, tales como GET,POST,
 * PATCH</br>
 * <b>Fecha Creación:</b> 25/11/2022 </br>
 * <b>Autor:BABYLON Ricardo Salinas </br>
 * <b>Fecha de última Modificación: 13/01/2023</b></br>
 * <b>Modificado por: BABYLON Jose Andrés Sánchez Bernal</b></br>
 */
@Component(configurationPid = BabylonCommonUtilsConstants.KEY_METAOCD_ID_CONNECTION_PROPERTIES, immediate = true, service = RestWebServicesClientUtilApi.class)
public class RestWebServicesClientImpl implements RestWebServicesClientUtilApi {

	private volatile ConnectionPropertiesConfiguration connectionPropertiesConfiguration;
	private static final Log LOGGER = LogFactoryUtil.getLog(RestWebServicesClientImpl.class);

	@Reference
	ServiceContextHelper serviceContextHelper;

	/**
	 * <b>Nombre: </b> callRestServiceByGet </br>
	 * <b>Descripción:</b> Método de implementación que consume servicios Rest
	 * por metodo GET </br>
	 * <b>Fecha Creación:</b> 25/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de última Modificación: 13/01/2023</b></br>
	 * <b>Modificado por: BABYLON Jose Andrés Sánchez Bernal</b></br>
	 *
	 * @param restWebServiceRequest
	 * @param logger
	 * @return JSONObject
	 * @throws RestWebServiceClientException
	 */
	@Override
	public JSONObject callRestServiceByGet(RestWebServiceRequest restWebServiceRequest, Log logger)
			throws RestWebServiceClientException, NoSuchOrganizationIdException {
		JSONObject serviceResponse = null;
		HttpGet httpGet = new HttpGet();

		URI uri = buildRequestURI(restWebServiceRequest.getRequestUrl(), restWebServiceRequest.getParameters());
		printRequest(restWebServiceRequest, uri.toString(), RestWebServiceConstants.HttpMethods.GET, logger);

		if (Validator.isNotNull(uri)) {
			httpGet = new HttpGet(uri);
		}

		if (Validator.isNotNull(httpGet)) {
			setHeaders(httpGet, restWebServiceRequest.getHeaders(), restWebServiceRequest.getRequestBodyMimeType());
			CloseableHttpClient httpClient = buildClient(restWebServiceRequest.getUsesProxy());
			try {
				CloseableHttpResponse response = httpClient.execute(httpGet);
				serviceResponse = parseServiceResponse(restWebServiceRequest.getRequestUrl(), response);
			} catch (IOException e) {
				logger.error("Error al llamar al servicio: " + restWebServiceRequest.getRequestUrl(), e);
				String errorMessage = BabylonCommonUtilsConstants.DEFAULT_MESSAGE_EXCEPTION_LOG_MESSAGE
						+ BabylonCommonUtilsConstants.DEFAULT_MESSAGE_EXCEPTION_LOG_MESSAGE_OPENGET
						+ restWebServiceRequest.getRequestUrl();
				throw new RestWebServiceClientException(HttpStatus.SC_INTERNAL_SERVER_ERROR, errorMessage,
						e.getMessage());
			} finally {
				try {
					httpClient.close();
				} catch (IOException e) {
					String errorMessage = BabylonCommonUtilsConstants.DEFAULT_MESSAGE_EXCEPTION_LOG_MESSAGE
							+ BabylonCommonUtilsConstants.DEFAULT_MESSAGE_EXCEPTION_LOG_MESSAGE_CLOSEGET;
					throw new RestWebServiceClientException(HttpStatus.SC_INTERNAL_SERVER_ERROR, errorMessage,
							e.getMessage());
				}
			}
		}
		return serviceResponse;
	}

	/**
	 * <b>Nombre: </b> callRestServiceByPost </br>
	 * <b>Descripción:</b> </b> Método de implementación que consume servicios
	 * Rest por metodo POST </br>
	 * <b>Fecha Creación:</b> 25/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de última Modificación: 13/01/2023</b></br>
	 * <b>Modificado por: BABYLON Jose Andrés Sánchez Bernal</b></br>
	 *
	 * @param restWebServiceRequest
	 * @param logger
	 * @return JSONObject
	 * @throws RestWebServiceClientException
	 */
	@Override
	public JSONObject callRestServiceByPost(RestWebServiceRequest restWebServiceRequest, Log logger)
			throws RestWebServiceClientException, NoSuchOrganizationIdException {
		JSONObject serviceResponse = null;
		HttpPost httpPost = null;

		URI uri = buildRequestURI(restWebServiceRequest.getRequestUrl(), restWebServiceRequest.getParameters());
		httpPost = new HttpPost(uri);

		if (Validator.isNotNull(httpPost)) {
			if (Validator.isNotNull(restWebServiceRequest.getRequestBodyMimeType())
					&& restWebServiceRequest.getRequestBodyMimeType().equals(ContentTypes.MULTIPART_FORM_DATA)) {
				httpPost.setEntity(Objects.requireNonNull(setMultipartEntity(restWebServiceRequest, logger)).build());
			} else if (Validator.isNotNull(restWebServiceRequest.getRequestBody())
					&& !restWebServiceRequest.getRequestBody().isEmpty()) {
				httpPost.setEntity(new StringEntity(restWebServiceRequest.getRequestBody(),
						getContentType(restWebServiceRequest.getRequestBodyMimeType())));
			}

			setHeaders(httpPost, restWebServiceRequest.getHeaders(), restWebServiceRequest.getRequestBodyMimeType());
			CloseableHttpClient httpClient = buildClient(restWebServiceRequest.getUsesProxy());
			printRequest(restWebServiceRequest, uri.toString(), RestWebServiceConstants.HttpMethods.POST, logger);

			try {
				CloseableHttpResponse response = httpClient.execute(httpPost);
				serviceResponse = parseServiceResponse(restWebServiceRequest.getRequestUrl(), response);

			} catch (IOException e) {
				logger.error("IOException ", e);
				String errorMessage = BabylonCommonUtilsConstants.DEFAULT_MESSAGE_EXCEPTION_LOG_MESSAGE
						+ "Execute consumption by POST";
				throw new RestWebServiceClientException(HttpStatus.SC_INTERNAL_SERVER_ERROR, errorMessage,
						e.getMessage());
			} finally {
				try {
					httpClient.close();
				} catch (IOException e) {
					logger.error(e);
					String errorMessage = BabylonCommonUtilsConstants.DEFAULT_MESSAGE_EXCEPTION_LOG_MESSAGE
							+ "Closing connection by POST";
					throw new RestWebServiceClientException(HttpStatus.SC_INTERNAL_SERVER_ERROR, errorMessage,
							e.getMessage());
				}
			}
		}
		printResponse(serviceResponse, RestWebServiceConstants.HttpMethods.POST, logger);
		return serviceResponse;
	}
	
	@Override
	public JSONObject callRestServiceByPost(RestWebServiceRequest restWebServiceRequest, boolean enableSetOrganizationId , Log logger)
			throws RestWebServiceClientException, NoSuchOrganizationIdException {
		JSONObject serviceResponse = null;
		HttpPost httpPost = null;

		URI uri = buildRequestURI(restWebServiceRequest.getRequestUrl(), restWebServiceRequest.getParameters());
		httpPost = new HttpPost(uri);

		if (Validator.isNotNull(httpPost)) {
			if (Validator.isNotNull(restWebServiceRequest.getRequestBodyMimeType())
					&& restWebServiceRequest.getRequestBodyMimeType().equals(ContentTypes.MULTIPART_FORM_DATA)) {
				httpPost.setEntity(Objects.requireNonNull(setMultipartEntity(restWebServiceRequest, logger)).build());
			} else if (Validator.isNotNull(restWebServiceRequest.getRequestBody())
					&& !restWebServiceRequest.getRequestBody().isEmpty()) {
				httpPost.setEntity(new StringEntity(restWebServiceRequest.getRequestBody(),
						getContentType(restWebServiceRequest.getRequestBodyMimeType())));
			}

			setHeaders(httpPost, restWebServiceRequest.getHeaders(), restWebServiceRequest.getRequestBodyMimeType(), enableSetOrganizationId);
			CloseableHttpClient httpClient = buildClient(restWebServiceRequest.getUsesProxy());
			printRequest(restWebServiceRequest, uri.toString(), RestWebServiceConstants.HttpMethods.POST, logger);

			try {
				CloseableHttpResponse response = httpClient.execute(httpPost);
				serviceResponse = parseServiceResponse(restWebServiceRequest.getRequestUrl(), response);

			} catch (IOException e) {
				logger.error("IOException ", e);
				String errorMessage = BabylonCommonUtilsConstants.DEFAULT_MESSAGE_EXCEPTION_LOG_MESSAGE
						+ "Execute consumption by POST";
				throw new RestWebServiceClientException(HttpStatus.SC_INTERNAL_SERVER_ERROR, errorMessage,
						e.getMessage());
			} finally {
				try {
					httpClient.close();
				} catch (IOException e) {
					logger.error(e);
					String errorMessage = BabylonCommonUtilsConstants.DEFAULT_MESSAGE_EXCEPTION_LOG_MESSAGE
							+ "Closing connection by POST";
					throw new RestWebServiceClientException(HttpStatus.SC_INTERNAL_SERVER_ERROR, errorMessage,
							e.getMessage());
				}
			}
		}
		printResponse(serviceResponse, RestWebServiceConstants.HttpMethods.POST, logger);
		return serviceResponse;
	}

	/**
	 * <b>Nombre: </b> callRestServiceByPut </br>
	 * <b>Descripción:</b> </b> Método de implementación que consume servicios
	 * Rest por metodo PUT </br>
	 * <b>Fecha Creación:</b> 25/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de última Modificación: 13/01/2023</b></br>
	 * <b>Modificado por: BABYLON Jose Andrés Sánchez Bernal</b></br>
	 *
	 * @param restWebServiceRequest
	 * @param logger
	 * @return JSONObject
	 * @throws RestWebServiceClientException
	 */
	@Override
	public JSONObject callRestServiceByPut(RestWebServiceRequest restWebServiceRequest, Log logger)
			throws RestWebServiceClientException, NoSuchOrganizationIdException {

		JSONObject serviceResponse = null;
		HttpPut httpPut = null;

		URI uri = buildRequestURI(restWebServiceRequest.getRequestUrl(), restWebServiceRequest.getParameters());

		httpPut = new HttpPut(uri);

		if (Validator.isNotNull(httpPut)) {

			httpPut.setEntity(new StringEntity(restWebServiceRequest.getRequestBody(),
					getContentType(restWebServiceRequest.getRequestBodyMimeType())));

			setHeaders(httpPut, restWebServiceRequest.getHeaders(), restWebServiceRequest.getRequestBodyMimeType());

			CloseableHttpClient httpClient = buildClient(restWebServiceRequest.getUsesProxy());

			printRequest(restWebServiceRequest, uri.toString(), RestWebServiceConstants.HttpMethods.PUT, logger);

			try {
				CloseableHttpResponse response = httpClient.execute(httpPut);
				serviceResponse = parseServiceResponse(restWebServiceRequest.getRequestUrl(), response);
			} catch (IOException e) {
				logger.error(e);
				String errorMessage = BabylonCommonUtilsConstants.DEFAULT_MESSAGE_EXCEPTION_LOG_MESSAGE
						+ "Execute consumption by PUT";
				throw new RestWebServiceClientException(HttpStatus.SC_INTERNAL_SERVER_ERROR, errorMessage,
						e.getMessage());
			} finally {
				try {
					httpClient.close();
				} catch (IOException e) {
					logger.error(e);
					String errorMessage = BabylonCommonUtilsConstants.DEFAULT_MESSAGE_EXCEPTION_LOG_MESSAGE
							+ "Closing connection by PUT";
					throw new RestWebServiceClientException(HttpStatus.SC_INTERNAL_SERVER_ERROR, errorMessage,
							e.getMessage());
				}
			}
		}
		printResponse(serviceResponse, RestWebServiceConstants.HttpMethods.PUT, logger);
		return serviceResponse;
	}

	/**
	 * <b>Nombre: </b> callRestServiceByPatch </br>
	 * <b>Descripción:</b> </b> Método de implementación que consume servicios
	 * Rest por metodo PATCH </br>
	 * <b>Fecha Creación:</b> 25/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de última Modificación: 13/01/2023</b></br>
	 * <b>Modificado por: BABYLON Jose Andrés Sánchez Bernal</b></br>
	 *
	 * @param restWebServiceRequest
	 * @param logger
	 * @return JSONObject
	 * @throws RestWebServiceClientException
	 */
	@Override
	public JSONObject callRestServiceByPatch(RestWebServiceRequest restWebServiceRequest, Log logger)
			throws RestWebServiceClientException, NoSuchOrganizationIdException {

		JSONObject serviceResponse = null;
		HttpPatch httpPatch = null;

		URI uri = buildRequestURI(restWebServiceRequest.getRequestUrl(), restWebServiceRequest.getParameters());

		httpPatch = new HttpPatch(uri);

		if (Validator.isNotNull(httpPatch)) {
			if (Validator.isNotNull(restWebServiceRequest.getRequestBodyMimeType())
					&& restWebServiceRequest.getRequestBodyMimeType().equals(ContentTypes.MULTIPART_FORM_DATA)) {
				httpPatch.setEntity(Objects.requireNonNull(setMultipartEntity(restWebServiceRequest, logger)).build());
			} else if (Validator.isNotNull(restWebServiceRequest.getRequestBody())
					&& !restWebServiceRequest.getRequestBody().isEmpty()) {
				httpPatch.setEntity(new StringEntity(restWebServiceRequest.getRequestBody(),
						getContentType(restWebServiceRequest.getRequestBodyMimeType())));
			}
			
			setHeaders(httpPatch, restWebServiceRequest.getHeaders(), restWebServiceRequest.getRequestBodyMimeType());
			CloseableHttpClient httpClient = buildClient(restWebServiceRequest.getUsesProxy());

			printRequest(restWebServiceRequest, uri.toString(), RestWebServiceConstants.HttpMethods.PATCH, logger);

			try {
				CloseableHttpResponse response = httpClient.execute(httpPatch);
				serviceResponse = parseServiceResponse(restWebServiceRequest.getRequestUrl(), response);
			} catch (IOException e) {
				logger.error(e);
				String errorMessage = BabylonCommonUtilsConstants.DEFAULT_MESSAGE_EXCEPTION_LOG_MESSAGE
						+ BabylonCommonUtilsConstants.DEFAULT_MESSAGE_EXCEPTION_LOG_MESSAGE_OPENPATCH;
				throw new RestWebServiceClientException(HttpStatus.SC_INTERNAL_SERVER_ERROR, errorMessage,
						e.getMessage());
			} finally {
				try {
					httpClient.close();
				} catch (IOException e) {
					logger.error(e);
					String errorMessage = BabylonCommonUtilsConstants.DEFAULT_MESSAGE_EXCEPTION_LOG_MESSAGE
							+ BabylonCommonUtilsConstants.DEFAULT_MESSAGE_EXCEPTION_LOG_MESSAGE_CLOSEPATCH;
					throw new RestWebServiceClientException(HttpStatus.SC_INTERNAL_SERVER_ERROR, errorMessage,
							e.getMessage());
				}
			}
		}
		printResponse(serviceResponse, RestWebServiceConstants.HttpMethods.PATCH, logger);
		return serviceResponse;
	}

	/**
	 * <b>Nombre: </b> callRestServiceByDelete </br>
	 * <b>Descripción:</b> </b> Método de implementación que consume servicios
	 * Rest por metodo DELETE </br>
	 * <b>Fecha Creación:</b> 01/06/2024 </br>
	 * <b>Autor:BABYLON Jose Andrés Sánchez Bernal </br>
	 * <b>Fecha de última Modificación: </b></br>
	 * <b>Modificado por: </b></br>
	 *
	 * @param restWebServiceRequest
	 * @param logger
	 * @return JSONObject
	 * @throws RestWebServiceClientException
	 */
	@Override
	public JSONObject callRestServiceByDelete(RestWebServiceRequest restWebServiceRequest, Log logger)
			throws RestWebServiceClientException, NoSuchOrganizationIdException {
		JSONObject serviceResponse = null;
		HttpDelete httpDelete = new HttpDelete();

		URI uri = buildRequestURI(restWebServiceRequest.getRequestUrl(), restWebServiceRequest.getParameters());
		printRequest(restWebServiceRequest, uri.toString(), RestWebServiceConstants.HttpMethods.DELETE, logger);

		if (Validator.isNotNull(uri)) {
			httpDelete = new HttpDelete(uri);
		}

		if (Validator.isNotNull(httpDelete)) {
			setHeaders(httpDelete, restWebServiceRequest.getHeaders(), restWebServiceRequest.getRequestBodyMimeType());
			CloseableHttpClient httpClient = buildClient(restWebServiceRequest.getUsesProxy());
			try {
				CloseableHttpResponse response = httpClient.execute(httpDelete);
				serviceResponse = parseServiceResponse(restWebServiceRequest.getRequestUrl(), response);
			} catch (IOException e) {
				logger.error(e);
				String errorMessage = BabylonCommonUtilsConstants.DEFAULT_MESSAGE_EXCEPTION_LOG_MESSAGE
						+ BabylonCommonUtilsConstants.DEFAULT_MESSAGE_EXCEPTION_LOG_MESSAGE_OPENGET;
				throw new RestWebServiceClientException(HttpStatus.SC_INTERNAL_SERVER_ERROR, errorMessage,
						e.getMessage());
			} finally {
				try {
					httpClient.close();
				} catch (IOException e) {
					logger.error(e);
					String errorMessage = BabylonCommonUtilsConstants.DEFAULT_MESSAGE_EXCEPTION_LOG_MESSAGE
							+ BabylonCommonUtilsConstants.DEFAULT_MESSAGE_EXCEPTION_LOG_MESSAGE_CLOSEGET;
					throw new RestWebServiceClientException(HttpStatus.SC_INTERNAL_SERVER_ERROR, errorMessage,
							e.getMessage());
				}
			}
		}
		return serviceResponse;
	}

	/**
	 * <b>Nombre: </b> setMultipartEntity </br>
	 * <b>Descripción:</b> Método propio de la implementación que setea el Dto
	 * MultipartEntityBuilder</br>
	 * <b>Fecha Creación:</b> 25/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de última Modificación: 13/01/2023</b></br>
	 * <b>Modificado por: BABYLON Jose Andrés Sánchez Bernal</b></br>
	 *
	 * @param restWebServiceRequest
	 * @param logger
	 * @return MultipartEntityBuilder
	 */
	private MultipartEntityBuilder setMultipartEntity(RestWebServiceRequest restWebServiceRequest, Log logger) {

		try {
			ContentType contentType = ContentType.create(ContentTypes.TEXT_PLAIN, StandardCharsets.UTF_8);
			MultipartEntityBuilder entityBuilder = MultipartEntityBuilder.create();

			if (Validator.isNotNull(restWebServiceRequest.getRequestBody())
					&& !restWebServiceRequest.getRequestBody().isEmpty()) {

				JSONObject requestBody = JSONFactoryUtil.createJSONObject(restWebServiceRequest.getRequestBody());

				requestBody.keys().forEachRemaining(key -> {
					if (Validator.isNotNull(requestBody.getString(key))) {
						entityBuilder.addPart(key, new StringBody(requestBody.getString(key), contentType));
					}
				});
			}
			if (Validator.isNotNull(restWebServiceRequest.getAttachments())) {
				restWebServiceRequest.getAttachments().forEach((key, value) -> {
					if (Validator.isNotNull(value)) {
						entityBuilder.addPart(key, new FileBody(value));
					}
				});
			}

			return entityBuilder;
		} catch (JSONException e) {
			logger.error("Error --> setMultipartEntity: " + e.getMessage());
		}
		return null;
	}

	/**
	 * <b>Nombre: </b> printResponse </br>
	 * <b>Descripción:</b> Método propio de la implementación que mapea la
	 * respuesta del servicio consumido </br>
	 * <b>Fecha Creación:</b> 25/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de última Modificación: 13/01/2023</b></br>
	 * <b>Modificado por: BABYLON Jose Andrés Sánchez Bernal</b></br>
	 *
	 * @param serviceResponse
	 * @param method
	 * @param logger
	 */
	private void printResponse(JSONObject serviceResponse, HttpMethods method, Log logger) {
		if (Validator.isNotNull(logger) && logger.isDebugEnabled()) {
			String responseLog = "Response method -> " + method + " Response body [" + serviceResponse
					+ StringPool.CLOSE_BRACKET;
			logger.debug(responseLog);
		}
	}

	/**
	 * <b>Nombre: </b> printRequest </br>
	 * <b>Descripción:</b> Método propio de la implementación que setea el log
	 * del request del servicio a consumir</br>
	 * <b>Fecha Creación:</b> 25/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de última Modificación: 25/11/2022</b></br>
	 * <b>Modificado por: BABYLON Jose Andrés Sánchez Bernal</b></br>
	 *
	 * @param restWebServiceRequest
	 * @param completeURL
	 * @param method
	 * @param logger
	 */
	private void printRequest(RestWebServiceRequest restWebServiceRequest, String completeURL, HttpMethods method,
			Log logger) {
		logger.info("printRequest*");
		if (Validator.isNotNull(logger) && logger.isDebugEnabled()) {
			StringBuilder requestLog = new StringBuilder();
			requestLog.append("Method -> ");
			requestLog.append(method);
			requestLog.append(" Request URL [");
			requestLog.append(completeURL);
			requestLog.append(StringPool.CLOSE_BRACKET);
			requestLog.append(" Request body [");
			requestLog.append(restWebServiceRequest.getRequestBody());
			requestLog.append(StringPool.CLOSE_BRACKET);
			requestLog.append(" Request body mime-type [");
			requestLog.append(restWebServiceRequest.getRequestBodyMimeType());
			requestLog.append(StringPool.CLOSE_BRACKET);
			requestLog.append(" Headers [");

			if (Validator.isNotNull(restWebServiceRequest.getHeaders())
					&& !restWebServiceRequest.getHeaders().isEmpty()) {
				restWebServiceRequest.getHeaders().forEach((key, value) -> {
					requestLog.append(StringPool.OPEN_CURLY_BRACE);
					requestLog.append(key);
					requestLog.append(StringPool.COMMA);
					requestLog.append(value);
					requestLog.append(StringPool.CLOSE_CURLY_BRACE);
				});
			}
			requestLog.append(StringPool.CLOSE_BRACKET);
			logger.info("request: " + requestLog.toString());
		}
	}

	/**
	 * <b>Nombre: </b> setHeaders </br>
	 * <b>Descripción:</b> Método propio de la implementación que setea los
	 * headers del servicio a consumir </br>
	 * <b>Fecha Creación:</b> 25/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de última Modificación: 28/09/2024</b></br>
	 * <b>Modificado por: BABYLON Andrea Daza</b></br>
	 *
	 * @param httpMethod
	 * @param headers
	 * @param contenType
	 */
	private void setHeaders(HttpRequestBase httpMethod, Map<String, String> headers, String contenType)
			throws NoSuchOrganizationIdException, RestWebServiceClientException {

		try {
			ServiceContext serviceContext = serviceContextHelper.getServiceContext();
			User user = UserLocalServiceUtil.getUser(serviceContext.getUserId());
			httpMethod.setHeader(RestWebServiceConstants.KEY_UTILS_USER, user.getScreenName());
			long organizationId = CommonGenericUtilsUtil.getOrganizationId(user);
			httpMethod.setHeader(RestWebServiceConstants.KEY_UTILS_ORGANIZATION_ID, String.valueOf(organizationId));
		} catch (NoSuchOrganizationIdException e) {
			LOGGER.error("Error al obtener el organizationId en llamado a servicio web", e);
			throw e;
		} catch (PortalException e) {
			LOGGER.error("Error al obtener el usuario para trazabilidad en llamado a servicio web", e);
			throw new RestWebServiceClientException();
		}
		httpMethod.setHeader(RestWebServiceConstants.KEY_UTILS_ACCEPT, ContentTypes.APPLICATION_JSON);
		if (Validator.isNull(contenType) || !contenType.equals(ContentTypes.MULTIPART_FORM_DATA)) {
			httpMethod.setHeader(RestWebServiceConstants.KEY_UTILS_CONTENT_TYPE, ContentTypes.APPLICATION_JSON);
		}
		if (Validator.isNotNull(headers) && !headers.isEmpty()) {
			headers.forEach(httpMethod::setHeader);
		}

	}
	
	/**	<b>Nombre: </b> setHeaders </br>
	 * <b>Descripción:</b> Metodo Provisional mientras pasamos a consumo desde servicios</br>
	 * <b>Fecha Creación:</b> 2 dic. 2024 </br>
	 * <b>Autor:</b> Luis Alberto Aldana </br>
	 * <b>Fecha de Última Modificación: </b></br>
	 * <b>Modificado por: </b></br>
	 * @param httpMethod
	 * @param headers
	 * @param contenType
	 * @param enableSetOrganizationId
	 * @throws NoSuchOrganizationIdException
	 * @throws RestWebServiceClientException
	 */
	private void setHeaders(HttpRequestBase httpMethod, Map<String, String> headers, String contenType, boolean enableSetOrganizationId)
			throws NoSuchOrganizationIdException, RestWebServiceClientException {
		
		try {
			if (enableSetOrganizationId) {
				ServiceContext serviceContext = serviceContextHelper.getServiceContext();
				User user = UserLocalServiceUtil.getUser(serviceContext.getUserId());
				httpMethod.setHeader(RestWebServiceConstants.KEY_UTILS_USER, user.getScreenName());
				long organizationId = CommonGenericUtilsUtil.getOrganizationId(user);
				httpMethod.setHeader(RestWebServiceConstants.KEY_UTILS_ORGANIZATION_ID, String.valueOf(organizationId));
			}
			
		} catch (NoSuchOrganizationIdException e) {
			LOGGER.error("Error al obtener el organizationId en llamado a servicio web", e);
			throw e;
		} catch (PortalException e) {
			LOGGER.error("Error al obtener el usuario para trazabilidad en llamado a servicio web", e);
			throw new RestWebServiceClientException();
		}
		httpMethod.setHeader(RestWebServiceConstants.KEY_UTILS_ACCEPT, ContentTypes.APPLICATION_JSON);
		if (Validator.isNull(contenType) || !contenType.equals(ContentTypes.MULTIPART_FORM_DATA)) {
			httpMethod.setHeader(RestWebServiceConstants.KEY_UTILS_CONTENT_TYPE, ContentTypes.APPLICATION_JSON);
		}
		if (Validator.isNotNull(headers) && !headers.isEmpty()) {
			headers.forEach(httpMethod::setHeader);
		}

	}

	/**
	 * <b>Nombre: </b> getContentType </br>
	 * <b>Descripción:</b> Método propio de la implementación que obtiene el
	 * pórametro contentType definidio</br>
	 * <b>Fecha Creación:</b> 25/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de última Modificación: 25/11/2022</b></br>
	 * <b>Modificado por:BABYLON Jose Andrés Sánchez Bernal</b></br>
	 *
	 * @param mimeType
	 * @return ContentType
	 */
	private ContentType getContentType(String mimeType) {
		LOGGER.info("entro a getContentType " + mimeType);
		ContentType contentType = ContentType.getByMimeType(mimeType);
		if (Validator.isNull(contentType)) {
			return ContentType.APPLICATION_JSON;
		}
		return contentType;
	}

	/**
	 * <b>Nombre: </b> buildRequestURI </br>
	 * <b>Descripción:</b> Método propio de la implementación que concatena el
	 * request del servicio</br>
	 * <b>Fecha Creación:</b> 25/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de última Modificación: 13/01/2023</b></br>
	 * <b>Modificado por: BABYLON Jose Andrés Sánchez Bernal</b></br>
	 *
	 * @param requestUrl
	 * @param parameters
	 * @return URI
	 * @throws RestWebServiceClientException
	 */
	private URI buildRequestURI(String requestUrl, Map<String, String> parameters)
			throws RestWebServiceClientException {
		URIBuilder uriBuilder;
		try {
			uriBuilder = new URIBuilder(requestUrl);
			if (Validator.isNotNull(parameters) && !parameters.isEmpty()) {
				List<NameValuePair> postParameters = new LinkedList<>();
				parameters.forEach((key, value) -> postParameters.add(new BasicNameValuePair(key, value)));
				uriBuilder.addParameters(postParameters);
			}
			return uriBuilder.build();
		} catch (URISyntaxException e) {
			String errorMessage = BabylonCommonUtilsConstants.DEFAULT_MESSAGE_EXCEPTION_LOG_MESSAGE
					+ "error built request URI ";
			throw new RestWebServiceClientException(HttpStatus.SC_INTERNAL_SERVER_ERROR, errorMessage);
		}
	}

	/**
	 * <b>Nombre: </b> buildClient </br>
	 * <b>Descripción:</b> Método propio de la implementación que cierra la
	 * conección de tiempo de respuesta del servicio definida en segundos </br>
	 * <b>Fecha Creación:</b> 25/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de última Modificación: 13/01/2023</b></br>
	 * <b>Modificado por: BABYLON Jose Andrés Sánchez Bernal</b></br>
	 *
	 * @param usesProxy
	 * @return CloseableHttpClient
	 */
	private CloseableHttpClient buildClient(Boolean usesProxy) {

		if (usesProxy == null) {
			usesProxy = Boolean.FALSE;
		}

		HttpClientBuilder builder = HttpClientBuilder.create();

		builder.useSystemProperties();
		if (usesProxy) {
			builder.setProxy(new HttpHost(connectionPropertiesConfiguration.proxyHostname(),
					connectionPropertiesConfiguration.proxyPort()));
		}
		builder.setDefaultRequestConfig(RequestConfig.custom()
				.setConnectTimeout(connectionPropertiesConfiguration.connectTimeout()
						* BabylonCommonUtilsConstants.KEY_NUM_PROPERTIES_UTIL_MILLISECONDS_BY_SECOND)
				.setConnectionRequestTimeout(connectionPropertiesConfiguration.connectionRequestTimeout()
						* BabylonCommonUtilsConstants.KEY_NUM_PROPERTIES_UTIL_MILLISECONDS_BY_SECOND)
				.setSocketTimeout(connectionPropertiesConfiguration.socketTimeout()
						* BabylonCommonUtilsConstants.KEY_NUM_PROPERTIES_UTIL_MILLISECONDS_BY_SECOND)
				.build());
		return builder.build();
	}

	/**
	 * <b>Nombre: </b> parseServiceResponse </br>
	 * <b>Descripción:</b> Método propio de la implementación que convierte y/o
	 * parsea la respuesta del servicio y sus controles de errores</br>
	 * <b>Fecha Creación:</b> 25/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de última Modificación: 13/01/2023</b></br>
	 * <b>Modificado por: BABYLON Jose Andrés Sánchez Bernal</b></br>
	 *
	 * @param response
	 * @return JSONObject
	 * @throws RestWebServiceClientException
	 */
	private JSONObject parseServiceResponse(String url, CloseableHttpResponse response)
			throws RestWebServiceClientException {

		HttpEntity resEntity = response.getEntity();
		String streamResponse = StringPool.BLANK;
		int responseCode = response.getStatusLine().getStatusCode();

		try {
			streamResponse = convertStreamToString(resEntity.getContent());
		} catch (UnsupportedOperationException | IOException e) {
			String errorMessage = BabylonCommonUtilsConstants.DEFAULT_MESSAGE_EXCEPTION_LOG_MESSAGE
					+ "Error getting String response [" + url + "] ";

			throw new RestWebServiceClientException(response.getStatusLine().getStatusCode(), errorMessage,
					streamResponse);
		}

		if (HttpStatus.SC_OK != responseCode && HttpStatus.SC_CREATED != responseCode
				&& HttpStatus.SC_INTERNAL_SERVER_ERROR != responseCode) {

			String errorMessage = BabylonCommonUtilsConstants.DEFAULT_MESSAGE_EXCEPTION_LOG_MESSAGE
					+ "Service consumption error [" + url + "] ";

			throw new RestWebServiceClientException(response.getStatusLine().getStatusCode(), errorMessage,
					streamResponse);
		} else {

			JSONObject jsonObject = parseJSONResponse(streamResponse);
			if (Validator.isNotNull(jsonObject)) {
				return jsonObject;
			}
			jsonObject = JSONFactoryUtil.createJSONObject();
			JSONArray jsonArray = parseJSONArrayResponse(streamResponse);
			if (Validator.isNotNull(jsonArray)) {
				jsonObject.put(RestWebServiceConstants.KEY_UTILS_RESULT, parseJSONArrayResponse(streamResponse));
				return jsonObject;
			}
			return jsonObject.put(RestWebServiceConstants.KEY_UTILS_RESULT, streamResponse);
		}

	}

	/**
	 * <b>Nombre: </b> parseJSONResponse </br>
	 * <b>Descripción:</b> Método propio de la implementación que convierte y/o
	 * parsea un string a un JsonObject</br>
	 * <b>Fecha Creación:</b> 25/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de última Modificación: 13/01/2023</b></br>
	 * <b>Modificado por: BABYLON Jose Andrés Sánchez Bernal</b></br>
	 *
	 * @param serviceResponse
	 * @return JSONObject
	 */
	private JSONObject parseJSONResponse(String serviceResponse) {
		try {
			return JSONFactoryUtil.createJSONObject(serviceResponse);
		} catch (JSONException e) {
			return null;
		}
	}

	/**
	 * <b>Nombre: </b> parseJSONArrayResponse </br>
	 * <b>Descripción:</b> Método propio de la implementación que convierte y/o
	 * parsea un string a un array de estructura json</br>
	 * <b>Fecha Creación:</b> 25/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de última Modificación: 13/01/2023</b></br>
	 * <b>Modificado por: BABYLON Jose Andrés Sánchez Bernal</b></br>
	 *
	 * @param serviceResponse
	 * @return JSONArray
	 */
	private JSONArray parseJSONArrayResponse(String serviceResponse) {
		try {
			return JSONFactoryUtil.createJSONArray(serviceResponse);
		} catch (JSONException e) {
			return null;
		}
	}

	/**
	 * <b>Nombre: </b> convertStreamToString </br>
	 * <b>Descripción:</b> Método propio de la implementación que parsea y/o
	 * convierte un obj InputStream a string para el control de errores</br>
	 * <b>Fecha Creación:</b> 25/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de última Modificación: 13/01/2023</b></br>
	 * <b>Modificado por: BABYLON Jose Andrés Sánchez Bernal</b></br>
	 *
	 * @param is
	 * @return String
	 * @throws RestWebServiceClientException
	 */
	private String convertStreamToString(InputStream is) throws RestWebServiceClientException {
		BufferedReader reader = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
		StringBuilder sb = new StringBuilder();
		String line = null;
		try {
			while (Validator.isNotNull((line = reader.readLine()))) {
				sb.append(line).append(StringPool.NEW_LINE);
			}
		} catch (IOException e) {
			String errorMessage = BabylonCommonUtilsConstants.DEFAULT_MESSAGE_EXCEPTION_LOG_MESSAGE + e.getMessage()
					+ StringPool.COMMA + "error get response";
			throw new RestWebServiceClientException(HttpStatus.SC_INTERNAL_SERVER_ERROR, errorMessage);
		} finally {
			try {
				is.close();
			} catch (IOException e) {
				String errorMessage = BabylonCommonUtilsConstants.DEFAULT_MESSAGE_EXCEPTION_LOG_MESSAGE + e.getMessage()
						+ StringPool.COMMA + "error closing connection";
				throw new RestWebServiceClientException(HttpStatus.SC_INTERNAL_SERVER_ERROR, errorMessage);
			}
		}
		return sb.toString();
	}

	/**
	 * <b>Nombre: </b> activate </br>
	 * <b>Descripción:</b> Implementación del Método que activa la configuración
	 * del modulo en liferay para la api Encryption</br>
	 * <b>Fecha Creación:</b> 25/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de última Modificación: 13/01/2023</b></br>
	 * <b>Modificado por: BABYLON Jose Andrés Sánchez Bernal</b></br>
	 * 
	 * @param properties
	 */
	@Activate
	@Modified
	protected void activate(Map<String, Object> properties) {
		connectionPropertiesConfiguration = ConfigurableUtil.createConfigurable(ConnectionPropertiesConfiguration.class,
				properties);
	}

}