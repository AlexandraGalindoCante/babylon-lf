package com.babylon.utils.common.api.impl;

import com.babylon.utils.common.api.ValidatorUtilApi;
import com.babylon.utils.common.api.constants.BabylonCommonUtilsConstants;
import com.babylon.utils.common.api.model.ValidatorRulesDto;
import com.babylon.utils.common.api.util.CommonGenericUtilsUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.util.Validator;

import org.osgi.service.component.annotations.Component;

/**
 * <b>Nombre: </b> ValidatorUtilImpl </br>
 * <b>Descripci�n:</b> Clase de implementaci�n que expone m�todos para validar
 * los parametros</br>
 * <b>Fecha Creaci�n:</b> 30/11/2022 </br>
 * <b>Autor:BABYLON Jose Andr�s S�nchez Bernal </br>
 * <b>Fecha de �ltima Modificaci�n: </b></br>
 * <b>Modificado por: </b></br>
 */
@Component(service = ValidatorUtilApi.class)
public class ValidatorUtilImpl implements ValidatorUtilApi {

	/**
	 * <b>Nombre: </b> validateAttributeAction </br>
	 * <b>Descripci�n:</b> </br>
	 * <b>Fecha Creaci�n:</b> 5/12/2022 </br>
	 * <b>Autor:BABYLON Jose Andr�s S�nchez Bernal </br>
	 * <b>Fecha de �ltima Modificaci�n: </b></br>
	 * <b>Modificado por: </b></br>
	 * 
	 * @param validatorRulesDto
	 * @param value
	 * @param message
	 * @param response
	 * @return
	 */
	@Override
	public boolean validateAttributeAction(ValidatorRulesDto validatorRulesDto, String value, String message,
			JSONObject response) {
		boolean validate = false;

		validate = validateAttribute(validatorRulesDto, value);
		if (!validate) {
			setResultToResponse(message, response);
			return false;
		}
		return true;
	}

	/**
	 * <b>Nombre: </b> validateAttribute </br>
	 * <b>Descripci�n:</b> Implementaci�n del m�todo para validar los p�rametros de
	 * entrada sin importar el tipo</br>
	 * <b>Fecha Creaci�n:</b> 30/11/2022 </br>
	 * <b>Autor:BABYLON Jose Andr�s S�nchez Bernal </br>
	 * <b>Fecha de �ltima Modificaci�n: </b></br>
	 * <b>Modificado por: </b></br>
	 * 
	 * @param value
	 * @param validatorRulesDto
	 * @return
	 */

	public boolean validateAttribute(ValidatorRulesDto validatorRulesDto, String value) {
		boolean validateAttribute = Boolean.TRUE;
		if (validatorRulesDto.isRequired()) {
			if (!CommonGenericUtilsUtil.requiredAttribute(value))
				validateAttribute = Boolean.FALSE;
		}

		if (validatorRulesDto.isDigits()) {
			if (!Validator.isDigit(value))
				validateAttribute = Boolean.FALSE;
		}

		if (validatorRulesDto.isDecimal()) {
			if (!CommonGenericUtilsUtil.isValidDecimal4(value))
				validateAttribute = Boolean.FALSE;
		}

		if (validatorRulesDto.isEmail()) {
			if (!Validator.isEmailAddress(value))
				validateAttribute = Boolean.FALSE;
		}

		if (validatorRulesDto.isMinYear()) {
			if (!CommonGenericUtilsUtil.validateMinYear(value, validatorRulesDto.getMinYears()))
				validateAttribute = Boolean.FALSE;
		}

		if (validatorRulesDto.isMaxYear()) {
			if (!CommonGenericUtilsUtil.validateMaxYear(value, validatorRulesDto.getMaxYears()))
				validateAttribute = Boolean.FALSE;
		}

		if (validatorRulesDto.getMinLength() != 0) {
			if (!CommonGenericUtilsUtil.minLengthAttribute(value, validatorRulesDto.getMinLength()))
				validateAttribute = Boolean.FALSE;
		}

		if (validatorRulesDto.getMaxLength() != 0) {
			if (!CommonGenericUtilsUtil.maxLengthAttribute(value, validatorRulesDto.getMaxLength()))
				validateAttribute = Boolean.FALSE;
		}

		if (validatorRulesDto.isLetters()) {
			if (!Validator.isName(value))
				validateAttribute = Boolean.FALSE;
		}

		if (Validator.isNotNull(validatorRulesDto.getStartWith()) && !validatorRulesDto.getStartWith().isEmpty()) {
			if (!value.startsWith(validatorRulesDto.getStartWith()))
				validateAttribute = Boolean.FALSE;
		}

		if (Validator.isNotNull(validatorRulesDto.getStartWithOr())) {
			String[] startWithOr = validatorRulesDto.getStartWithOr();
			if (startWithOr.length > 0) {
				for (String starWith : startWithOr) {
					if (!value.startsWith(starWith)) {
						validateAttribute = Boolean.FALSE;
					}
				}
			}
		}

		if (Validator.isNotNull(validatorRulesDto.getDateFormat()) && !validatorRulesDto.getDateFormat().isEmpty()) {
			if (!CommonGenericUtilsUtil.dateFormatAttribute(value, validatorRulesDto.getDateFormat()))
				validateAttribute = Boolean.FALSE;
		}

		return validateAttribute;
	}

	/**
	 * <b>Nombre: </b> setResultToResponse </br>
	 * <b>Descripci�n:</b> </br>
	 * <b>Fecha Creaci�n:</b> 5/12/2022 </br>
	 * <b>Autor:BABYLON Jose Andr�s S�nchez Bernal </br>
	 * <b>Fecha de �ltima Modificaci�n: </b></br>
	 * <b>Modificado por: </b></br>
	 * 
	 * @param message
	 * @param response
	 */
	private static void setResultToResponse(String message, JSONObject response) {
		response.put(BabylonCommonUtilsConstants.KEY_UTILS_ERROR, true);
		response.put(BabylonCommonUtilsConstants.KEY_UTILS_SHOW, true);
		response.put(BabylonCommonUtilsConstants.KEY_UTILS_MESSAGE, message);
	}
}
