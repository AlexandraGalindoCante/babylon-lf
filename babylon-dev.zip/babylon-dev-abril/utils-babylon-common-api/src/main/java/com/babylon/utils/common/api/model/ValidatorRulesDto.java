package com.babylon.utils.common.api.model;

import java.util.Arrays;

/**
 * <b>Nombre: </b> ValidatorRulesDto </br>
 * <b>Descripci�n:</b> Clase modelo para generar un dto para el api de
 * ValidatorUtilApi </br>
 * <b>Fecha Creaci�n:</b> 30/11/2022 </br>
 * <b>Autor:BABYLON Jose Andr�s S�nchez Bernal </br>
 * <b>Fecha de �ltima Modificaci�n: </b></br>
 * <b>Modificado por: </b></br>
 */
public class ValidatorRulesDto {

	private boolean required;
	private boolean digits;
	private boolean decimal;
	private boolean letters;
	private boolean lettersES;
	private boolean email;
	private boolean minYear;
	private boolean maxYear;
	private int minYears;
	private int maxYears;
	private int minLength;
	private int maxLength;
	private String startWith;
	private String[] startWithOr;
	private String dateFormat;

	public boolean isRequired() {
		return required;
	}

	public void setRequired(boolean required) {
		this.required = required;
	}

	public boolean isDigits() {
		return digits;
	}

	public void setDigits(boolean digits) {
		this.digits = digits;
	}

	public boolean isDecimal() {
		return decimal;
	}

	public void setDecimal(boolean decimal) {
		this.decimal = decimal;
	}

	public boolean isEmail() {
		return email;
	}

	public void setEmail(boolean email) {
		this.email = email;
	}

	public boolean isMinYear() {
		return minYear;
	}

	public void setMinYear(boolean minYear) {
		this.minYear = minYear;
	}

	public int getMinYears() {
		return minYears;
	}

	public void setMinYears(int minYears) {
		this.minYears = minYears;
	}

	public int getMaxYears() {
		return maxYears;
	}

	public void setMaxYears(int maxYears) {
		this.maxYears = maxYears;
	}

	public boolean isMaxYear() {
		return maxYear;
	}

	public void setMaxYear(boolean maxYear) {
		this.maxYear = maxYear;
	}

	public String getStartWith() {
		return startWith;
	}

	public void setStartWith(String startWith) {
		this.startWith = startWith;
	}

	public String getDateFormat() {
		return dateFormat;
	}

	public void setDateFormat(String dateFormat) {
		this.dateFormat = dateFormat;
	}

	public int getMinLength() {
		return minLength;
	}

	public void setMinLength(int minLength) {
		this.minLength = minLength;
	}

	public int getMaxLength() {
		return maxLength;
	}

	public void setMaxLength(int maxLength) {
		this.maxLength = maxLength;
	}

	public boolean isLetters() {
		return letters;
	}

	public void setLetters(boolean letters) {
		this.letters = letters;
	}

	public boolean isLettersES() {
		return lettersES;
	}

	public void setLettersES(boolean lettersES) {
		this.lettersES = lettersES;
	}

	public String[] getStartWithOr() {
		return startWithOr;
	}

	public void setStartWithOr(String[] startWithOr) {
		this.startWithOr = startWithOr;
	}

	@Override
	public String toString() {
		return "Rules [required=" + required + ", digits=" + digits + ", letters=" + letters + ", lettersES="
				+ lettersES + ", email=" + email + ", minYear=" + minYear + ", maxYear=" + maxYear + ", minYears="
				+ minYears + ", maxYears=" + maxYears + ", minLength=" + minLength + ", maxLength=" + maxLength
				+ ", startWith=" + startWith + ", startWithOr=" + Arrays.toString(startWithOr) + ", dateFormat="
				+ dateFormat + "]";
	}

}
