package com.babylon.utils.common.api.request;

import com.liferay.portal.kernel.json.JSONObject;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

/**
 * <b>Nombre: </b> RestWebServiceRequest </br>
 * <b>Descripci�n:</b> Clase Dto para la respuesta de los servicios </br>
 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
 * <b>Autor:BABYLON Ricardo Salinas</br>
 * <b>Fecha de �ltima Modificaci�n: 22/11/2022 </b></br>
 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
 */
public class RestWebServiceRequest {

	private String requestUrl;
	private String requestBody;
	private Boolean usesProxy;
	private String requestBodyMimeType;
	private Map<String, String> headers;
	private Map<String, String> parameters;
	/* Authorization settings */
	private String authorizationType;
	private String accessTokenURL;
	private String clientID;
	private String clientSecret;
	private String scope;
	private String grantType;
	private Map<String, File> attachments;

	/**
	 * <b>Nombre: </b> RequestBuilder </br>
	 * <b>Descripci�n:</b> Clase Dto objeto interno dentro de la respueesta de los
	 * servicios. </br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas </br>
	 * <b>Fecha de �ltima Modificaci�n: 22/11/2022 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 */
	public static class RequestBuilder {
	    
	    private static final String USERNAME_STR = "username";
        private static final String PASSW_STR = "password";
        private static final String GRANT_TYPE = "grant_type";
        private static final String CLIENT_CREDENTIALS = "client_credentials";

		private String requestUrl;
		private String requestBody;
		private Map<String, String> headers;
		private Map<String, String> parameters;
		private String requestBodyMimeType;
		private Boolean usesProxy;
		private String authorizationType;
		private String accessTokenURL;
		private String clientID;
		private String clientSecret;
		private String scope;
		private String grantType;
		private Map<String, File> attachments;
		

        // Tokenized Request
        private String authToken;
        private Map<String, String> tokenRequestParams;

		public RequestBuilder() {

		}

		public RequestBuilder requestURL(String requestUrl) {
			this.requestUrl = requestUrl;

			return this;
		}

		public RequestBuilder requestBodyMimeType(String requestBodyMimeType) {
			this.requestBodyMimeType = requestBodyMimeType;
			return this;
		}

		public RequestBuilder requestBody(String requestBody) {
			this.requestBody = requestBody;
			return this;
		}

		public RequestBuilder requestBody(JSONObject requestBody) {
			if (requestBody != null) {
				this.requestBody = requestBody.toString();
			}
			return this;
		}

		public RequestBuilder requestHeaders(Map<String, String> headers) {
			this.headers = headers;
			return this;
		}

		public RequestBuilder usesProxy(Boolean usesProxy) {
			this.usesProxy = usesProxy;
			return this;
		}

		public RequestBuilder requestParameters(Map<String, String> parameters) {
			this.parameters = parameters;
			return this;
		}

		public RequestBuilder authorizationType(String authorizationType) {
			this.authorizationType = authorizationType;
			return this;
		}

		public RequestBuilder accessTokenURL(String accessTokenURL) {
			this.accessTokenURL = accessTokenURL;
			return this;
		}

		public RequestBuilder clientID(String clientID) {
			this.clientID = clientID;
			return this;
		}

		public RequestBuilder clientSecret(String clientSecret) {
			this.clientSecret = clientSecret;
			return this;
		}

		public RequestBuilder scope(String scope) {
			this.scope = scope;
			return this;
		}

		public RequestBuilder grantType(String grantType) {
			this.grantType = grantType;
			return this;
		}

		public RequestBuilder attachments(Map<String, File> attachments) {
			this.attachments = attachments;
			return this;
		}

		public RestWebServiceRequest build() {
			return new RestWebServiceRequest(this);
		}
		
	    /**
         * grant_type: client_credentials
         */
        public RequestBuilder tokenizedRequestWithCredentials(String authToken) {
            this.authToken = authToken;
            
            this.tokenRequestParams = new HashMap<>();
            tokenRequestParams.put(GRANT_TYPE, CLIENT_CREDENTIALS);
            
            return this;
        }
	}

	/**
	 * <b>Nombre: </b> RestWebServiceRequest </br>
	 * <b>Descripci�n:</b> Constructor de la clase </br>
	 * <b>Fecha Creaci�n:</b> 22/11/2022 </br>
	 * <b>Autor:BABYLON Ricardo Salinas</br>
	 * <b>Fecha de �ltima Modificaci�n: 22/11/2022 </b></br>
	 * <b>Modificado por: BABYLON Jose Andr�s S�nchez Bernal </b></br>
	 * 
	 * @param builder
	 */
	private RestWebServiceRequest(RequestBuilder builder) {
		this.requestUrl = builder.requestUrl;
		this.requestBody = builder.requestBody;
		this.headers = builder.headers;
		this.parameters = builder.parameters;
		this.requestBodyMimeType = builder.requestBodyMimeType;
		this.usesProxy = builder.usesProxy;
		/* Authorization settings */
		this.authorizationType = builder.authorizationType;
		this.accessTokenURL = builder.accessTokenURL;
		this.clientID = builder.clientID;
		this.clientSecret = builder.clientSecret;
		this.scope = builder.scope;
		this.grantType = builder.grantType;
		this.attachments = builder.attachments;
	}

	public String getRequestUrl() {
		return requestUrl;
	}

	public String getRequestBodyMimeType() {
		return requestBodyMimeType;
	}

	public String getRequestBody() {
		return requestBody;
	}

	public Map<String, String> getHeaders() {
		return headers;
	}

	public void setHeaders(Map<String, String> headers) {
		this.headers = headers;
	}

	public void setHeader(String key, String value) {
		if (headers == null) {
			headers = new HashMap<>();
		}
		headers.put(key, value);
	}

	public Map<String, String> getParameters() {
		return parameters;
	}

	public Boolean getUsesProxy() {
		return usesProxy;
	}

	public String getAuthorizationType() {
		return authorizationType;
	}

	public void setAuthorizationType(String authorizationType) {
		this.authorizationType = authorizationType;
	}

	public String getAccessTokenURL() {
		return accessTokenURL;
	}

	public void setAccessTokenURL(String accessTokenURL) {
		this.accessTokenURL = accessTokenURL;
	}

	public String getClientID() {
		return clientID;
	}

	public void setClientID(String clientID) {
		this.clientID = clientID;
	}

	public String getClientSecret() {
		return clientSecret;
	}

	public void setClientSecret(String clientSecret) {
		this.clientSecret = clientSecret;
	}

	public String getScope() {
		return scope;
	}

	public void setScope(String scope) {
		this.scope = scope;
	}

	public void setUsesProxy(Boolean usesProxy) {
		this.usesProxy = usesProxy;
	}

	public void setRequestUrl(String requestUrl) {
		this.requestUrl = requestUrl;
	}

	public void setRequestBody(String requestBody) {
		this.requestBody = requestBody;
	}

	public String getGrantType() {
		return grantType;
	}

	public void setGrantType(String grantType) {
		this.grantType = grantType;
	}

	public void setRequestBodyMimeType(String requestBodyMimeType) {
		this.requestBodyMimeType = requestBodyMimeType;
	}

	public Map<String, File> getAttachments() {
		return attachments;
	}

	public void setAttachments(Map<String, File> attachments) {
		this.attachments = attachments;
	}

	public void addAttachment(String key, File value) {
		if (getAttachments() == null) {
			attachments = new HashMap<>();
		}
		attachments.put(key, value);
	}
}
