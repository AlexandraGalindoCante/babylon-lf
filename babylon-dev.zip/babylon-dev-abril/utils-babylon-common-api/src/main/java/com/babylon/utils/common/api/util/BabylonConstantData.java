package com.babylon.utils.common.api.util;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.repository.model.FileEntry;
import com.liferay.portal.kernel.service.ClassNameLocalServiceUtil;

public class BabylonConstantData {

    private static final Log LOGGER = LogFactoryUtil.getLog(BabylonConstantData.class);

    private static BabylonConstantData babylonConstantData;

    private static Long fileEntryClassNameId = 0L;

    private  BabylonConstantData(){
        fileEntryClassNameId = ClassNameLocalServiceUtil.getClassNameId(FileEntry.class.getName());
    }

    public static Long getFileEntryClassNameId (){
        if (babylonConstantData == null) {
            babylonConstantData = new BabylonConstantData();
        }
        return fileEntryClassNameId;
    }
}
