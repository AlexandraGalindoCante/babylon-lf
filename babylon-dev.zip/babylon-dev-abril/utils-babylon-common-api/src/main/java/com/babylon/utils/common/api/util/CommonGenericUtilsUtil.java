package com.babylon.utils.common.api.util;

import com.babylon.utils.common.api.constants.BabylonCommonUtilsConstants;
import com.babylon.utils.common.api.exceptions.NoSuchOrganizationIdException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.json.JSONArray;
import com.liferay.portal.kernel.json.JSONException;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.UserLocalServiceUtil;
import com.liferay.portal.kernel.util.Validator;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.regex.Pattern;

/**
 * <b>Nombre: </b> CommonGenericUtilsUtil </br>
 * <b>Descripci�n:</b> M�todo que ofrece utilitarios transversales para la api y
 * su desarrollo</br>
 * <b>Fecha Creaci�n:</b> 30/11/2022 </br>
 * <b>Autor:BABYLON Jose Andr�s S�nchez Bernal </br>
 * <b>Fecha de �ltima Modificaci�n: </b></br>
 * <b>Modificado por: </b></br>
 */
public class CommonGenericUtilsUtil {

	private CommonGenericUtilsUtil() {
	}

	/**
	 * <b>Nombre: </b> requiredAttribute </br>
	 * <b>Descripci�n:</b> M�todo que valida que el p�rametro no este nulo o vacio
	 * </br>
	 * <b>Fecha Creaci�n:</b> 30/11/2022 </br>
	 * <b>Autor:BABYLON Jose Andr�s S�nchez Bernal </br>
	 * <b>Fecha de �ltima Modificaci�n: </b></br>
	 * <b>Modificado por: </b></br>
	 * 
	 * @param value
	 * @return
	 */
	public static boolean requiredAttribute(String value) {
		if (Validator.isNull(value) || value.isEmpty())
			return false;

		return true;
	}

	/**
	 * <b>Nombre: </b> maxLengthAttribute </br>
	 * <b>Descripci�n:</b> M�todo que valida el p�rametro supere la cantidad maxima
	 * de caracteres establecidas</br>
	 * <b>Fecha Creaci�n:</b> 30/11/2022 </br>
	 * <b>Autor:BABYLON Jose Andr�s S�nchez Bernal </br>
	 * <b>Fecha de �ltima Modificaci�n: </b></br>
	 * <b>Modificado por: </b></br>
	 * 
	 * @param value
	 * @param max
	 * @return
	 */
	public static boolean maxLengthAttribute(String value, int max) {

		if (Validator.isNull(value)) {
			return false;
		}

		if (value.length() > max) {
			return false;
		}

		return true;
	}

	/**
	 * <b>Nombre: </b> minLengthAttribute </br>
	 * <b>Descripci�n:</b> M�todo que valida el p�rametro no supere la cantidad
	 * minima de caracteres establecidas</br>
	 * <b>Fecha Creaci�n:</b> 30/11/2022 </br>
	 * <b>Autor:BABYLON Jose Andr�s S�nchez Bernal </br>
	 * <b>Fecha de �ltima Modificaci�n: </b></br>
	 * <b>Modificado por: </b></br>
	 * 
	 * @param value
	 * @param min
	 * @return
	 */
	public static boolean minLengthAttribute(String value, int min) {

		if (Validator.isNull(value)) {
			return false;
		}

		if (value.length() < min) {
			return false;
		}

		return true;
	}

	/**
	 * <b>Nombre: </b> dateFormatAttribute </br>
	 * <b>Descripci�n:</b> M�todo que valida el p�rametro de tipo fecha y cumpla uno
	 * de los formator establecidos</br>
	 * <b>Fecha Creaci�n:</b> 30/11/2022 </br>
	 * <b>Autor:BABYLON Jose Andr�s S�nchez Bernal </br>
	 * <b>Fecha de �ltima Modificaci�n: </b></br>
	 * <b>Modificado por: </b></br>
	 * 
	 * @param value
	 * @param format
	 * @return
	 */
	public static boolean dateFormatAttribute(String value, String format) {

		switch (format) {
		case BabylonCommonUtilsConstants.KEY_VALIDATOR_DATE_FORMAT1:
			if (!Pattern.matches(BabylonCommonUtilsConstants.KEY_VALIDATOR_DATE_REGEXP1, value))
				return false;
			break;
		case BabylonCommonUtilsConstants.KEY_VALIDATOR_DATE_FORMAT2:
			if (!Pattern.matches(BabylonCommonUtilsConstants.KEY_VALIDATOR_DATE_REGEXP2, value))
				return false;
			break;
		case BabylonCommonUtilsConstants.KEY_VALIDATOR_DATE_FORMAT3:
			if (!Pattern.matches(BabylonCommonUtilsConstants.KEY_VALIDATOR_DATE_REGEXP3, value))
				return false;
			break;
		case BabylonCommonUtilsConstants.KEY_VALIDATOR_DATE_FORMAT4:
			if (!Pattern.matches(BabylonCommonUtilsConstants.KEY_VALIDATOR_DATE_REGEXP4, value))
				return false;
			break;
		case BabylonCommonUtilsConstants.KEY_VALIDATOR_DATE_FORMAT5:
			if (!Pattern.matches(BabylonCommonUtilsConstants.KEY_VALIDATOR_DATE_REGEXP5, value))
				return false;
			break;
		case BabylonCommonUtilsConstants.KEY_VALIDATOR_DATE_FORMAT7:
			if (!Pattern.matches(BabylonCommonUtilsConstants.KEY_VALIDATOR_DATE_REGEXP5, value))
				return false;
			break;
		case BabylonCommonUtilsConstants.KEY_VALIDATOR_DATE_FORMAT8:
			if (!Pattern.matches(BabylonCommonUtilsConstants.KEY_VALIDATOR_DATE_REGEXP8, value))
				return false;
			break;
		default:

			return false;
		}
		return true;
	}

	/**
	 * <b>Nombre: </b> lettersES </br>
	 * <b>Descripci�n:</b> M�todo utilitsrio para el tipo de lenguaje a usar y
	 * validaci�n de texto</br>
	 * <b>Fecha Creaci�n:</b> 30/11/2022 </br>
	 * <b>Autor:BABYLON Jose Andr�s S�nchez Bernal </br>
	 * <b>Fecha de �ltima Modificaci�n: </b></br>
	 * <b>Modificado por: </b></br>
	 * 
	 * @param value
	 * @return
	 */
	public static boolean lettersES(String value) {
		if (!Pattern.matches(BabylonCommonUtilsConstants.KEY_VALIDATOR_NAMES_REGEXP, value))
			return false;

		return true;
	}

	/**
	 * <b>Nombre: </b> validateMinYear </br>
	 * <b>Descripci�n:</b> M�todo que valida el p�rametro supere la edad minima
	 * establecida</br>
	 * <b>Fecha Creaci�n:</b> 30/11/2022 </br>
	 * <b>Autor:BABYLON Jose Andr�s S�nchez Bernal </br>
	 * <b>Fecha de �ltima Modificaci�n: </b></br>
	 * <b>Modificado por: </b></br>
	 * 
	 * @param value
	 * @param minYears
	 * @return
	 */
	public static boolean validateMinYear(String value, int minYears) {
		String fechaNacimiento = value;
		LocalDate fechaNacimientoDate = LocalDate.parse(fechaNacimiento, DateTimeFormatter.ofPattern("dd/MM/yyyy"));
		LocalDate now = LocalDate.now();

		Period periodo = Period.between(fechaNacimientoDate, now);

		if (periodo.getYears() < minYears)
			return false;

		return true;
	}

	/**
	 * <b>Nombre: </b> validateMaxYear </br>
	 * <b>Descripci�n:</b> M�todo que valida el p�rametro no supere la edad maxima
	 * establecida</br>
	 * <b>Fecha Creaci�n:</b> 30/11/2022 </br>
	 * <b>Autor:BABYLON Jose Andr�s S�nchez Bernal </br>
	 * <b>Fecha de �ltima Modificaci�n: </b></br>
	 * <b>Modificado por: </b></br>
	 * 
	 * @param value
	 * @param maxYears
	 * @return
	 */
	public static boolean validateMaxYear(String value, int maxYears) {
		String fechaNacimiento = value;
		LocalDate fechaNacimientoDate = LocalDate.parse(fechaNacimiento, DateTimeFormatter.ofPattern("dd/MM/yyyy"));
		LocalDate now = LocalDate.now();

		Period periodo = Period.between(fechaNacimientoDate, now);
		if (periodo.getYears() > maxYears)
			return false;
		return true;
	}

	/**
	 * <b>Nombre: </b> findInJsonArrayByLongValue </br>
	 * <b>Descripci�n:</b> </br>
	 * <b>Fecha Creaci�n:</b> 12/02/2024 </br>
	 * <b>Autor:</b> Luis Alberto Aldana </br>
	 * <b>Fecha de �ltima Modificaci�n: </b></br>
	 * <b>Modificado por: </b></br>
	 * 
	 * @param jsonArray
	 * @param key
	 * @param idToSearch
	 * @return
	 */
	public static boolean findInJsonArrayByLongValue(JSONArray jsonArray, String key, long idToSearch) {
		boolean exist = false;
		for (int i = 0; i < jsonArray.length(); i++) {
			JSONObject jsonObject = jsonArray.getJSONObject(i);
			if (jsonObject.getLong(key) == idToSearch) {
				return true;
			}
		}
		return exist;
	}

	public static <T> JSONArray convertEntityListToJSONArray(List<T> entityList) {

		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.disable(SerializationFeature.FAIL_ON_EMPTY_BEANS);
		try {
			String entityListJson = objectMapper.writeValueAsString(entityList);
			JSONArray jsonArray = JSONFactoryUtil.createJSONArray(entityListJson);
			return jsonArray;
		} catch (JsonProcessingException | JSONException e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * <b>Nombre: </b> isValidDecimal4 </br>
	 * <b>Descripción:</b> </br>
	 * <b>Fecha Creación:</b> 31/05/2024 </br>
	 * <b>Autor:</b> Luis Alberto Aldana </br>
	 * <b>Fecha de Última Modificación: </b></br>
	 * <b>Modificado por: </b></br>
	 * 
	 * @param value
	 * @return
	 */
	public static boolean isValidDecimal4(String value) {
		if (value == null || value.isEmpty()) {
			return false;
		}
		return BabylonCommonUtilsConstants.DECIMAL_4_PATTERN.matcher(value).matches();
	}

	/**
	 * Retorna el texto de status correspondiente
	 * @param state
	 * @return
	 */
	public static String getStateText(Boolean state) {
		return Boolean.TRUE.equals(state) ? BabylonCommonUtilsConstants.State.ACTIVE : BabylonCommonUtilsConstants.State.INACTIVE;
	}

	/***
	 * Retorna la clave de status de acuerdo a los boolean de las tablas liferay
	 * @param active
	 * @param disabled
	 * @return
	 */
	public static String getStateText(Boolean active, Boolean disabled) {
		return Boolean.TRUE.equals(active) ? BabylonCommonUtilsConstants.State.ACTIVE : Boolean.TRUE.equals(disabled) ? BabylonCommonUtilsConstants.State.DELETED : BabylonCommonUtilsConstants.State.INACTIVE;
	}

	/**
	 * Retorna el boolean de acuerdo al texto
	 * @param state
	 * @return
	 */
	public static Boolean getStateValue(String state) {
		return BabylonCommonUtilsConstants.State.ACTIVE.equals(state);
	}

	public static long getOrganizationId(User user) throws NoSuchOrganizationIdException{
		if (Validator.isNotNull(user) && user.getExpandoBridge().hasAttribute(BabylonCommonUtilsConstants.KEY_UTILS_ORGANIZATIONID)) {
			return (long) user.getExpandoBridge()
					.getAttribute(BabylonCommonUtilsConstants.KEY_UTILS_ORGANIZATIONID);
		}
		throw new NoSuchOrganizationIdException();
	}

	public static long getOrganizationId(ServiceContext serviceContext) throws NoSuchOrganizationIdException, PortalException {
		if(serviceContext != null) {
			User user = UserLocalServiceUtil.getUser(serviceContext.getUserId());
			return getOrganizationId(user);
		}
		throw new PortalException("ServiceContext is null");
	}

}
