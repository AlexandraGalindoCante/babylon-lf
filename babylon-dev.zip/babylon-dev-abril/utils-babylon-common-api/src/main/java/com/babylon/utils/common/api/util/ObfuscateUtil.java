package com.babylon.utils.common.api.util;

public class ObfuscateUtil {

	/**
	 * <b>Nombre: </b> obfuscatePhoneNumber </br>
	 * <b>Descripción:</b> </br>
	 * <b>Fecha Creación:</b> 16 nov. 2024 </br>
	 * <b>Autor:</b> Luis Alberto Aldana </br>
	 * <b>Fecha de Última Modificación: </b></br>
	 * <b>Modificado por: </b></br>
	 * 
	 * @param phoneNumber
	 * @return
	 */
	public static String obfuscatePhoneNumber(String phoneNumber) {
		if (phoneNumber == null || phoneNumber.length() < 4) {
			return phoneNumber; // Retornar tal cual si no es válido
		}

		String lastFourDigits = phoneNumber.substring(phoneNumber.length() - 4);
		String obfuscatedPhoneNumber = "*".repeat(phoneNumber.length() - 4) + lastFourDigits;

		return obfuscatedPhoneNumber;
	}

	/**
	 * <b>Nombre: </b> obfuscateEmail </br>
	 * <b>Descripción:</b> </br>
	 * <b>Fecha Creación:</b> 16 nov. 2024 </br>
	 * <b>Autor:</b> Luis Alberto Aldana </br>
	 * <b>Fecha de Última Modificación: </b></br>
	 * <b>Modificado por: </b></br>
	 * 
	 * @param email
	 * @return
	 */
	public static String obfuscateEmail(String email) {
		if (email == null || !email.contains("@")) {
			return email; // Retornar tal cual si no tiene un formato válido
		}

		// Divide el correo en dos partes: antes y después del "@"
		String[] parts = email.split("@");
		String localPart = parts[0];
		String domain = parts[1];

		if (localPart.length() <= 4) {
			return "***@" + domain; // Si el localPart es menor o igual a 4, solo ocultamos con ***
		}

		String lastFourChars = localPart.substring(localPart.length() - 4);
		String obfuscatedEmail = "*".repeat(localPart.length() - 4) + lastFourChars + "@" + domain;

		return obfuscatedEmail;
	}

}
