package com.babylon.utils.common.api.util;

import com.babylon.utils.common.api.constants.BabylonCommonUtilsConstants;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;

import javax.naming.directory.InvalidAttributesException;

public class ResponseConverterUtil {

    private static final Log LOGGER = LogFactoryUtil.getLog(ResponseConverterUtil.class);
    
    public static JSONObject createJSONResponse(Integer code, boolean error, String message, String status, boolean show) {
        JSONObject joError = JSONFactoryUtil.createJSONObject();
        joError.put(BabylonCommonUtilsConstants.KEY_UTILS_CODE, code);
        joError.put(BabylonCommonUtilsConstants.KEY_UTILS_ERROR, error);
        joError.put(BabylonCommonUtilsConstants.KEY_UTILS_MESSAGE, message);
        joError.put(BabylonCommonUtilsConstants.KEY_UTILS_STATUS, status);
        joError.put(BabylonCommonUtilsConstants.KEY_UTILS_SHOW, show);
        return joError;
    }

    public static JSONObject createJSONError(String message, String status) {
        JSONObject error = JSONFactoryUtil.createJSONObject();
        error.put(BabylonCommonUtilsConstants.KEY_UTILS_ERROR, Boolean.TRUE);
        error.put(BabylonCommonUtilsConstants.KEY_UTILS_MESSAGE, message);
        error.put(BabylonCommonUtilsConstants.KEY_UTILS_STATUS, status);
        return error;
    }

    public static JSONObject createJSONError(Integer code, String message, String status) {
        JSONObject error = JSONFactoryUtil.createJSONObject();
        error.put(BabylonCommonUtilsConstants.KEY_UTILS_CODE, code);
        error.put(BabylonCommonUtilsConstants.KEY_UTILS_ERROR, Boolean.TRUE);
        error.put(BabylonCommonUtilsConstants.KEY_UTILS_MESSAGE, message);
        error.put(BabylonCommonUtilsConstants.KEY_UTILS_STATUS, status);
        return error;
    }
    public static JSONObject createJSONError(Integer code, String message, String status, boolean show) {
        JSONObject error = JSONFactoryUtil.createJSONObject();
        error.put(BabylonCommonUtilsConstants.KEY_UTILS_CODE, code);
        error.put(BabylonCommonUtilsConstants.KEY_UTILS_ERROR, Boolean.TRUE);
        error.put(BabylonCommonUtilsConstants.KEY_UTILS_MESSAGE, message);
        error.put(BabylonCommonUtilsConstants.KEY_UTILS_STATUS, status);
        error.put(BabylonCommonUtilsConstants.KEY_UTILS_SHOW, show);
        return error;
    }
    public static JSONObject updateJSON(JSONObject jsonResponse, Integer code, String message, String status, boolean show) {
        jsonResponse.put(BabylonCommonUtilsConstants.KEY_UTILS_CODE, code);
        jsonResponse.put(BabylonCommonUtilsConstants.KEY_UTILS_ERROR, Boolean.TRUE);
        jsonResponse.put(BabylonCommonUtilsConstants.KEY_UTILS_MESSAGE, message);
        jsonResponse.put(BabylonCommonUtilsConstants.KEY_UTILS_STATUS, status);
        jsonResponse.put(BabylonCommonUtilsConstants.KEY_UTILS_SHOW, show);
        return jsonResponse;
    }

    /**
     * Convert JSON string to DTO object
     * @param jsonObject
     * @param valueType
     * @return
     * @param <T>
     * @throws InvalidAttributesException
     */
    public static <T> T     toDTO(JSONObject jsonObject, Class<T> valueType) throws InvalidAttributesException {
        return toDTO(jsonObject.toString(), valueType);
    }

    public static <T> T     toDTO(String jsonString, Class<T> valueType) throws InvalidAttributesException {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        objectMapper.enable(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY);
        try {
            return objectMapper.readValue(jsonString, valueType);
        } catch (Exception e) {
            LOGGER.error(e);
            throw new InvalidAttributesException("Invalid JSON to convert to " + valueType.getSimpleName() + " [ " + jsonString +" ] " );
        }
    }

    /**
     * Convert DTO object to JSON string
     * @param object
     * @return
     * @param <T>
     * @throws InvalidAttributesException
     */
    public static <T> String toJSON(T object) throws InvalidAttributesException{
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        try {
            return objectMapper.writeValueAsString(object);
        } catch (Exception e) {
            throw new InvalidAttributesException("Invalid object to convert JSON [ " + object.getClass().getSimpleName() + "]");
        }
    }

}
