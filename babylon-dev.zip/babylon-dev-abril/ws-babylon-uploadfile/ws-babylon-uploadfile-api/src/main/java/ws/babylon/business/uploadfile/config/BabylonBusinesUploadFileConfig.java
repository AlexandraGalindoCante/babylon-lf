package ws.babylon.business.uploadfile.config;

import com.babylon.utils.common.api.constants.BabylonCommonUtilsConstants;
import com.liferay.portal.configuration.metatype.annotations.ExtendedObjectClassDefinition;

import aQute.bnd.annotation.metatype.Meta;
import ws.babylon.business.uploadfile.constants.BabylonBusinessUploadFileKeys;

@ExtendedObjectClassDefinition(category = BabylonCommonUtilsConstants.CATEGORY_CONFIG_SERVICES,
scope = ExtendedObjectClassDefinition.Scope.SYSTEM)
@Meta.OCD(id = 
		BabylonBusinessUploadFileKeys.BABYLON_UPLOAD_FILE_CONFIG, 
		localization = BabylonCommonUtilsConstants.KEY_UTILS_CONTENT_LANGUAGE, 
		name = BabylonBusinessUploadFileKeys.BABYLON_UPLOAD_FILE_CONFIG_NAME)

public interface BabylonBusinesUploadFileConfig {
	

	@Meta.AD(
	    deflt = BabylonBusinessUploadFileKeys.WS_ATTACHMENT_API_ENDPOINT,
	    name = "configuration.auth-token-endpoint", 
	    required = false,
	    description="URL del servicio que genera el token de autenticacion")
	public String getAuthTokenEndpoint();
	
	@Meta.AD(
	    deflt = BabylonBusinessUploadFileKeys.WS_ATTACHMENT_API_ENDPOINT,
	    name = "configuration.cmr-service-endpoint", 
	    required = false,
	    description="URL del servicio AttachmentAPI")
	public String getAttachmentServiceEndpoint();
	
	
	@Meta.AD(
	    deflt = BabylonBusinessUploadFileKeys.WS_ATTACHMENT_API_SERVICE_KEY,
	    name = "configuration.cmr-service-key", 
	    required = false,
	    description="Key del servicio AttachmentAPI")
	public String getAttachmentServiceKey();
	
   @Meta.AD(
        deflt = BabylonBusinessUploadFileKeys.WS_CREATE_SALT_ENDPOINT,
        name = "configuration.create-salt-service-endpoint", 
        required = false,
        description="Endpoint del servicio que crea el mensaje cifrado para proteger el archivo")
    public String getCreateSaltServiceEndpoint();
    
	    
   @Meta.AD(
       deflt = BabylonBusinessUploadFileKeys.WS_CREATE_SALT_ENDPOINT,
       name = "configuration.create-salt-service-key", 
       required = false,
       description="Key del servicio que crea el mensaje cifrado para proteger el archivo")
   public String getCreateSaltServiceKey();
   
   
   @Meta.AD(
       deflt = BabylonBusinessUploadFileKeys.WS_CREATE_SALT_ENDPOINT,
       name = "configuration.service-public-key", 
       required = false,
       description="Key publica para cifrar el mensaje")
   public String getServicePublicKey();
   
   
	@Meta.AD(
	    deflt = BabylonBusinessUploadFileKeys.WS_CHECK_HASH_ENDPOINT,
	    name = "configuration.check-hash-service-endpoint", 
	    required = false,
	    description="Endpoint del servicio que comprueba el hash generado")
	public String getCheckHashServiceEndpoint();
	
	

	@Meta.AD(
	    deflt = BabylonBusinessUploadFileKeys.WS_CHECK_HASH_SERVICE_KEY,
	    name = "configuration.check-hash-service-endpoint", 
	    required = false,
	    description="Key del servicio que comprueba el hash generado")
	public String getCheckHashServiceKey();
	
		
	@Meta.AD(
	    deflt = BabylonBusinessUploadFileKeys.WS_DOCUMENT_MANAGEMENT_ENDPOINT,
	    name = "configuration.get-document-athento-service-endpoint", 
	    required = false,
	    description="Endpoint del servicio que consulta el documento cargado en Athentho")
	public String getDocumentAthentoServiceEndpoint();
	
	@Meta.AD(
	    deflt = BabylonBusinessUploadFileKeys.WS_DOCUMENT_MANAGEMENT_SERVICE_KEY,
	    name = "configuration.get-document-athento-service-endpoint", 
	    required = false,
	    description="Key del servicio que consulta el documento cargado en Athentho")
	public String getDocumentAthentoServiceKey();
			
	@Meta.AD(
	    deflt = BabylonBusinessUploadFileKeys.WS_MANAGER_MASIV_ENDPOINT,
	    name = "configuration.masiv-notifications-service-endpoint", 
	    required = false,
	    description="Endpoint del servicio de Notificaciones Masiv")
	public String getMasivServiceEndpoint();
			
	@Meta.AD(
	    deflt = BabylonBusinessUploadFileKeys.WS_DOCUMENT_MANAGEMENT_SERVICE_KEY,
	    name = "configuration.masiv-notifications-service-endpoint", 
	    required = false,
	    description="Key del servicio de Notificaciones Masiv")
	public String getMasivServiceKey();
	
	
	

}
