package ws.babylon.business.uploadfile.constants;

public class BabylonBusinessUploadFileKeys {

    private BabylonBusinessUploadFileKeys() {
    }

    /***
     * CONFIGURATION
     */
    public  static final String BABYLON_UPLOAD_FILE_CONFIG = "ws.babylon.business.uploadfile.config.BabylonBusinesUploadFileConfig";
    public  static final String BABYLON_UPLOAD_FILE_CONFIG_NAME = "configuration.uploadfile-config-name";

    /* URLS APIS UPLOADFILE AXACOLPATRIA-BABYLON */
    public static final String WS_ATTACHMENT_API_ENDPOINT = "/AttachmentApi/v1/Files";
    public static final String WS_ATTACHMENT_API_SERVICE_KEY = "key";
    public static final String WS_CREATE_SALT_ENDPOINT= "/customerManagement/dataProtectionAPI/v1/Salt";
    public static final String WS_CREATE_SALT_SERVICE_KEY = "key";
    public static final String WS_CHECK_HASH_ENDPOINT= "/IdorUtil/dataProtectionAPI/v1/CheckHash";
    public static final String WS_CHECK_HASH_SERVICE_KEY = "key";
    public static final String WS_DOCUMENT_MANAGEMENT_ENDPOINT= "/documentManagement/documentsManagementApi/v1/documents/{{GuidAthento}}";
    public static final String WS_DOCUMENT_MANAGEMENT_SERVICE_KEY = "key";
    public static final String WS_MANAGER_MASIV_ENDPOINT= "/utilityManagement/notificationsAPI/v4/onlinemails";
    public static final String WS_MANAGER_MASIV_SERVICE_KEY = "key";
    
    /* PARAMETERS */
    public static final String PARAMETERS_STATUS = "status";
    public static final String ACCESS_TOKEN = "access_token";
    
    public static final String AUTH_EXCEPTION_NOTOKEN = "Empty Auth Token";
    public static final String AUTH_EXCEPTION_NOURL= "Empty Token Request URL";
    public static final String AUTH_EXCEPTION_UNAUTHORIZED= "Unauthorized Petition";
    public static final String JSON_ERROR = "error";
	
}
