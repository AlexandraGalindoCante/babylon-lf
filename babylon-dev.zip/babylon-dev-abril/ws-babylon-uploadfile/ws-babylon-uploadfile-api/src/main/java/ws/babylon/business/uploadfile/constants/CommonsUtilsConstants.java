package ws.babylon.business.uploadfile.constants;

import com.liferay.portal.kernel.util.PortletKeys;

public class CommonsUtilsConstants extends PortletKeys{
	// Expando Data
	public static final String USER_EXPANDO_DATA_KEY = "user-json-data";
	public static final String ST_USERIDTYPE = "TipoIdentificacion";
	public static final String ST_USER_IDTYPE = "TipoIdentificacionCode";
	public static final String ST_USER_IDNAME = "TipoIdentificacionName";
	public static final String ST_USER_IDNUMBER = "NumeroIdentificacion";
	public static final String ST_USER_EMAIL = "CorreoElectronico";
	public static final String ST_USER_PHONE = "Telefono";
	
	public static final String ST_SELECTED_APP = "AplicacionSeleccionada";
    public static final String ST_SELECTED_PROFILE = "PerfilSeleccionado";
	
	public static final String USER_SELECTED_KEY = "ClaveAsesorSeleccionada";
	public static final String LDC_CLAVE_ASESOR_SELECCIONADA = "LDC_ClaveAsesorSeleccionada";
	public static final String APPLICATIONS = "Aplicaciones";
	public static final String APPLICATION_PREFIX = "Prefijo";
	public static final String APPLICATION_PROFILES = "Perfiles";
	public static final String APPLICATION_PROFILE = "perfil";
	public static final String PROFILE_ENTERPRISES = "Empresas";
	public static final String PROFILE_DESCRIPTION = "Descripcion";
	public static final String KEY_ENTERPRISE_ID = "Id";

	public static final String PARSING_USER_DATA_ERROR = "Error parsing userData";

	// JSON RESPONSE DATA (REST LISTS)
	public static final String JSON_RESPONSE_HEADER = "responseHeader";
	public static final String JSON_QUOTE_HEADER = "quoteHeader";
	public static final String JSON_SERVICE_STATE = "serviceState";
	public static final String JSON_ERROR = "error";

	public static final String JSON_LISTS = "lists";
	public static final String JSON_LIST_SEARCH_KEY = "listSearchKey";
	public static final String JSON_LIST_NAME = "listName";
	public static final String JSON_LIST_RESULTS = "listResults";
	public static final String JSON_KEY = "key";
	public static final String JSON_NAME = "name";
	public static final String JSON_VALUE = "value";
	public static final String JSON_GROUPING = "grouping";
	public static final String JSON_RESULTS = "results";

	public static final String JSON_ERROR_DESC = "error_description";

	// JSON RESPONSE DATA (Gateway)
	public static final String GW_JSON_RESPONSE_HEADER = "MsgRsHdr";
	public static final String GW_JSON_RESPONSE_BODY = "body";
	public static final String GW_JSON_RESPONSE_STATUS = "Status";
	public static final String GW_JSON_RESPONSE_STATUS_CODE = "StatusCode";
	public static final String GW_JSON_RESPONSE_STATUS_DESCRIPTION = "StatusDesc";
	public static final String GW_JSON_RESPONSE_ADDITIONAL_STATUS = "AdditionalStatus";
	public static final String GW_JSON_RESPONSE_SERVER_STATUS_CODE = "ServerStatusCode";
	public static final String GW_JSON_RESPONSE_CATEGORY = "Category";
	
	// RestClientUtil Keys
	public static final String REST_CLIENT_UTIL_ERROR = "Error ";
	public static final String IO_EXCEPTION = "IOException";
	public static final String EXCEPTION_AT_PARSING_RESPONSE = "Exception at parsing response: ";
	public static final String URI_SYNTAX_EXCEPTION = "URISyntaxException: ";

	public static final String ACCESS_TOKEN = "access_token";
	public static final String AUTH_EXCEPTION_GENERIC = "Unexpected Exception";
	public static final String AUTH_EXCEPTION_NOTOKEN = "Empty Auth Token";
	public static final String AUTH_EXCEPTION_NOURL = "Empty Token Request URL";
	public static final String AUTH_EXCEPTION_UNAUTHORIZED = "Unauthorized Petition";
	
	public static final String ACCEPT = "Accept";
	public static final String ACCEPT_ALL = "*/*";
	public static final String CONTENT_TYPE = "Content-type";
	public static final String APPLICATION_JSON = "application/json";
	public static final String APPLICATION_FORM_URLENCODED = "application/x-www-form-urlencoded";
	public static final String AUTHORIZATION = "Authorization";

	// StringUtil Keys
	public static final String NUMBER_FORMAT_EXCEPTION = "NumberFormatException parsing ";
	public static final String PARSE_EXCEPTION = "Error formato de fecha ";
	public static final String DATE_FORMAT_DD_MM_YYYY_H_MM_A = "dd/MM/yyyy - h:mm a";
	public static final String DATE_FORMAT_YYYY_MM_DD_T_HH_MM_SS = "yyyy-MM-dd'T'hh:mm:ss";
	public static final String DATE_FORMAT_YYYY_MM_DD_T_HH_MM = "yyyy-MM-dd'T'hh:mm";
	public static final String DATE_FORMAT_DD_MM_YYYY = "dd/MM/yyyy";
	public static final String DATE_FORMAT_DD_MM_YYYY_HYPHEN = "dd-MM-yyyy";
	public static final String DATE_FORMAT_DD_MMM_YYYY = "dd/MMM/yyyy";
	public static final String DATE_FORMAT_MM_DD_YYYY = "MM/dd/yy";
	public static final String DATE_FORMAT_YYYYMMDD = "yyyyMMdd";
	public static final String DATE_FORMAT_YYYYMMDDHHMMSSSS = "yyMMddHHmmssSSS";
	public static final String DATE_FORMAT_YYYY_MM_DD = "yyyy-MM-dd";
	public static final String DATE_FORMAT_H_MM_A = "h:mm a";
	public static final String AM_UPPERCASE = "AM";
	public static final String AM_LOWERCASE = "a.m.";
	public static final String PM_UPPERCASE = "PM";
	public static final String PM_LOWERCASE = "p.m.";
	public static final String ES = "es";
	public static final String CO = "CO";
	public static final String DATE_FORMAT_YYYY_MM_DD_T_KK_MM_SS = "yyyy-MM-dd'T'KK:mm:ss"; 

	// DateUtil Keys
	public static final String DATE_FORMAT_HH_MM_DD_MM_YYYY = "HH:mm - dd/MM/yyyy";
	public static final String DATE_TRANSFORM_ERROR = "Error setting petition date - DateConfigurationError - ";

	// Content admin user role
	public static final String CONTENT_ADMIN_ROLE = "Content Admin Role";
	
	// GRECAPTCHA URL
	public static final String GRECAPTCHA_URL = "https://www.google.com/recaptcha/api/siteverify";
	public static final String KEY_SECRET = "secret";
	public static final String KEY_RESPONSE = "response";
	public static final String KEY_SUCCESS = "success";
	public static final String GRECAPTCHA_CACHE = "grecaptchaCache";
	public static final String VALIDATED_KEYS = "validated-keys";
	
	//ECM
	public static final String RES_DOC = "Documento";
	public static final String RES_DOC_URL = "url";
	public static final String PARAM_PROCESS_TYPE="processType";
	public static final String PARAM_DOCUMENT_TYPE="documentType";
	public static final String PARAM_WATERMARK="watermark";
	public static final String PARAM_PASSWORD="password";
	public static final String PARAM_ONE_USAGE_LINK = "onlyOneUse";
	public static final String PARAM_EXPIRATION_DATE = "expirationDate";
	public static final String RESULT = "result";

	//UserUtil: getDistributorAndCompanyData
	public static final String EMPRESA_SELECCIONADA = "EmpresaSeleccionada";
	public static final String COMPANY_NAME = "Nombre";
	
	public static final String COMPANY_ID_NUMBER_KEY = "NumeroIdentificacionEmpresa";
	public static final String COMPANY_ID_TYPE_KEY = "TipoIdentificacionEmpresa";
	public static final String COMPANY_NAME_KEY = "EmpresaNombre";
	
	public static final String ST_USER_NAME = "NombreUsuario";
	public static final String ST_USER_FIRST_NAME = "Nombres";
	public static final String ST_USER_LAST_NAME = "Apellidos";
	
	public static final String USER_LAST_NAME_KEY = "ApellidosUsuario";
	public static final String USER_NAMES_KEY = "NombresUsuario";
	public static final String ADVISER_CODE_KEY = "ClaveAsesor";
	public static final String ID_TYPE_KEY = "TipoIdentificacion";
	public static final String ASESOR_JSON_KEY = "Asesor";
	public static final String EMPRESA_JSON_KEY = "Empresa";
	
	//FILE UPLOAD
	public static final String FILE_UPLOAD_SALT = "Salt";
	public static final String FILE_UPLOAD_RESOURCE = "Resource";
	public static final String FILE_UPLOAD_MESSAGE = "Message";
	public static final String FILE_UPLOAD_ID = "id";
	public static final String FILE_UPLOAD_ID_UPPER = "Id";
	public static final String FILE_UPLOAD_HASH = "hash";
	public static final String FILE_UPLOAD_FILTER = "filter";
	public static final String FILE_UPLOAD_RESULTS = "results";
	public static final String FILE_UPLOAD_UUID = "uuid";
	public static final String FILE_UPLOAD_RESULT = "result";
	public static final String FILE_UPLOAD_RSA_METHOD = "RSA";
	public static final String FILE_UPLOAD_RSA_CIPHER = "RSA/ECB/PKCS1PADDING";
	public static final String FILE_UPLOAD_SHA_256_HASH = "SHA-256";
	public static final String FILE_UPLOAD_UTF8_ENCODING = "UTF-8";
	
	//WSO2-V2 	
	public static final String URL_SERVICE_LIST = "uri";
	public static final String TOKEN_SERVICE_LIST = "token";
	
}
