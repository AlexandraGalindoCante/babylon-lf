package ws.babylon.business.uploadfile.dto.v1_0;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;

import com.liferay.petra.function.UnsafeSupplier;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLField;
import com.liferay.portal.vulcan.graphql.annotation.GraphQLName;
import com.liferay.portal.vulcan.util.ObjectMapperUtil;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import javax.annotation.Generated;

import javax.validation.Valid;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Alexandra Galindo Cante
 * @generated
 */
@Generated("")
@GraphQLName("LoadFileResponse")
@JsonFilter("Liferay.Vulcan")
@XmlRootElement(name = "LoadFileResponse")
public class LoadFileResponse implements Serializable {

	public static LoadFileResponse toDTO(String json) {
		return ObjectMapperUtil.readValue(LoadFileResponse.class, json);
	}

	public static LoadFileResponse unsafeToDTO(String json) {
		return ObjectMapperUtil.unsafeReadValue(LoadFileResponse.class, json);
	}

	@Schema
	@Valid
	public MsgRsHdr getMsgRsHdr() {
		return MsgRsHdr;
	}

	public void setMsgRsHdr(MsgRsHdr MsgRsHdr) {
		this.MsgRsHdr = MsgRsHdr;
	}

	@JsonIgnore
	public void setMsgRsHdr(
		UnsafeSupplier<MsgRsHdr, Exception> MsgRsHdrUnsafeSupplier) {

		try {
			MsgRsHdr = MsgRsHdrUnsafeSupplier.get();
		}
		catch (RuntimeException re) {
			throw re;
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected MsgRsHdr MsgRsHdr;

	@Schema
	@Valid
	public Body getBody() {
		return body;
	}

	public void setBody(Body body) {
		this.body = body;
	}

	@JsonIgnore
	public void setBody(UnsafeSupplier<Body, Exception> bodyUnsafeSupplier) {
		try {
			body = bodyUnsafeSupplier.get();
		}
		catch (RuntimeException re) {
			throw re;
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Body body;

	@Schema
	public Integer getCodeResp() {
		return codeResp;
	}

	public void setCodeResp(Integer codeResp) {
		this.codeResp = codeResp;
	}

	@JsonIgnore
	public void setCodeResp(
		UnsafeSupplier<Integer, Exception> codeRespUnsafeSupplier) {

		try {
			codeResp = codeRespUnsafeSupplier.get();
		}
		catch (RuntimeException re) {
			throw re;
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Integer codeResp;

	@Schema
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@JsonIgnore
	public void setMessage(
		UnsafeSupplier<String, Exception> messageUnsafeSupplier) {

		try {
			message = messageUnsafeSupplier.get();
		}
		catch (RuntimeException re) {
			throw re;
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected String message;

	@Schema
	public Boolean getShow() {
		return show;
	}

	public void setShow(Boolean show) {
		this.show = show;
	}

	@JsonIgnore
	public void setShow(UnsafeSupplier<Boolean, Exception> showUnsafeSupplier) {
		try {
			show = showUnsafeSupplier.get();
		}
		catch (RuntimeException re) {
			throw re;
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected Boolean show;

	@Schema
	@Valid
	public StatusResp getStatusResp() {
		return statusResp;
	}

	@JsonIgnore
	public String getStatusRespAsString() {
		if (statusResp == null) {
			return null;
		}

		return statusResp.toString();
	}

	public void setStatusResp(StatusResp statusResp) {
		this.statusResp = statusResp;
	}

	@JsonIgnore
	public void setStatusResp(
		UnsafeSupplier<StatusResp, Exception> statusRespUnsafeSupplier) {

		try {
			statusResp = statusRespUnsafeSupplier.get();
		}
		catch (RuntimeException re) {
			throw re;
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@GraphQLField
	@JsonProperty(access = JsonProperty.Access.READ_WRITE)
	protected StatusResp statusResp;

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof LoadFileResponse)) {
			return false;
		}

		LoadFileResponse loadFileResponse = (LoadFileResponse)object;

		return Objects.equals(toString(), loadFileResponse.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		StringBundler sb = new StringBundler();

		sb.append("{");

		if (MsgRsHdr != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"MsgRsHdr\": ");

			sb.append(String.valueOf(MsgRsHdr));
		}

		if (body != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"body\": ");

			sb.append(String.valueOf(body));
		}

		if (codeResp != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"codeResp\": ");

			sb.append(codeResp);
		}

		if (message != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"message\": ");

			sb.append("\"");

			sb.append(_escape(message));

			sb.append("\"");
		}

		if (show != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"show\": ");

			sb.append(show);
		}

		if (statusResp != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"statusResp\": ");

			sb.append("\"");

			sb.append(statusResp);

			sb.append("\"");
		}

		sb.append("}");

		return sb.toString();
	}

	@Schema(
		accessMode = Schema.AccessMode.READ_ONLY,
		defaultValue = "ws.babylon.business.uploadfile.dto.v1_0.LoadFileResponse",
		name = "x-class-name"
	)
	public String xClassName;

	@GraphQLName("StatusResp")
	public static enum StatusResp {

		CONTINUE("CONTINUE"), SWITCHING_PROTOCOLS("SWITCHING_PROTOCOLS"),
		PROCESSING("PROCESSING"), CHECKPOINT("CHECKPOINT"), OK("OK"),
		CREATED("CREATED"), ACCEPTED("ACCEPTED"),
		NON_AUTHORITATIVE_INFORMATION("NON_AUTHORITATIVE_INFORMATION"),
		NO_CONTENT("NO_CONTENT"), RESET_CONTENT("RESET_CONTENT"),
		PARTIAL_CONTENT("PARTIAL_CONTENT"), MULTI_STATUS("MULTI_STATUS"),
		ALREADY_REPORTED("ALREADY_REPORTED"), IM_USED("IM_USED"),
		MULTIPLE_CHOICES("MULTIPLE_CHOICES"),
		MOVED_PERMANENTLY("MOVED_PERMANENTLY"), FOUND("FOUND"),
		MOVED_TEMPORARILY("MOVED_TEMPORARILY"), SEE_OTHER("SEE_OTHER"),
		NOT_MODIFIED("NOT_MODIFIED"), USE_PROXY("USE_PROXY"),
		TEMPORARY_REDIRECT("TEMPORARY_REDIRECT"),
		PERMANENT_REDIRECT("PERMANENT_REDIRECT"), BAD_REQUEST("BAD_REQUEST"),
		UNAUTHORIZED("UNAUTHORIZED"), PAYMENT_REQUIRED("PAYMENT_REQUIRED"),
		FORBIDDEN("FORBIDDEN"), NOT_FOUND("NOT_FOUND"),
		METHOD_NOT_ALLOWED("METHOD_NOT_ALLOWED"),
		NOT_ACCEPTABLE("NOT_ACCEPTABLE"),
		PROXY_AUTHENTICATION_REQUIRED("PROXY_AUTHENTICATION_REQUIRED"),
		REQUEST_TIMEOUT("REQUEST_TIMEOUT"), CONFLICT("CONFLICT"), GONE("GONE"),
		LENGTH_REQUIRED("LENGTH_REQUIRED"),
		PRECONDITION_FAILED("PRECONDITION_FAILED"),
		PAYLOAD_TOO_LARGE("PAYLOAD_TOO_LARGE"),
		REQUEST_ENTITY_TOO_LARGE("REQUEST_ENTITY_TOO_LARGE"),
		URI_TOO_LONG("URI_TOO_LONG"),
		REQUEST_URI_TOO_LONG("REQUEST_URI_TOO_LONG"),
		UNSUPPORTED_MEDIA_TYPE("UNSUPPORTED_MEDIA_TYPE"),
		REQUESTED_RANGE_NOT_SATISFIABLE("REQUESTED_RANGE_NOT_SATISFIABLE"),
		EXPECTATION_FAILED("EXPECTATION_FAILED"),
		I_AM_A_TEAPOT("I_AM_A_TEAPOT"),
		INSUFFICIENT_SPACE_ON_RESOURCE("INSUFFICIENT_SPACE_ON_RESOURCE"),
		METHOD_FAILURE("METHOD_FAILURE"),
		DESTINATION_LOCKED("DESTINATION_LOCKED"),
		UNPROCESSABLE_ENTITY("UNPROCESSABLE_ENTITY"), LOCKED("LOCKED"),
		FAILED_DEPENDENCY("FAILED_DEPENDENCY"), TOO_EARLY("TOO_EARLY"),
		UPGRADE_REQUIRED("UPGRADE_REQUIRED"),
		PRECONDITION_REQUIRED("PRECONDITION_REQUIRED"),
		TOO_MANY_REQUESTS("TOO_MANY_REQUESTS"),
		REQUEST_HEADER_FIELDS_TOO_LARGE("REQUEST_HEADER_FIELDS_TOO_LARGE"),
		UNAVAILABLE_FOR_LEGAL_REASONS("UNAVAILABLE_FOR_LEGAL_REASONS"),
		INTERNAL_SERVER_ERROR("INTERNAL_SERVER_ERROR"),
		NOT_IMPLEMENTED("NOT_IMPLEMENTED"), BAD_GATEWAY("BAD_GATEWAY"),
		SERVICE_UNAVAILABLE("SERVICE_UNAVAILABLE"),
		GATEWAY_TIMEOUT("GATEWAY_TIMEOUT"),
		HTTP_VERSION_NOT_SUPPORTED("HTTP_VERSION_NOT_SUPPORTED"),
		VARIANT_ALSO_NEGOTIATES("VARIANT_ALSO_NEGOTIATES"),
		INSUFFICIENT_STORAGE("INSUFFICIENT_STORAGE"),
		LOOP_DETECTED("LOOP_DETECTED"),
		BANDWIDTH_LIMIT_EXCEEDED("BANDWIDTH_LIMIT_EXCEEDED"),
		NOT_EXTENDED("NOT_EXTENDED"),
		NETWORK_AUTHENTICATION_REQUIRED("NETWORK_AUTHENTICATION_REQUIRED");

		@JsonCreator
		public static StatusResp create(String value) {
			if ((value == null) || value.equals("")) {
				return null;
			}

			for (StatusResp statusResp : values()) {
				if (Objects.equals(statusResp.getValue(), value)) {
					return statusResp;
				}
			}

			throw new IllegalArgumentException("Invalid enum value: " + value);
		}

		@JsonValue
		public String getValue() {
			return _value;
		}

		@Override
		public String toString() {
			return _value;
		}

		private StatusResp(String value) {
			_value = value;
		}

		private final String _value;

	}

	private static String _escape(Object object) {
		return StringUtil.replace(
			String.valueOf(object), _JSON_ESCAPE_STRINGS[0],
			_JSON_ESCAPE_STRINGS[1]);
	}

	private static boolean _isArray(Object value) {
		if (value == null) {
			return false;
		}

		Class<?> clazz = value.getClass();

		return clazz.isArray();
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(_escape(entry.getKey()));
			sb.append("\": ");

			Object value = entry.getValue();

			if (_isArray(value)) {
				sb.append("[");

				Object[] valueArray = (Object[])value;

				for (int i = 0; i < valueArray.length; i++) {
					if (valueArray[i] instanceof String) {
						sb.append("\"");
						sb.append(valueArray[i]);
						sb.append("\"");
					}
					else {
						sb.append(valueArray[i]);
					}

					if ((i + 1) < valueArray.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof Map) {
				sb.append(_toJSON((Map<String, ?>)value));
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(value));
				sb.append("\"");
			}
			else {
				sb.append(value);
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

	private static final String[][] _JSON_ESCAPE_STRINGS = {
		{"\\", "\"", "\b", "\f", "\n", "\r", "\t"},
		{"\\\\", "\\\"", "\\b", "\\f", "\\n", "\\r", "\\t"}
	};

}