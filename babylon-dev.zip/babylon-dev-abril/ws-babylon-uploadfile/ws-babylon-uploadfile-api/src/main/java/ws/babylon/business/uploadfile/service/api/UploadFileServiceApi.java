package ws.babylon.business.uploadfile.service.api;


import ws.babylon.business.uploadfile.dto.v1_0.ReqUploadDoc;
import ws.babylon.business.uploadfile.service.dto.LoadFileResponseWSDTO;

public interface UploadFileServiceApi {

    LoadFileResponseWSDTO callPostUploadFile(ReqUploadDoc requestUploadDoc) throws Exception;

}
