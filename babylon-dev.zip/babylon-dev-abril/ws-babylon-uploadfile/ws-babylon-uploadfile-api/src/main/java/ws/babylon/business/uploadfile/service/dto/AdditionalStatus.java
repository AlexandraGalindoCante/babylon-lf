package ws.babylon.business.uploadfile.service.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AdditionalStatus {
	@JsonProperty("ServerStatusCode")
	private String serverStatusCode;
	@JsonProperty("Severity")
	private String severity;
	@JsonProperty("StatusDesc")
	private String statusDesc;

	public String getServerStatusCode() {
		return serverStatusCode;
	}

	public void setServerStatusCode(String serverStatusCode) {
		this.serverStatusCode = serverStatusCode;
	}

	public String getSeverity() {
		return severity;
	}

	public void setSeverity(String severity) {
		this.severity = severity;
	}

	public String getStatusDesc() {
		return statusDesc;
	}

	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}
}
