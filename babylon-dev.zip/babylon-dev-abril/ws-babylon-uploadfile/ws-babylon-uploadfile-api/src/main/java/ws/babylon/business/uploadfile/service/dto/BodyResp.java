package ws.babylon.business.uploadfile.service.dto;

public class BodyResp {
    
    

}
