package ws.babylon.business.uploadfile.service.dto;

public class CanonicoAthento {
    private Params params;

    // Getters and Setters
    public Params getParams() {
        return params;
    }

    public void setParams(Params params) {
        this.params = params;
    }

    // Clase interna Params
    public static class Params {
        private ParamProperties paramProperties;

        // Getters and Setters
        public ParamProperties getParamProperties() {
            return paramProperties;
        }

        public void setParamProperties(ParamProperties paramProperties) {
            this.paramProperties = paramProperties;
        }
    }

   
}
