package ws.babylon.business.uploadfile.service.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Error {
	@JsonProperty("Status")
	 private Status status;

     public Status getStatus() {
         return status;
     }

     public void setStatus(Status status) {
         this.status = status;
     }

	@Override
	public String toString() {
		return "Error [status=" + status + "]";
	}
     
     
}
