package ws.babylon.business.uploadfile.service.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import ws.babylon.business.uploadfile.dto.v1_0.MsgRsHdr;

public class LoadFileResponseWSDTO {
    

    @JsonProperty("MsgRsHdr")
    private MsgRsHdr msgRsHdr;
    @JsonProperty("body")
    private BodyResp body;

    public MsgRsHdr getMsgRsHdr() {
        return msgRsHdr;
    }

    public void setMsgRsHdr(MsgRsHdr msgRsHdr) {
        this.msgRsHdr = msgRsHdr;
    }

  
    public BodyResp getBody() {
        return body;
    }

    public void setBody(BodyResp body) {
        this.body = body;
    }

    @Override
    public String toString() {
        return "CheckIdentityWSResponse [msgRsHdr=" + msgRsHdr + "body=" + body + "]";
    }


}
