package ws.babylon.business.uploadfile.service.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class MsgRsHdr {
	@JsonProperty("error")  
	private Error error;

      public Error getError() {
          return error;
      }

      public void setError(Error error) {
          this.error = error;
      }

	@Override
	public String toString() {
		return "MsgRsHdr [error=" + error + "]";
	}
            
  }

