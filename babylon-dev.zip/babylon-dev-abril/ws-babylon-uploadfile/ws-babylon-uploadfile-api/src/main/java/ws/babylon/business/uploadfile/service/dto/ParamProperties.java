package ws.babylon.business.uploadfile.service.dto;

public class ParamProperties {

        private String canonico_nombre_documento;
        private String canonico_nro_identificacion_cliente;
        private String canonico_tipo_identificacion_cliente;
        private String canonico_ramo;
        private String canonico_producto;
        private String canonico_nombre_aliado;
        private String canonico_requiere_firma;
        private String canonico_clave_aliado;
        private String canonico_fecha_almacenamiento_documento;

        // Getters and Setters
        public String getCanonico_nombre_documento() {
            return canonico_nombre_documento;
        }

        public void setCanonico_nombre_documento(String canonico_nombre_documento) {
            this.canonico_nombre_documento = canonico_nombre_documento;
        }

        public String getCanonico_nro_identificacion_cliente() {
            return canonico_nro_identificacion_cliente;
        }

        public void setCanonico_nro_identificacion_cliente(String canonico_nro_identificacion_cliente) {
            this.canonico_nro_identificacion_cliente = canonico_nro_identificacion_cliente;
        }

        public String getCanonico_ramo() {
            return canonico_ramo;
        }

        public void setCanonico_ramo(String canonico_ramo) {
            this.canonico_ramo = canonico_ramo;
        }

        public String getCanonico_producto() {
            return canonico_producto;
        }

        public void setCanonico_producto(String canonico_producto) {
            this.canonico_producto = canonico_producto;
        }

        public String getCanonico_nombre_aliado() {
            return canonico_nombre_aliado;
        }

        public void setCanonico_nombre_aliado(String canonico_nombre_aliado) {
            this.canonico_nombre_aliado = canonico_nombre_aliado;
        }

        public String getCanonico_requiere_firma() {
            return canonico_requiere_firma;
        }

        public void setCanonico_requiere_firma(String canonico_requiere_firma) {
            this.canonico_requiere_firma = canonico_requiere_firma;
        }

        public String getCanonico_clave_aliado() {
            return canonico_clave_aliado;
        }

        public void setCanonico_clave_aliado(String canonico_clave_aliado) {
            this.canonico_clave_aliado = canonico_clave_aliado;
        }

        public String getCanonico_tipo_identificacion_cliente() {
            return canonico_tipo_identificacion_cliente;
        }

        public void setCanonico_tipo_identificacion_cliente(String canonico_tipo_identificacion_cliente) {
            this.canonico_tipo_identificacion_cliente = canonico_tipo_identificacion_cliente;
        }

        public String getCanonico_fecha_almacenamiento_documento() {
            return canonico_fecha_almacenamiento_documento;
        }

        public void setCanonico_fecha_almacenamiento_documento(
            String canonico_fecha_almacenamiento_documento) {
            this.canonico_fecha_almacenamiento_documento = canonico_fecha_almacenamiento_documento;
        }
        
        
        
    }

