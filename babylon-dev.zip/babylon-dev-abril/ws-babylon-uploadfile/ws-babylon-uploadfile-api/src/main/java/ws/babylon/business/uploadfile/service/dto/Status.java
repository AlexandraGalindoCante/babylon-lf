package ws.babylon.business.uploadfile.service.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Status {

	@JsonProperty("StatusCode")
	private String statusCode;
	@JsonProperty("Severity")
	private String severity;
	@JsonProperty("StatusDesc")
	private String statusDesc;
	@JsonProperty("AdditionalStatus")
	private AdditionalStatus additionalStatus;

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getSeverity() {
		return severity;
	}

	public void setSeverity(String severity) {
		this.severity = severity;
	}

	public String getStatusDesc() {
		return statusDesc;
	}

	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	public AdditionalStatus getAdditionalStatus() {
		return additionalStatus;
	}

	public void setAdditionalStatus(AdditionalStatus additionalStatus) {
		this.additionalStatus = additionalStatus;
	}

	@Override
	public String toString() {
		return "Status [statusCode=" + statusCode + ", severity=" + severity + ", statusDesc=" + statusDesc
				+ ", additionalStatus=" + additionalStatus + "]";
	}

}
