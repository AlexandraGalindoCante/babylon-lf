package ws.babylon.business.uploadfile.util;

import com.liferay.portal.kernel.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/**
 * RestRequestDTO.java
 *
 * This class is deprecated, use com.axa.portal.col.web.service.consumer.dto.RestRequestDTO instead
 *
 * @author dfgaleanod
 *
 */
public class RestRequestDTO {
	
	private String requestUrl;
	private String credsUser;
	private String credsPass;
	private String requestBody;
	private Map<String, String> headers;
	private Map<String, String> parameters;

	// Tokenized Request
	private String authToken;
	private Map<String, String> tokenRequestParams;
	
	public static class RequestBuilder {
		private static final String USERNAME_STR = "username";
		private static final String PASSW_STR = "password";
		private static final String GRANT_TYPE = "grant_type";
		private static final String CLIENT_CREDENTIALS = "client_credentials";
		
		private String requestUrl;
		private String credsUser;
		private String credsPass;
		private String requestBody;
		private Map<String, String> headers;
		private Map<String, String> parameters;

		// Tokenized Request
		private String authToken;
		private Map<String, String> tokenRequestParams;
		
		public RequestBuilder() {
			//Constructor
		}
		
		public RequestBuilder requestURL(String requestUrl) {
			this.requestUrl = requestUrl;
			
			return this;
		}
		
		public RequestBuilder credentials(String credsUser, String credsPass) {
			this.credsUser = credsUser;
			this.credsPass = credsPass;
			
			return this;
		}
		
		public RequestBuilder requestBody(String requestBody) {
			this.requestBody = requestBody;
			
			return this;
		}
		
		public RequestBuilder requestBody(JSONObject requestBody) {
			if(requestBody != null) {
				this.requestBody = requestBody.toString();
			}
			
			return this;
		}
		
		public RequestBuilder requestHeaders(Map<String, String> headers) {
			this.headers = headers;
			
			return this;
		}
		
		public RequestBuilder requestParameters(Map<String, String> parameters) {
			this.parameters = parameters;
			
			return this;
		}
		
		/**
		 * grant_type: client_credentials
		 */
		public RequestBuilder tokenizedRequestWithCredentials(String authToken) {
			this.authToken = authToken;
			
			this.tokenRequestParams = new HashMap<>();
			tokenRequestParams.put(GRANT_TYPE, CLIENT_CREDENTIALS);
			
			return this;
		}
		
		/**
		 *  grant_type: password
		 */
		public RequestBuilder tokenizedRequestWithPassword(String authToken, String username, String password) {
			this.authToken = authToken;
			
			this.tokenRequestParams = new HashMap<>();
			tokenRequestParams.put(GRANT_TYPE, PASSW_STR);
			tokenRequestParams.put(USERNAME_STR, username);
			tokenRequestParams.put(PASSW_STR, password);
			
			return this;
		}
		
		public RestRequestDTO build() {
			return new RestRequestDTO(this);
		}
	}
	
	private RestRequestDTO(RequestBuilder builder) {
		this.requestUrl = builder.requestUrl;
		this.credsUser = builder.credsUser;
		this.credsPass = builder.credsPass;
		this.requestBody = builder.requestBody;
		this.headers = builder.headers;
		this.parameters = builder.parameters;
		this.authToken = builder.authToken;
		this.tokenRequestParams = builder.tokenRequestParams;
	}

	public String getRequestUrl() {
		return requestUrl;
	}

	public String getCredsUser() {
		return credsUser;
	}

	public String getCredsPass() {
		return credsPass;
	}

	public String getRequestBody() {
		return requestBody;
	}

	public Map<String, String> getHeaders() {
		return headers;
	}

	public Map<String, String> getParameters() {
		return parameters;
	}

	public String getAuthToken() {
		return authToken;
	}	

	public Map<String, String> getTokenRequestParams() {
		return tokenRequestParams;
	}
	
	public String setAuthToken(String authToken) {
		return this.authToken = authToken;
	}
	
	
}
