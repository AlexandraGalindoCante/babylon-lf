package ws.babylon.business.uploadfile.client.dto.v1_0;

import java.io.Serializable;

import java.util.Objects;

import javax.annotation.Generated;

import ws.babylon.business.uploadfile.client.function.UnsafeSupplier;
import ws.babylon.business.uploadfile.client.serdes.v1_0.AditionalStatusSerDes;

/**
 * @author Alexandra Galindo Cante
 * @generated
 */
@Generated("")
public class AditionalStatus implements Cloneable, Serializable {

	public static AditionalStatus toDTO(String json) {
		return AditionalStatusSerDes.toDTO(json);
	}

	public String getCategory() {
		return Category;
	}

	public void setCategory(String Category) {
		this.Category = Category;
	}

	public void setCategory(
		UnsafeSupplier<String, Exception> CategoryUnsafeSupplier) {

		try {
			Category = CategoryUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected String Category;

	public Integer getServerStatusCode() {
		return ServerStatusCode;
	}

	public void setServerStatusCode(Integer ServerStatusCode) {
		this.ServerStatusCode = ServerStatusCode;
	}

	public void setServerStatusCode(
		UnsafeSupplier<Integer, Exception> ServerStatusCodeUnsafeSupplier) {

		try {
			ServerStatusCode = ServerStatusCodeUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected Integer ServerStatusCode;

	public String getStatusDesc() {
		return StatusDesc;
	}

	public void setStatusDesc(String StatusDesc) {
		this.StatusDesc = StatusDesc;
	}

	public void setStatusDesc(
		UnsafeSupplier<String, Exception> StatusDescUnsafeSupplier) {

		try {
			StatusDesc = StatusDescUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected String StatusDesc;

	@Override
	public AditionalStatus clone() throws CloneNotSupportedException {
		return (AditionalStatus)super.clone();
	}

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof AditionalStatus)) {
			return false;
		}

		AditionalStatus aditionalStatus = (AditionalStatus)object;

		return Objects.equals(toString(), aditionalStatus.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		return AditionalStatusSerDes.toJSON(this);
	}

}