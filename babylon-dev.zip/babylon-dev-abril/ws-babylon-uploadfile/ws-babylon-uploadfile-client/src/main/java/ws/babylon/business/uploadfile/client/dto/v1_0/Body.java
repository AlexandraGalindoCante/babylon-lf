package ws.babylon.business.uploadfile.client.dto.v1_0;

import java.io.Serializable;

import java.util.Objects;

import javax.annotation.Generated;

import ws.babylon.business.uploadfile.client.dto.v1_0.Result;
import ws.babylon.business.uploadfile.client.function.UnsafeSupplier;
import ws.babylon.business.uploadfile.client.serdes.v1_0.BodySerDes;

/**
 * @author Alexandra Galindo Cante
 * @generated
 */
@Generated("")
public class Body implements Cloneable, Serializable {

	public static Body toDTO(String json) {
		return BodySerDes.toDTO(json);
	}

	public Result[] getResults() {
		return results;
	}

	public void setResults(Result[] results) {
		this.results = results;
	}

	public void setResults(
		UnsafeSupplier<Result[], Exception> resultsUnsafeSupplier) {

		try {
			results = resultsUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected Result[] results;

	@Override
	public Body clone() throws CloneNotSupportedException {
		return (Body)super.clone();
	}

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof Body)) {
			return false;
		}

		Body body = (Body)object;

		return Objects.equals(toString(), body.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		return BodySerDes.toJSON(this);
	}

}