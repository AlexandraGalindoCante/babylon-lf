package ws.babylon.business.uploadfile.client.dto.v1_0;

import java.io.Serializable;

import java.util.Objects;

import javax.annotation.Generated;

import ws.babylon.business.uploadfile.client.dto.v1_0.AditionalStatus;
import ws.babylon.business.uploadfile.client.function.UnsafeSupplier;
import ws.babylon.business.uploadfile.client.serdes.v1_0.ErrorSerDes;

/**
 * @author Alexandra Galindo Cante
 * @generated
 */
@Generated("")
public class Error implements Cloneable, Serializable {

	public static Error toDTO(String json) {
		return ErrorSerDes.toDTO(json);
	}

	public AditionalStatus getAditionalStatus() {
		return AditionalStatus;
	}

	public void setAditionalStatus(AditionalStatus AditionalStatus) {
		this.AditionalStatus = AditionalStatus;
	}

	public void setAditionalStatus(
		UnsafeSupplier<AditionalStatus, Exception>
			AditionalStatusUnsafeSupplier) {

		try {
			AditionalStatus = AditionalStatusUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected AditionalStatus AditionalStatus;

	public String getSeverity() {
		return Severity;
	}

	public void setSeverity(String Severity) {
		this.Severity = Severity;
	}

	public void setSeverity(
		UnsafeSupplier<String, Exception> SeverityUnsafeSupplier) {

		try {
			Severity = SeverityUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected String Severity;

	public Integer getStatusCode() {
		return StatusCode;
	}

	public void setStatusCode(Integer StatusCode) {
		this.StatusCode = StatusCode;
	}

	public void setStatusCode(
		UnsafeSupplier<Integer, Exception> StatusCodeUnsafeSupplier) {

		try {
			StatusCode = StatusCodeUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected Integer StatusCode;

	public String getStatusDesc() {
		return StatusDesc;
	}

	public void setStatusDesc(String StatusDesc) {
		this.StatusDesc = StatusDesc;
	}

	public void setStatusDesc(
		UnsafeSupplier<String, Exception> StatusDescUnsafeSupplier) {

		try {
			StatusDesc = StatusDescUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected String StatusDesc;

	@Override
	public Error clone() throws CloneNotSupportedException {
		return (Error)super.clone();
	}

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof Error)) {
			return false;
		}

		Error error = (Error)object;

		return Objects.equals(toString(), error.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		return ErrorSerDes.toJSON(this);
	}

}