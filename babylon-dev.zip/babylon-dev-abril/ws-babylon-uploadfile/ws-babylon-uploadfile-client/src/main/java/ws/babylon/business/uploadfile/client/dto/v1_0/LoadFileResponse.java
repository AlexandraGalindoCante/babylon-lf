package ws.babylon.business.uploadfile.client.dto.v1_0;

import java.io.Serializable;

import java.util.Objects;

import javax.annotation.Generated;

import ws.babylon.business.uploadfile.client.dto.v1_0.Body;
import ws.babylon.business.uploadfile.client.dto.v1_0.MsgRsHdr;
import ws.babylon.business.uploadfile.client.function.UnsafeSupplier;
import ws.babylon.business.uploadfile.client.serdes.v1_0.LoadFileResponseSerDes;

/**
 * @author Alexandra Galindo Cante
 * @generated
 */
@Generated("")
public class LoadFileResponse implements Cloneable, Serializable {

	public static LoadFileResponse toDTO(String json) {
		return LoadFileResponseSerDes.toDTO(json);
	}

	public MsgRsHdr getMsgRsHdr() {
		return MsgRsHdr;
	}

	public void setMsgRsHdr(MsgRsHdr MsgRsHdr) {
		this.MsgRsHdr = MsgRsHdr;
	}

	public void setMsgRsHdr(
		UnsafeSupplier<MsgRsHdr, Exception> MsgRsHdrUnsafeSupplier) {

		try {
			MsgRsHdr = MsgRsHdrUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected MsgRsHdr MsgRsHdr;

	public Body getBody() {
		return body;
	}

	public void setBody(Body body) {
		this.body = body;
	}

	public void setBody(UnsafeSupplier<Body, Exception> bodyUnsafeSupplier) {
		try {
			body = bodyUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected Body body;

	public Integer getCodeResp() {
		return codeResp;
	}

	public void setCodeResp(Integer codeResp) {
		this.codeResp = codeResp;
	}

	public void setCodeResp(
		UnsafeSupplier<Integer, Exception> codeRespUnsafeSupplier) {

		try {
			codeResp = codeRespUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected Integer codeResp;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public void setMessage(
		UnsafeSupplier<String, Exception> messageUnsafeSupplier) {

		try {
			message = messageUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected String message;

	public Boolean getShow() {
		return show;
	}

	public void setShow(Boolean show) {
		this.show = show;
	}

	public void setShow(UnsafeSupplier<Boolean, Exception> showUnsafeSupplier) {
		try {
			show = showUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected Boolean show;

	public StatusResp getStatusResp() {
		return statusResp;
	}

	public String getStatusRespAsString() {
		if (statusResp == null) {
			return null;
		}

		return statusResp.toString();
	}

	public void setStatusResp(StatusResp statusResp) {
		this.statusResp = statusResp;
	}

	public void setStatusResp(
		UnsafeSupplier<StatusResp, Exception> statusRespUnsafeSupplier) {

		try {
			statusResp = statusRespUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected StatusResp statusResp;

	@Override
	public LoadFileResponse clone() throws CloneNotSupportedException {
		return (LoadFileResponse)super.clone();
	}

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof LoadFileResponse)) {
			return false;
		}

		LoadFileResponse loadFileResponse = (LoadFileResponse)object;

		return Objects.equals(toString(), loadFileResponse.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		return LoadFileResponseSerDes.toJSON(this);
	}

	public static enum StatusResp {

		CONTINUE("CONTINUE"), SWITCHING_PROTOCOLS("SWITCHING_PROTOCOLS"),
		PROCESSING("PROCESSING"), CHECKPOINT("CHECKPOINT"), OK("OK"),
		CREATED("CREATED"), ACCEPTED("ACCEPTED"),
		NON_AUTHORITATIVE_INFORMATION("NON_AUTHORITATIVE_INFORMATION"),
		NO_CONTENT("NO_CONTENT"), RESET_CONTENT("RESET_CONTENT"),
		PARTIAL_CONTENT("PARTIAL_CONTENT"), MULTI_STATUS("MULTI_STATUS"),
		ALREADY_REPORTED("ALREADY_REPORTED"), IM_USED("IM_USED"),
		MULTIPLE_CHOICES("MULTIPLE_CHOICES"),
		MOVED_PERMANENTLY("MOVED_PERMANENTLY"), FOUND("FOUND"),
		MOVED_TEMPORARILY("MOVED_TEMPORARILY"), SEE_OTHER("SEE_OTHER"),
		NOT_MODIFIED("NOT_MODIFIED"), USE_PROXY("USE_PROXY"),
		TEMPORARY_REDIRECT("TEMPORARY_REDIRECT"),
		PERMANENT_REDIRECT("PERMANENT_REDIRECT"), BAD_REQUEST("BAD_REQUEST"),
		UNAUTHORIZED("UNAUTHORIZED"), PAYMENT_REQUIRED("PAYMENT_REQUIRED"),
		FORBIDDEN("FORBIDDEN"), NOT_FOUND("NOT_FOUND"),
		METHOD_NOT_ALLOWED("METHOD_NOT_ALLOWED"),
		NOT_ACCEPTABLE("NOT_ACCEPTABLE"),
		PROXY_AUTHENTICATION_REQUIRED("PROXY_AUTHENTICATION_REQUIRED"),
		REQUEST_TIMEOUT("REQUEST_TIMEOUT"), CONFLICT("CONFLICT"), GONE("GONE"),
		LENGTH_REQUIRED("LENGTH_REQUIRED"),
		PRECONDITION_FAILED("PRECONDITION_FAILED"),
		PAYLOAD_TOO_LARGE("PAYLOAD_TOO_LARGE"),
		REQUEST_ENTITY_TOO_LARGE("REQUEST_ENTITY_TOO_LARGE"),
		URI_TOO_LONG("URI_TOO_LONG"),
		REQUEST_URI_TOO_LONG("REQUEST_URI_TOO_LONG"),
		UNSUPPORTED_MEDIA_TYPE("UNSUPPORTED_MEDIA_TYPE"),
		REQUESTED_RANGE_NOT_SATISFIABLE("REQUESTED_RANGE_NOT_SATISFIABLE"),
		EXPECTATION_FAILED("EXPECTATION_FAILED"),
		I_AM_A_TEAPOT("I_AM_A_TEAPOT"),
		INSUFFICIENT_SPACE_ON_RESOURCE("INSUFFICIENT_SPACE_ON_RESOURCE"),
		METHOD_FAILURE("METHOD_FAILURE"),
		DESTINATION_LOCKED("DESTINATION_LOCKED"),
		UNPROCESSABLE_ENTITY("UNPROCESSABLE_ENTITY"), LOCKED("LOCKED"),
		FAILED_DEPENDENCY("FAILED_DEPENDENCY"), TOO_EARLY("TOO_EARLY"),
		UPGRADE_REQUIRED("UPGRADE_REQUIRED"),
		PRECONDITION_REQUIRED("PRECONDITION_REQUIRED"),
		TOO_MANY_REQUESTS("TOO_MANY_REQUESTS"),
		REQUEST_HEADER_FIELDS_TOO_LARGE("REQUEST_HEADER_FIELDS_TOO_LARGE"),
		UNAVAILABLE_FOR_LEGAL_REASONS("UNAVAILABLE_FOR_LEGAL_REASONS"),
		INTERNAL_SERVER_ERROR("INTERNAL_SERVER_ERROR"),
		NOT_IMPLEMENTED("NOT_IMPLEMENTED"), BAD_GATEWAY("BAD_GATEWAY"),
		SERVICE_UNAVAILABLE("SERVICE_UNAVAILABLE"),
		GATEWAY_TIMEOUT("GATEWAY_TIMEOUT"),
		HTTP_VERSION_NOT_SUPPORTED("HTTP_VERSION_NOT_SUPPORTED"),
		VARIANT_ALSO_NEGOTIATES("VARIANT_ALSO_NEGOTIATES"),
		INSUFFICIENT_STORAGE("INSUFFICIENT_STORAGE"),
		LOOP_DETECTED("LOOP_DETECTED"),
		BANDWIDTH_LIMIT_EXCEEDED("BANDWIDTH_LIMIT_EXCEEDED"),
		NOT_EXTENDED("NOT_EXTENDED"),
		NETWORK_AUTHENTICATION_REQUIRED("NETWORK_AUTHENTICATION_REQUIRED");

		public static StatusResp create(String value) {
			for (StatusResp statusResp : values()) {
				if (Objects.equals(statusResp.getValue(), value) ||
					Objects.equals(statusResp.name(), value)) {

					return statusResp;
				}
			}

			return null;
		}

		public String getValue() {
			return _value;
		}

		@Override
		public String toString() {
			return _value;
		}

		private StatusResp(String value) {
			_value = value;
		}

		private final String _value;

	}

}