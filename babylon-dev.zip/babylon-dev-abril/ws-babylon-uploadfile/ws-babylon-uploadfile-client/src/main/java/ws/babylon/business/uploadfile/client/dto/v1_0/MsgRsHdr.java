package ws.babylon.business.uploadfile.client.dto.v1_0;

import java.io.Serializable;

import java.util.Objects;

import javax.annotation.Generated;

import ws.babylon.business.uploadfile.client.dto.v1_0.Error;
import ws.babylon.business.uploadfile.client.function.UnsafeSupplier;
import ws.babylon.business.uploadfile.client.serdes.v1_0.MsgRsHdrSerDes;

/**
 * @author Alexandra Galindo Cante
 * @generated
 */
@Generated("")
public class MsgRsHdr implements Cloneable, Serializable {

	public static MsgRsHdr toDTO(String json) {
		return MsgRsHdrSerDes.toDTO(json);
	}

	public Error getError() {
		return error;
	}

	public void setError(Error error) {
		this.error = error;
	}

	public void setError(UnsafeSupplier<Error, Exception> errorUnsafeSupplier) {
		try {
			error = errorUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected Error error;

	@Override
	public MsgRsHdr clone() throws CloneNotSupportedException {
		return (MsgRsHdr)super.clone();
	}

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof MsgRsHdr)) {
			return false;
		}

		MsgRsHdr msgRsHdr = (MsgRsHdr)object;

		return Objects.equals(toString(), msgRsHdr.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		return MsgRsHdrSerDes.toJSON(this);
	}

}