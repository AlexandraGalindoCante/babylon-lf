package ws.babylon.business.uploadfile.client.dto.v1_0;

import java.io.Serializable;

import java.util.Objects;

import javax.annotation.Generated;

import ws.babylon.business.uploadfile.client.function.UnsafeSupplier;
import ws.babylon.business.uploadfile.client.serdes.v1_0.ReqUploadDocSerDes;

/**
 * @author Alexandra Galindo Cante
 * @generated
 */
@Generated("")
public class ReqUploadDoc implements Cloneable, Serializable {

	public static ReqUploadDoc toDTO(String json) {
		return ReqUploadDocSerDes.toDTO(json);
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public void setData(UnsafeSupplier<String, Exception> dataUnsafeSupplier) {
		try {
			data = dataUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected String data;

	public String getFile() {
		return file;
	}

	public void setFile(String file) {
		this.file = file;
	}

	public void setFile(UnsafeSupplier<String, Exception> fileUnsafeSupplier) {
		try {
			file = fileUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected String file;

	@Override
	public ReqUploadDoc clone() throws CloneNotSupportedException {
		return (ReqUploadDoc)super.clone();
	}

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof ReqUploadDoc)) {
			return false;
		}

		ReqUploadDoc reqUploadDoc = (ReqUploadDoc)object;

		return Objects.equals(toString(), reqUploadDoc.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		return ReqUploadDocSerDes.toJSON(this);
	}

}