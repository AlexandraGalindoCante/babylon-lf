package ws.babylon.business.uploadfile.client.dto.v1_0;

import java.io.Serializable;

import java.util.Objects;

import javax.annotation.Generated;

import ws.babylon.business.uploadfile.client.function.UnsafeSupplier;
import ws.babylon.business.uploadfile.client.serdes.v1_0.ResultSerDes;

/**
 * @author Alexandra Galindo Cante
 * @generated
 */
@Generated("")
public class Result implements Cloneable, Serializable {

	public static Result toDTO(String json) {
		return ResultSerDes.toDTO(json);
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public void setUrl(UnsafeSupplier<String, Exception> urlUnsafeSupplier) {
		try {
			url = urlUnsafeSupplier.get();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected String url;

	@Override
	public Result clone() throws CloneNotSupportedException {
		return (Result)super.clone();
	}

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof Result)) {
			return false;
		}

		Result result = (Result)object;

		return Objects.equals(toString(), result.toString());
	}

	@Override
	public int hashCode() {
		String string = toString();

		return string.hashCode();
	}

	public String toString() {
		return ResultSerDes.toJSON(this);
	}

}