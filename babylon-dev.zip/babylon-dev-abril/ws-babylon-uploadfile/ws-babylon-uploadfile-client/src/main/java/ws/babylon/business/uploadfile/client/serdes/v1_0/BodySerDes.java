package ws.babylon.business.uploadfile.client.serdes.v1_0;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TreeMap;
import java.util.stream.Stream;

import javax.annotation.Generated;

import ws.babylon.business.uploadfile.client.dto.v1_0.Body;
import ws.babylon.business.uploadfile.client.dto.v1_0.Result;
import ws.babylon.business.uploadfile.client.json.BaseJSONParser;

/**
 * @author Alexandra Galindo Cante
 * @generated
 */
@Generated("")
public class BodySerDes {

	public static Body toDTO(String json) {
		BodyJSONParser bodyJSONParser = new BodyJSONParser();

		return bodyJSONParser.parseToDTO(json);
	}

	public static Body[] toDTOs(String json) {
		BodyJSONParser bodyJSONParser = new BodyJSONParser();

		return bodyJSONParser.parseToDTOs(json);
	}

	public static String toJSON(Body body) {
		if (body == null) {
			return "null";
		}

		StringBuilder sb = new StringBuilder();

		sb.append("{");

		if (body.getResults() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"results\": ");

			sb.append("[");

			for (int i = 0; i < body.getResults().length; i++) {
				sb.append(String.valueOf(body.getResults()[i]));

				if ((i + 1) < body.getResults().length) {
					sb.append(", ");
				}
			}

			sb.append("]");
		}

		sb.append("}");

		return sb.toString();
	}

	public static Map<String, Object> toMap(String json) {
		BodyJSONParser bodyJSONParser = new BodyJSONParser();

		return bodyJSONParser.parseToMap(json);
	}

	public static Map<String, String> toMap(Body body) {
		if (body == null) {
			return null;
		}

		Map<String, String> map = new TreeMap<>();

		if (body.getResults() == null) {
			map.put("results", null);
		}
		else {
			map.put("results", String.valueOf(body.getResults()));
		}

		return map;
	}

	public static class BodyJSONParser extends BaseJSONParser<Body> {

		@Override
		protected Body createDTO() {
			return new Body();
		}

		@Override
		protected Body[] createDTOArray(int size) {
			return new Body[size];
		}

		@Override
		protected void setField(
			Body body, String jsonParserFieldName,
			Object jsonParserFieldValue) {

			if (Objects.equals(jsonParserFieldName, "results")) {
				if (jsonParserFieldValue != null) {
					body.setResults(
						Stream.of(
							toStrings((Object[])jsonParserFieldValue)
						).map(
							object -> ResultSerDes.toDTO((String)object)
						).toArray(
							size -> new Result[size]
						));
				}
			}
		}

	}

	private static String _escape(Object object) {
		String string = String.valueOf(object);

		for (String[] strings : BaseJSONParser.JSON_ESCAPE_STRINGS) {
			string = string.replace(strings[0], strings[1]);
		}

		return string;
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(entry.getKey());
			sb.append("\": ");

			Object value = entry.getValue();

			Class<?> valueClass = value.getClass();

			if (value instanceof Map) {
				sb.append(_toJSON((Map)value));
			}
			else if (valueClass.isArray()) {
				Object[] values = (Object[])value;

				sb.append("[");

				for (int i = 0; i < values.length; i++) {
					sb.append("\"");
					sb.append(_escape(values[i]));
					sb.append("\"");

					if ((i + 1) < values.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(entry.getValue()));
				sb.append("\"");
			}
			else {
				sb.append(String.valueOf(entry.getValue()));
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

}