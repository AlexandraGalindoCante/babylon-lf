package ws.babylon.business.uploadfile.client.serdes.v1_0;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TreeMap;

import javax.annotation.Generated;

import ws.babylon.business.uploadfile.client.dto.v1_0.LoadFileResponse;
import ws.babylon.business.uploadfile.client.json.BaseJSONParser;

/**
 * @author Alexandra Galindo Cante
 * @generated
 */
@Generated("")
public class LoadFileResponseSerDes {

	public static LoadFileResponse toDTO(String json) {
		LoadFileResponseJSONParser loadFileResponseJSONParser =
			new LoadFileResponseJSONParser();

		return loadFileResponseJSONParser.parseToDTO(json);
	}

	public static LoadFileResponse[] toDTOs(String json) {
		LoadFileResponseJSONParser loadFileResponseJSONParser =
			new LoadFileResponseJSONParser();

		return loadFileResponseJSONParser.parseToDTOs(json);
	}

	public static String toJSON(LoadFileResponse loadFileResponse) {
		if (loadFileResponse == null) {
			return "null";
		}

		StringBuilder sb = new StringBuilder();

		sb.append("{");

		if (loadFileResponse.getMsgRsHdr() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"MsgRsHdr\": ");

			sb.append(String.valueOf(loadFileResponse.getMsgRsHdr()));
		}

		if (loadFileResponse.getBody() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"body\": ");

			sb.append(String.valueOf(loadFileResponse.getBody()));
		}

		if (loadFileResponse.getCodeResp() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"codeResp\": ");

			sb.append(loadFileResponse.getCodeResp());
		}

		if (loadFileResponse.getMessage() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"message\": ");

			sb.append("\"");

			sb.append(_escape(loadFileResponse.getMessage()));

			sb.append("\"");
		}

		if (loadFileResponse.getShow() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"show\": ");

			sb.append(loadFileResponse.getShow());
		}

		if (loadFileResponse.getStatusResp() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"statusResp\": ");

			sb.append("\"");

			sb.append(loadFileResponse.getStatusResp());

			sb.append("\"");
		}

		sb.append("}");

		return sb.toString();
	}

	public static Map<String, Object> toMap(String json) {
		LoadFileResponseJSONParser loadFileResponseJSONParser =
			new LoadFileResponseJSONParser();

		return loadFileResponseJSONParser.parseToMap(json);
	}

	public static Map<String, String> toMap(LoadFileResponse loadFileResponse) {
		if (loadFileResponse == null) {
			return null;
		}

		Map<String, String> map = new TreeMap<>();

		if (loadFileResponse.getMsgRsHdr() == null) {
			map.put("MsgRsHdr", null);
		}
		else {
			map.put("MsgRsHdr", String.valueOf(loadFileResponse.getMsgRsHdr()));
		}

		if (loadFileResponse.getBody() == null) {
			map.put("body", null);
		}
		else {
			map.put("body", String.valueOf(loadFileResponse.getBody()));
		}

		if (loadFileResponse.getCodeResp() == null) {
			map.put("codeResp", null);
		}
		else {
			map.put("codeResp", String.valueOf(loadFileResponse.getCodeResp()));
		}

		if (loadFileResponse.getMessage() == null) {
			map.put("message", null);
		}
		else {
			map.put("message", String.valueOf(loadFileResponse.getMessage()));
		}

		if (loadFileResponse.getShow() == null) {
			map.put("show", null);
		}
		else {
			map.put("show", String.valueOf(loadFileResponse.getShow()));
		}

		if (loadFileResponse.getStatusResp() == null) {
			map.put("statusResp", null);
		}
		else {
			map.put(
				"statusResp", String.valueOf(loadFileResponse.getStatusResp()));
		}

		return map;
	}

	public static class LoadFileResponseJSONParser
		extends BaseJSONParser<LoadFileResponse> {

		@Override
		protected LoadFileResponse createDTO() {
			return new LoadFileResponse();
		}

		@Override
		protected LoadFileResponse[] createDTOArray(int size) {
			return new LoadFileResponse[size];
		}

		@Override
		protected void setField(
			LoadFileResponse loadFileResponse, String jsonParserFieldName,
			Object jsonParserFieldValue) {

			if (Objects.equals(jsonParserFieldName, "MsgRsHdr")) {
				if (jsonParserFieldValue != null) {
					loadFileResponse.setMsgRsHdr(
						MsgRsHdrSerDes.toDTO((String)jsonParserFieldValue));
				}
			}
			else if (Objects.equals(jsonParserFieldName, "body")) {
				if (jsonParserFieldValue != null) {
					loadFileResponse.setBody(
						BodySerDes.toDTO((String)jsonParserFieldValue));
				}
			}
			else if (Objects.equals(jsonParserFieldName, "codeResp")) {
				if (jsonParserFieldValue != null) {
					loadFileResponse.setCodeResp(
						Integer.valueOf((String)jsonParserFieldValue));
				}
			}
			else if (Objects.equals(jsonParserFieldName, "message")) {
				if (jsonParserFieldValue != null) {
					loadFileResponse.setMessage((String)jsonParserFieldValue);
				}
			}
			else if (Objects.equals(jsonParserFieldName, "show")) {
				if (jsonParserFieldValue != null) {
					loadFileResponse.setShow((Boolean)jsonParserFieldValue);
				}
			}
			else if (Objects.equals(jsonParserFieldName, "statusResp")) {
				if (jsonParserFieldValue != null) {
					loadFileResponse.setStatusResp(
						LoadFileResponse.StatusResp.create(
							(String)jsonParserFieldValue));
				}
			}
		}

	}

	private static String _escape(Object object) {
		String string = String.valueOf(object);

		for (String[] strings : BaseJSONParser.JSON_ESCAPE_STRINGS) {
			string = string.replace(strings[0], strings[1]);
		}

		return string;
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(entry.getKey());
			sb.append("\": ");

			Object value = entry.getValue();

			Class<?> valueClass = value.getClass();

			if (value instanceof Map) {
				sb.append(_toJSON((Map)value));
			}
			else if (valueClass.isArray()) {
				Object[] values = (Object[])value;

				sb.append("[");

				for (int i = 0; i < values.length; i++) {
					sb.append("\"");
					sb.append(_escape(values[i]));
					sb.append("\"");

					if ((i + 1) < values.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(entry.getValue()));
				sb.append("\"");
			}
			else {
				sb.append(String.valueOf(entry.getValue()));
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

}