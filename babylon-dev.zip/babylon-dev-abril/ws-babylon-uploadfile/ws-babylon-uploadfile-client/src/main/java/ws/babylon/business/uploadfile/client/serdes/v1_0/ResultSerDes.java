package ws.babylon.business.uploadfile.client.serdes.v1_0;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TreeMap;

import javax.annotation.Generated;

import ws.babylon.business.uploadfile.client.dto.v1_0.Result;
import ws.babylon.business.uploadfile.client.json.BaseJSONParser;

/**
 * @author Alexandra Galindo Cante
 * @generated
 */
@Generated("")
public class ResultSerDes {

	public static Result toDTO(String json) {
		ResultJSONParser resultJSONParser = new ResultJSONParser();

		return resultJSONParser.parseToDTO(json);
	}

	public static Result[] toDTOs(String json) {
		ResultJSONParser resultJSONParser = new ResultJSONParser();

		return resultJSONParser.parseToDTOs(json);
	}

	public static String toJSON(Result result) {
		if (result == null) {
			return "null";
		}

		StringBuilder sb = new StringBuilder();

		sb.append("{");

		if (result.getUrl() != null) {
			if (sb.length() > 1) {
				sb.append(", ");
			}

			sb.append("\"url\": ");

			sb.append("\"");

			sb.append(_escape(result.getUrl()));

			sb.append("\"");
		}

		sb.append("}");

		return sb.toString();
	}

	public static Map<String, Object> toMap(String json) {
		ResultJSONParser resultJSONParser = new ResultJSONParser();

		return resultJSONParser.parseToMap(json);
	}

	public static Map<String, String> toMap(Result result) {
		if (result == null) {
			return null;
		}

		Map<String, String> map = new TreeMap<>();

		if (result.getUrl() == null) {
			map.put("url", null);
		}
		else {
			map.put("url", String.valueOf(result.getUrl()));
		}

		return map;
	}

	public static class ResultJSONParser extends BaseJSONParser<Result> {

		@Override
		protected Result createDTO() {
			return new Result();
		}

		@Override
		protected Result[] createDTOArray(int size) {
			return new Result[size];
		}

		@Override
		protected void setField(
			Result result, String jsonParserFieldName,
			Object jsonParserFieldValue) {

			if (Objects.equals(jsonParserFieldName, "url")) {
				if (jsonParserFieldValue != null) {
					result.setUrl((String)jsonParserFieldValue);
				}
			}
		}

	}

	private static String _escape(Object object) {
		String string = String.valueOf(object);

		for (String[] strings : BaseJSONParser.JSON_ESCAPE_STRINGS) {
			string = string.replace(strings[0], strings[1]);
		}

		return string;
	}

	private static String _toJSON(Map<String, ?> map) {
		StringBuilder sb = new StringBuilder("{");

		@SuppressWarnings("unchecked")
		Set set = map.entrySet();

		@SuppressWarnings("unchecked")
		Iterator<Map.Entry<String, ?>> iterator = set.iterator();

		while (iterator.hasNext()) {
			Map.Entry<String, ?> entry = iterator.next();

			sb.append("\"");
			sb.append(entry.getKey());
			sb.append("\": ");

			Object value = entry.getValue();

			Class<?> valueClass = value.getClass();

			if (value instanceof Map) {
				sb.append(_toJSON((Map)value));
			}
			else if (valueClass.isArray()) {
				Object[] values = (Object[])value;

				sb.append("[");

				for (int i = 0; i < values.length; i++) {
					sb.append("\"");
					sb.append(_escape(values[i]));
					sb.append("\"");

					if ((i + 1) < values.length) {
						sb.append(", ");
					}
				}

				sb.append("]");
			}
			else if (value instanceof String) {
				sb.append("\"");
				sb.append(_escape(entry.getValue()));
				sb.append("\"");
			}
			else {
				sb.append(String.valueOf(entry.getValue()));
			}

			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}

		sb.append("}");

		return sb.toString();
	}

}