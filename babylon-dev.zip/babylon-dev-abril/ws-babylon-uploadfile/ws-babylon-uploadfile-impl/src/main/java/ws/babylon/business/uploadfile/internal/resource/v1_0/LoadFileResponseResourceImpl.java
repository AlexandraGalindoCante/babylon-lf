package ws.babylon.business.uploadfile.internal.resource.v1_0;

import com.liferay.petra.function.UnsafeBiConsumer;
import com.liferay.petra.function.UnsafeFunction;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;

import java.util.Collection;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ServiceScope;

import ws.babylon.business.uploadfile.dto.v1_0.LoadFileResponse;
import ws.babylon.business.uploadfile.dto.v1_0.ReqUploadDoc;
import ws.babylon.business.uploadfile.resource.v1_0.LoadFileResponseResource;
import ws.babylon.business.uploadfile.service.api.UploadFileServiceApi;
import ws.babylon.business.uploadfile.service.dto.LoadFileResponseWSDTO;
import ws.babylon.business.uploadfile.service.helper.UploadFileHelper;

/**
 * @author Alexandra Galindo Cante
 */
@Component(
	properties = "OSGI-INF/liferay/rest/v1_0/load-file-response.properties",
	scope = ServiceScope.PROTOTYPE, service = LoadFileResponseResource.class
)
public class LoadFileResponseResourceImpl
	extends BaseLoadFileResponseResourceImpl {
    
    
    private static final Log LOGGER = LogFactoryUtil.getLog(LoadFileResponseResourceImpl.class);
    
    
     @Reference private UploadFileServiceApi uploadFileServiceApi;
     
    
    @Reference
    private UploadFileHelper uploadFileHelper;
    
    public LoadFileResponse loadFile(ReqUploadDoc reqUploadDoc) throws Exception {

        LoadFileResponseWSDTO loadFileResponseWSDTO = new LoadFileResponseWSDTO();
        LOGGER.debug("Request UploadFile: "+reqUploadDoc.toString());
        loadFileResponseWSDTO = uploadFileServiceApi.callPostUploadFile(reqUploadDoc);

        return uploadFileHelper.mapUploadFileResponse(loadFileResponseWSDTO);

    }

    @Override
    public void setContextBatchUnsafeBiConsumer(
        UnsafeBiConsumer<Collection<LoadFileResponse>, UnsafeFunction<LoadFileResponse, LoadFileResponse, Exception>, Exception> contextBatchUnsafeBiConsumer) {
        // TODO Auto-generated method stub
        
    }
}