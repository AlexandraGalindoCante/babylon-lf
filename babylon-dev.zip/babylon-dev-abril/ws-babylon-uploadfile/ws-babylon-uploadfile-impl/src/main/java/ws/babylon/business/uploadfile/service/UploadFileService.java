package ws.babylon.business.uploadfile.service;

import com.babylon.utils.common.api.RestWebServicesClientUtilApi;
import com.babylon.utils.common.api.constants.BabylonCommonUtilsConstants;
import com.babylon.utils.common.api.constants.RestWebServiceConstants;
import com.babylon.utils.common.api.request.RestWebServiceRequest;
import com.babylon.utils.common.api.util.ResponseConverterUtil;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.ContentTypes;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.uuid.PortalUUIDUtil;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import ws.babylon.business.uploadfile.constants.BabylonBusinessUploadFileKeys;
import ws.babylon.business.uploadfile.constants.CommonsUtilsConstants;
import ws.babylon.business.uploadfile.dto.v1_0.ReqUploadDoc;
import ws.babylon.business.uploadfile.service.api.UploadFileServiceApi;
import ws.babylon.business.uploadfile.service.dto.LoadFileResponseWSDTO;
import ws.babylon.business.uploadfile.service.helper.UploadFileHelper;



@Component(immediate = true,
service = UploadFileServiceApi.class)
public class UploadFileService implements UploadFileServiceApi {

    private static final Log LOGGER = LogFactoryUtil.getLog(UploadFileService.class);
    
       
    @Reference
    private RestWebServicesClientUtilApi restWebServicesClientUtilApi;
    
    @Reference
    private UploadFileHelper uploadFileHelper;
    
    
    
    @Override
    public LoadFileResponseWSDTO callPostUploadFile(ReqUploadDoc requestUploadDoc) throws Exception {
        // Obtener configuración
        var config = uploadFileHelper.getConfiguration();
        String urlWS = uploadFileHelper.getConfiguration().getAttachmentServiceEndpoint();
        String serviceKey = config.getAttachmentServiceKey();

        LOGGER.info("::: URL del servicio: {}"+ urlWS);

        // Obtener documentId directamente desde la validación
        String documentId = uploadFileHelper.validateRequestUploadFile(requestUploadDoc);

        // Si la validación no es exitosa, documentId será el mensaje de error, no lo procesamos
        if (documentId.startsWith("Error")) {
            return ResponseConverterUtil.toDTO(
                ResponseConverterUtil.createJSONError(
                    BabylonCommonUtilsConstants.Response.BAD_REQUEST, documentId, "BAD_REQUEST"),
                LoadFileResponseWSDTO.class);
        }

        // Generar firma
        String firma = generateSignature(documentId, serviceKey);

        // Validar firma
        if (Validator.isNull(firma) || !checkHash(firma)) {
            LOGGER.error("Firma inválida o verificación fallida.");
            throw new Exception("Error: No se pudo generar una firma válida para el documento.");
        }
        
        JSONObject body = JSONFactoryUtil.createJSONObject();
        body.put("data", requestUploadDoc.getData());
        body.put("firma", firma);
        
        
        // Decodificar el archivo Base64
        File tempFile = UploadFileHelper.decodeBase64ToTempFile(requestUploadDoc.getFile());

        RestWebServiceRequest request = new RestWebServiceRequest.RequestBuilder()
            .requestURL(urlWS)
            .requestBodyMimeType(ContentTypes.MULTIPART_FORM_DATA)
            .requestBody(body) 
            .build();
        

        JSONObject response = restWebServicesClientUtilApi.callRestServiceByPost(request, false, LOGGER);
        LOGGER.info(response);

        if (response == null) {
            throw new Exception("Error: La respuesta del servicio es nula.");
        }

        LOGGER.info("Respuesta del servicio: {}"+ response);

        // Convertir la respuesta del servicio a DTO
        return ResponseConverterUtil.toDTO(response, LoadFileResponseWSDTO.class);
    }

 
    /**
     * <b>Name:</b> generateSignature <br>
     * <b>Description:</b> Genera una firma segura para validar el documento que se enviará al servicio externo. <br>
     * Combina una UUID, el nombre del documento y una clave del servicio para construir un payload cifrado. <br>
     *
     * <b>Creation Date:</b> Apr 05, 2025 <br>
     * <b>Author:</b> Alexandra Galindo Cante <br>
     * <b>Last Modified Date:</b> Apr 07, 2025 <br>
     * <b>Modified by:</b> Alexandra Galindo Cante <br>
     *
     * @param keyToEncode Cadena que representa el recurso/documento a firmar.
     * @param serviceToken Token de autenticación del servicio externo.
     * @return Cadena encriptada que representa la firma digital del documento.
     */
    /**
     * Genera una firma digital cifrada usando clave pública y verifica su integridad.
     *
     * @param keyToEncode Valor que se desea firmar digitalmente.
     * @param serviceToken Token de servicio para autenticación ante el servicio externo.
     * @return Firma digital generada, o cadena vacía si ocurre un error o la verificación falla.
     */
    public String generateSignature(String keyToEncode, String serviceToken) {
        try {
            String requestId = PortalUUIDUtil.generate();
            String publicKey = uploadFileHelper.getConfiguration().getServicePublicKey();

            // Paso 1: Construcción del mensaje inicial a cifrar
            JSONObject requestToEncrypt = JSONFactoryUtil.createJSONObject();
            requestToEncrypt.put("Salt", requestId);
            requestToEncrypt.put("Resource", keyToEncode);

            LOGGER.debug("Generando firma con serviceToken: {}" + serviceToken);

            String encryptedRequest = encryptWithPublicKey(requestToEncrypt.toJSONString(),
                publicKey);

            // Paso 2: Llamada al endpoint para obtener el 'Salt'
            JSONObject saltRequest = JSONFactoryUtil.createJSONObject();
            saltRequest.put("Message", encryptedRequest);

            RestWebServiceRequest wsRequest = new RestWebServiceRequest.RequestBuilder()
                .requestURL(uploadFileHelper.getConfiguration().getCreateSaltServiceEndpoint())
                .tokenizedRequestWithCredentials(serviceToken)
                .requestBody(saltRequest)
                .build();

            
            JSONObject response = restWebServicesClientUtilApi.callRestServiceByPost(wsRequest,
                LOGGER);
            LOGGER.info("Respuesta del servicio generateSignature: {}" + response);

            if (response == null || !response.has(CommonsUtilsConstants.FILE_UPLOAD_ID)) {
                LOGGER.error("Respuesta inválida o sin 'Salt'.");
                return StringPool.BLANK;
            }

            String salt = response.getString(CommonsUtilsConstants.FILE_UPLOAD_ID);

            // Paso 3: Construcción del JSON final para la firma
            JSONObject signatureToEncrypt = JSONFactoryUtil.createJSONObject();
            signatureToEncrypt.put(CommonsUtilsConstants.FILE_UPLOAD_ID_UPPER, salt);
            signatureToEncrypt.put(CommonsUtilsConstants.FILE_UPLOAD_RESOURCE, keyToEncode);
            signatureToEncrypt.put(CommonsUtilsConstants.FILE_UPLOAD_HASH,
                encodeHash(requestId + keyToEncode));

            String finalSignature = encryptWithPublicKey(signatureToEncrypt.toJSONString(),
                publicKey);

            // Paso 4: Validación obligatoria de la firma
            if (!checkHash(finalSignature)) {
                LOGGER.error("La verificación de hash falló para la firma generada.");
                return StringPool.BLANK;
            }

            return finalSignature;

        } catch (Exception e) {
            LOGGER.error("Error generando la firma: ", e);
        }

        return StringPool.BLANK;
    }

        
    private String encodeHash(String textToEncrypt) throws PortalException {
        MessageDigest digest;
        try {
            digest = MessageDigest.getInstance(CommonsUtilsConstants.FILE_UPLOAD_SHA_256_HASH);

            return Base64.getEncoder().encodeToString(digest
                .digest(textToEncrypt.getBytes(CommonsUtilsConstants.FILE_UPLOAD_UTF8_ENCODING)));

        } catch (NoSuchAlgorithmException | UnsupportedEncodingException e) {
            LOGGER.error("Error generando la firma:  ", e);
        }
        return StringPool.BLANK;
    }

    /**
     * <b>Name:</b> encryptWithPublicKey <br>
     * <b>Description:</b> Cifra una cadena de texto usando una clave pública en formato RSA. <br>
     * Se utiliza para proteger información sensible antes de enviarla a servicios externos. <br>
     *
     * @param textToEncrypt Texto plano que se desea cifrar.
     * @param key Clave pública codificada en Base64.
     * @return Cadena cifrada en Base64 o String vacío si ocurre un error.
     * @throws PortalException Excepción personalizada lanzada si ocurre un fallo grave.
     */
    private String encryptWithPublicKey(String textToEncrypt, String key) throws PortalException {
        try {
            // Decodifica la clave pública desde Base64
            byte[] publicKeyData = Base64.getDecoder().decode(key.getBytes(StandardCharsets.UTF_8));
            X509EncodedKeySpec publicKeySpec = new X509EncodedKeySpec(publicKeyData);

            // Genera la clave pública RSA
            PublicKey publicKey = KeyFactory
                .getInstance(CommonsUtilsConstants.FILE_UPLOAD_RSA_METHOD)
                .generatePublic(publicKeySpec);

            // Inicializa el cifrador
            Cipher cipher = Cipher.getInstance(CommonsUtilsConstants.FILE_UPLOAD_RSA_CIPHER);
            cipher.init(Cipher.ENCRYPT_MODE, publicKey);

            // Cifra y codifica en Base64
            byte[] encryptedBytes = cipher.doFinal(textToEncrypt.getBytes(StandardCharsets.UTF_8));
            return Base64.getEncoder().encodeToString(encryptedBytes);

        } catch (InvalidKeySpecException | NoSuchAlgorithmException | NoSuchPaddingException |
                 IllegalBlockSizeException | BadPaddingException | InvalidKeyException e) {
            LOGGER.error("Error al cifrar con la clave pública: ", e);
        }

        return StringPool.BLANK;
    }

    /**
     * Verifica la validez de un mensaje firmado enviándolo al endpoint de verificación.
     * 
     * @param  message Mensaje firmado que se desea validar.
     * @return         true si el hash es válido, false en caso contrario o si hay error en la
     *                 respuesta.
     */
    private Boolean checkHash(String message) {
        try {
            LOGGER.info("Iniciando verificación de hash con mensaje cifrado...");

            RestWebServiceRequest wsRequest = new RestWebServiceRequest.RequestBuilder()
                .requestURL(uploadFileHelper.getConfiguration().getCheckHashServiceEndpoint())
                .requestBody(message).build();

            JSONObject response = restWebServicesClientUtilApi.callRestServiceByPost(wsRequest,
                LOGGER);
            LOGGER.info("Respuesta del servicio checkHash: {}"+
                response != null ? response.toJSONString() : "null");

            if (response == null || !response.has("body")) {
                LOGGER.error("Respuesta nula o sin campo 'body'.");
                return Boolean.FALSE;
            }

            JSONObject body = response.getJSONObject("body");
            if (!body.has("result")) {
                LOGGER.error("El cuerpo de la respuesta no contiene 'result'.");
                return Boolean.FALSE;
            }

            return body.getBoolean("result");

        } catch (Exception e) {
            LOGGER.error("Error validando la firma con checkHash: ", e);
            return Boolean.FALSE;
        }
    }

    /**
     * Obtiene un token de autorización para consumo de servicios externos mediante client credentials.
     *
     * @param key Clave del servicio utilizada para autenticación.
     * @return El token de autorización como una cadena.
     * @throws Exception Si no se puede obtener el token por error de autenticación, 
     *                   configuración o respuesta inválida del servidor.
     */
    private String getRequestAuthorizationToken(String key) throws Exception {
        LOGGER.info("Iniciando obtención de token de autorización...");

        String urlToken = uploadFileHelper.getConfiguration().getAttachmentServiceEndpoint();
        String authToken = RestWebServiceConstants.KEY_UTILS_BASIC_AUTHORIZATION + key;

        // Validación de parámetros
        if (urlToken.isEmpty()) {
            throw new Exception(BabylonBusinessUploadFileKeys.AUTH_EXCEPTION_NOURL);
        }
        if (authToken.isEmpty()) {
            throw new Exception(BabylonBusinessUploadFileKeys.AUTH_EXCEPTION_NOTOKEN);
        }

        LOGGER.info("URL del endpoint de token: {}"+ urlToken);
        LOGGER.debug("Authorization token generado: {}"+ authToken);

        // Construcción de headers
        Map<String, String> headers = new HashMap<>();
        headers.put(RestWebServiceConstants.KEY_UTILS_AUTHORIZATION, authToken);
        headers.put(RestWebServiceConstants.KEY_UTILS_CONTENT_TYPE,
                    RestWebServiceConstants.KEY_UTILS_APPLICATION_URLENCODED);
        headers.put("Cookie", "CookieConsentPolicy=0:1; LSKey-c$CookieConsentPolicy=0:1");

        // Parámetros del cuerpo
        Map<String, String> parameters = new HashMap<>();
        parameters.put(RestWebServiceConstants.KEY_UTILS_GRANT_TYPE,
                       RestWebServiceConstants.KEY_UTILS_CLIENT_CREDENTIALS);

        // Construcción del cuerpo
        String requestBody = RestWebServiceConstants.KEY_UTILS_GRANT_TYPE + "=" +
                             RestWebServiceConstants.KEY_UTILS_CLIENT_CREDENTIALS;

        // Armado de la solicitud REST
        RestWebServiceRequest restWebServiceRequest = new RestWebServiceRequest.RequestBuilder()
            .requestURL(urlToken)
            .requestParameters(parameters)
            .requestBody(requestBody)
            .requestHeaders(headers)
            .build();

        LOGGER.info("Solicitud para obtener token: {}"+ restWebServiceRequest);

        // Llamada al servicio
        JSONObject serviceResponse = restWebServicesClientUtilApi
            .callRestServiceByPost(restWebServiceRequest, Boolean.FALSE, LOGGER);

        LOGGER.info("Respuesta del servicio de token: {}"+ 
            serviceResponse != null ? serviceResponse.toJSONString() : "null");

        if (serviceResponse == null || serviceResponse.has(BabylonBusinessUploadFileKeys.JSON_ERROR)) {
            throw new Exception(BabylonBusinessUploadFileKeys.AUTH_EXCEPTION_UNAUTHORIZED);
        }

        return serviceResponse.getString(RestWebServiceConstants.KEY_UTILS_ACCESS_TOKEN);
    }
    
    
    

}
