package ws.babylon.business.uploadfile.service.helper;

import com.babylon.utils.common.api.constants.BabylonCommonUtilsConstants;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.liferay.portal.configuration.metatype.bnd.util.ConfigurableUtil;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.Map;

import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;

import ws.babylon.business.uploadfile.config.BabylonBusinesUploadFileConfig;
import ws.babylon.business.uploadfile.constants.BabylonBusinessUploadFileKeys;
import ws.babylon.business.uploadfile.dto.v1_0.LoadFileResponse;
import ws.babylon.business.uploadfile.dto.v1_0.ReqUploadDoc;
import ws.babylon.business.uploadfile.service.dto.CanonicoAthento;
import ws.babylon.business.uploadfile.service.dto.LoadFileResponseWSDTO;

@Component(configurationPid = {
    BabylonBusinessUploadFileKeys.BABYLON_UPLOAD_FILE_CONFIG }, immediate = true, service = UploadFileHelper.class)
public class UploadFileHelper {

    private static final Log LOGGER = LogFactoryUtil.getLog(UploadFileHelper.class);
    
    private volatile BabylonBusinesUploadFileConfig configuration;

       
    
    public BabylonBusinesUploadFileConfig getConfiguration() {
        return configuration;
    }

    @Activate
    @Modified
    protected void activate(Map<String, Object> properties) {
        LOGGER.info(":: INIT activate::");
        configuration = ConfigurableUtil.createConfigurable(BabylonBusinesUploadFileConfig.class, properties);
        LOGGER.info(":: END activate::" + configuration);
    }

    public String validateRequestUploadFile(ReqUploadDoc reqUploadDoc) {
        if (reqUploadDoc == null) return "Error: El objeto de solicitud está vacío.";

        // Validar que 'file' esté presente y no sea vacío (esperado en Base64)
        if (reqUploadDoc.getFile() == null || reqUploadDoc.getFile().isEmpty()) {
            return "Error: El archivo codificado en Base64 es obligatorio.";
        }

        // Validar que 'file' esté en formato Base64
        if (!isBase64(reqUploadDoc.getFile())) {
            return "Error: El archivo no tiene un formato Base64 válido.";
        }

        // Validar que 'data' esté presente y no sea vacío
        if (reqUploadDoc.getData() == null || reqUploadDoc.getData().isEmpty()) {
            return "Error: Los datos del documento están vacíos.";
        }

        // Deserializar 'data' que viene como String (JSON serializado)
        CanonicoAthento canonico;
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            canonico = objectMapper.readValue(reqUploadDoc.getData(), CanonicoAthento.class);
        } catch (Exception e) {
            return "Error: No se pudo deserializar 'data'.";
        }

        if (canonico == null) return "Error: La información 'canonicoAthento' está vacía.";

        var params = canonico.getParams();
        if (params == null) return "Error: Los parámetros del documento están vacíos.";

        var prop = params.getParamProperties();
        if (prop == null) return "Error: Las propiedades del documento están vacías.";

        // Validar campos obligatorios
        Map<String, String> campos = new LinkedHashMap<>();
        campos.put("canonico_nombre_documento", prop.getCanonico_nombre_documento());
        campos.put("canonico_nro_identificacion_cliente", prop.getCanonico_nro_identificacion_cliente());
        campos.put("canonico_tipo_identificacion_cliente", prop.getCanonico_tipo_identificacion_cliente());
        campos.put("canonico_ramo", prop.getCanonico_ramo());
        campos.put("canonico_producto", prop.getCanonico_producto());
        campos.put("canonico_nombre_aliado", prop.getCanonico_nombre_aliado());
        campos.put("canonico_requiere_firma", prop.getCanonico_requiere_firma());
        campos.put("canonico_clave_aliado", prop.getCanonico_clave_aliado());

        for (Map.Entry<String, String> campo : campos.entrySet()) {
            if (campo.getValue() == null || campo.getValue().isEmpty()) {
                return "Error: El campo '" + campo.getKey() + "' es obligatorio.";
            }
        }

        // Validar fecha si viene
        if (prop.getCanonico_fecha_almacenamiento_documento() != null) {
            try {
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                dateFormat.setLenient(false);
                dateFormat.parse(prop.getCanonico_fecha_almacenamiento_documento());
            } catch (ParseException e) {
                return "Error: La fecha de almacenamiento del documento es inválida.";
            }
        }

        String documentId = String.format("%s_%s",
            prop.getCanonico_nombre_documento(),
            prop.getCanonico_nro_identificacion_cliente());

        return documentId;
    }

    
    
    private boolean isBase64(String base64) {
        try {
            Base64.getDecoder().decode(base64);
            return true;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }



    public LoadFileResponse mapUploadFileResponse(LoadFileResponseWSDTO loadFileResponseWSDTO) {
        // TODO Auto-generated method stub
        return null;
    }
    

    /**
     * <b>Name: </b> getInternalServerError </br>
     * <b>Description:</b> </br>
     * <b>Creation Date:</b> 2 ap. 2025 </br>
     * <b>Autor:</b> Alexandra Galindo Cante</br>
     * <b>Last Modified Date:</b> 2 ap. 2025 </br>
     * 
     * @param  checkIdentityWSResponse
     * @return
     */
    public static LoadFileResponse getInternalServerError(
        LoadFileResponseWSDTO loadFileWSResponse) {
        LoadFileResponse response = new LoadFileResponse();

        response.setCodeResp(BabylonCommonUtilsConstants.Response.STATUS_INTERNAL_ERROR);
        response.setMessage(BabylonCommonUtilsConstants.Response.MESSAGE_INTERNAL_ERROR);
        response.setStatusResp(LoadFileResponse.StatusResp.INTERNAL_SERVER_ERROR);

        if (loadFileWSResponse == null || loadFileWSResponse.getMsgRsHdr() == null
            || loadFileWSResponse.getMsgRsHdr().getError() == null) {
            response.setMessage(BabylonCommonUtilsConstants.Response.MESSAGE_INTERNAL_ERROR);
            response.setStatusResp(LoadFileResponse.StatusResp.INTERNAL_SERVER_ERROR);
        } else {
            response.setCodeResp(
                Integer.valueOf(loadFileWSResponse.getMsgRsHdr().getError().getStatusCode()));
            response.setMessage(
                loadFileWSResponse.getMsgRsHdr().getError().getAditionalStatus().getStatusDesc());
            response.setStatusResp(LoadFileResponse.StatusResp.INTERNAL_SERVER_ERROR);
            LOGGER.error("Service checkIdentityWSResponse ERROR: "
                + loadFileWSResponse.getMsgRsHdr().getError().getAditionalStatus().getStatusDesc());
        }

        return response;
    }
        
    
    /**
     * Decodifica un archivo en Base64 y lo guarda como archivo temporal.
     *
     * @param base64File El archivo en Base64 que se desea decodificar.
     * @return El archivo temporal creado.
     * @throws Exception Si ocurre un error al crear el archivo o decodificar.
     */
    public static File decodeBase64ToTempFile(String base64File) throws Exception {
        // Validar que la cadena Base64 no esté vacía
        if (base64File == null || base64File.isEmpty()) {
            throw new IllegalArgumentException("La cadena Base64 no puede estar vacía.");
        }

        try {
            // Decodificar el archivo Base64
            byte[] decodedFile = Base64.getDecoder().decode(base64File);

            // Crear archivo temporal
            File tempFile = File.createTempFile("uploaded_", ".pdf");

            // Escribir el contenido decodificado en el archivo temporal
            Files.write(tempFile.toPath(), decodedFile);

            // Log para confirmar el archivo temporal creado
            System.out.println("Archivo temporal creado en: " + tempFile.getAbsolutePath());

            // Devolver el archivo temporal
            return tempFile;
        } catch (IOException e) {
            // Manejo de excepciones de I/O
            throw new IOException("Error al crear o escribir en el archivo temporal: " + e.getMessage(), e);
        } catch (IllegalArgumentException e) {
            // Manejo de posibles errores de decodificación Base64
            throw new IllegalArgumentException("Archivo Base64 no válido: " + e.getMessage(), e);
        }
    }

   
}
