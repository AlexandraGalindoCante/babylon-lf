package ws.babylon.business.uploadfile.resource.v1_0.test;

import com.liferay.arquillian.extension.junit.bridge.junit.Arquillian;

import org.junit.Ignore;
import org.junit.runner.RunWith;

/**
 * @author chris
 */
@Ignore
@RunWith(Arquillian.class)
public class LoadFileResponseResourceTest
	extends BaseLoadFileResponseResourceTestCase {
}